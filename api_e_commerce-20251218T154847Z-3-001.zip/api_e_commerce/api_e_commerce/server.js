require("dotenv").config();

const path = require("path");
const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const { createLogger, format, transports } = require("winston");
const { SecretManagerServiceClient } = require("@google-cloud/secret-manager");

const { connectDB, prisma } = require("./config/db");
const authRoutes = require("./src/routes/auth.route");
const uploadRoutes = require("./src/routes/upload.route");
const buyerRoutes = require("./src/routes/buyer.route");
const cartRoutes = require("./src/routes/cart.route");
const orderRoutes = require("./src/routes/order.route");
const paymentRoutes = require("./src/routes/payment.route");
const reviewRoutes = require("./src/routes/review.route");
const shipperRoutes = require("./src/routes/shipper.route");
const chatRoutes = require("./src/routes/chat.route");
const searchRoutes = require("./src/routes/search.route");

// -------------------- Logger --------------------
const logger = createLogger({
  level: process.env.NODE_ENV === "production" ? "info" : "debug",
  format: format.combine(format.timestamp(), format.json()),
  transports: [
    new transports.Console({
      format: format.combine(format.colorize(), format.simple()),
    }),
  ],
});

// -------------------- Secret Manager helpers --------------------
const smClient = new SecretManagerServiceClient();

async function readSecret(key) {
  if (process.env[key]) return process.env[key];
  const projectId =
    process.env.GOOGLE_CLOUD_PROJECT ||
    process.env.GCP_PROJECT ||
    "subtle-seat-475108-v5";
  const name = `projects/${projectId}/secrets/${key}/versions/latest`;
  try {
    const [version] = await smClient.accessSecretVersion({ name });
    const value = version.payload.data.toString("utf8");
    process.env[key] = value;
    logger.info(`Loaded secret ${key} from Secret Manager`);
    return value;
  } catch {
    logger.warn(
      `Cannot load secret ${key} from Secret Manager, using process.env fallback if any`
    );
    return process.env[key];
  }
}

async function loadAllSecrets() {
  const keys = [
    "DATABASE_URL",
    "JWT_SECRET",
    "REFRESH_JWT_SECRET",
    "CORS_ORIGIN",
    "VNP_TMN_CODE",
    "VNP_HASH_SECRET",
    "VNP_URL",
    "VNP_RETURN_URL",
    "VNP_IPN_URL",
    "GEMINI_API_KEY",
  ];

  await Promise.all(keys.map(readSecret));

  const connName = "subtle-seat-475108-v5:asia-southeast1:market-data-db";
  const dbUrl = process.env.DATABASE_URL;

  if (!dbUrl) throw new Error("DATABASE_URL not configured");

  logger.info(`DB URL (no auto-append): ${dbUrl}`);
  logger.info(`DB URL includes /cloudsql: ${/\/cloudsql\//.test(dbUrl)}`);
  logger.info(
    `DB URL param ok (host|socket): ${/\b(host|socket)=\/cloudsql\//.test(
      dbUrl
    )}`
  );
}

// -------------------- Swagger (optional) --------------------
let openapi;
try {
  openapi = require("./openapi.json");
} catch {
  logger.warn("OpenAPI spec not found, skip /docs");
}

// -------------------- App --------------------
const app = express();
const PORT = process.env.PORT || 8080;

app.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

app.get("/db/ping", async (_req, res, next) => {
  try {
    const [row] =
      await prisma.$queryRaw`SELECT DATABASE() AS db, NOW() AS now, VERSION() AS version`;
    res.json(row);
  } catch (e) {
    next(e);
  }
});

async function initializeApp() {
  await loadAllSecrets();

  await connectDB();
  logger.info("Database connected");

  app.use(helmet());
  app.set("trust proxy", 1);
  // JSON parser với error handler
  app.use(express.json({ limit: "10kb" }));
  app.use((err, req, res, next) => {
    if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
      return res.status(400).json({
        success: false,
        message:
          "JSON không hợp lệ. Vui lòng kiểm tra lại request body (không có dấu phẩy thừa, dùng dấu ngoặc kép đôi cho property names).",
        error: err.message,
      });
    }
    next(err);
  });
  app.use(express.urlencoded({ extended: true, limit: "10kb" }));
  app.use(cookieParser());
  app.use(express.static(path.join(__dirname, "public")));

  const allowOrigins = process.env.CORS_ORIGIN
    ? process.env.CORS_ORIGIN.split(",").map((s) => s.trim())
    : true;
  app.use(
    cors({ origin: allowOrigins, credentials: true, optionsSuccessStatus: 200 })
  );

  app.use((req, res, next) => {
    const start = Date.now();
    res.on("finish", () =>
      logger.info({
        method: req.method,
        url: req.originalUrl,
        status: res.statusCode,
        duration: `${Date.now() - start}ms`,
        ip: req.ip,
      })
    );
    next();
  });

  // --- Swagger UI ---
  if (openapi) {
    if (openapi.openapi && openapi.openapi.startsWith("3")) {
      openapi.servers = [{ url: "/" }];
      delete openapi.host;
      delete openapi.basePath;
      delete openapi.schemes;
    } else {
      openapi.schemes = ["https"];
      delete openapi.host;
      openapi.basePath = "/";
    }

    const swaggerUi = require("swagger-ui-express");
    app.use(
      "/docs",
      swaggerUi.serve,
      swaggerUi.setup(openapi, {
        explorer: true,
        swaggerOptions: {
          validatorUrl: null,
        },
      })
    );
    logger.info("Swagger UI available at /docs");
  }

  app.use("/api/auth", authRoutes);
  app.use("/api/upload", uploadRoutes);
  app.use("/api/buyer", buyerRoutes);
  app.use("/api/buyer/cart", cartRoutes);
  app.use("/api/buyer/orders", orderRoutes);
  app.use("/api/payment", paymentRoutes);
  app.use("/api/review", reviewRoutes);
  app.use("/api/shipper", shipperRoutes);
  app.use("/api/search", searchRoutes);
  app.use("/api/chat", chatRoutes);
  app.use("/api/seller", require("./src/routes/seller.route"));

  app.use((req, res) =>
    res.status(404).json({ success: false, message: "Endpoint not found" })
  );
  app.use((err, _req, res, _next) => {
    logger.error("Unhandled error:", err);
    res.status(err.status || 500).json({
      success: false,
      message: err.message || "Internal Server Error",
      ...(process.env.NODE_ENV !== "production" && { stack: err.stack }),
    });
  });

  logger.info({
    vnp_tmn_code: process.env.VNP_TMN_CODE,
    vnp_hash_type: (
      process.env.VNP_SECURE_HASH_TYPE || "HMACSHA512"
    ).toUpperCase(),
    vnp_hash_secret_len: (process.env.VNP_HASH_SECRET || "").trim().length,
    vnp_url: process.env.VNP_URL,
    vnp_return_url: process.env.VNP_RETURN_URL,
    vnp_ipn_url: process.env.VNP_IPN_URL,
  });
}

async function startServer() {
  try {
    await initializeApp();
    app.listen(PORT, "0.0.0.0", () => {
      logger.info(
        `Server started on port ${PORT} (env: ${
          process.env.NODE_ENV || "development"
        })`
      );
      logger.info(`CORS origins: ${process.env.CORS_ORIGIN || "All"}`);
    });
  } catch (err) {
    logger.error("Failed to start server:", err);
    app.use((_req, res) =>
      res.status(500).json({ success: false, message: "Boot failed" })
    );
  }
}

startServer();
