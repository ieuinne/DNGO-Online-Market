require("dotenv").config();
const { GoogleGenerativeAI } = require("@google/generative-ai");

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (!GEMINI_API_KEY) {
  console.error("❌ GEMINI_API_KEY chưa được cấu hình trong .env");
  process.exit(1);
}

async function listModels() {
  try {
    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models?key=${GEMINI_API_KEY}`
    );

    if (!response.ok) {
      const error = await response.text();
      console.error("❌ Lỗi:", error);
      return;
    }

    const data = await response.json();

    console.log("\n✅ Các model có sẵn:\n");
    console.log("=".repeat(80));

    if (data.models && data.models.length > 0) {
      data.models.forEach((model, index) => {
        console.log(`\n${index + 1}. ${model.name}`);
        console.log(`   Display Name: ${model.displayName || "N/A"}`);
        console.log(`   Description: ${model.description || "N/A"}`);
        console.log(
          `   Supported Methods: ${
            model.supportedGenerationMethods?.join(", ") || "N/A"
          }`
        );
        console.log(`   Input Token Limit: ${model.inputTokenLimit || "N/A"}`);
        console.log(
          `   Output Token Limit: ${model.outputTokenLimit || "N/A"}`
        );
      });

      console.log("\n" + "=".repeat(80));
      console.log("\n💡 Model name để dùng trong code (bỏ phần 'models/'):");
      data.models
        .filter((m) =>
          m.supportedGenerationMethods?.includes("generateContent")
        )
        .forEach((m) => {
          const modelName = m.name.replace("models/", "");
          console.log(`   - ${modelName}`);
        });
    } else {
      console.log("Không tìm thấy model nào");
    }
  } catch (error) {
    console.error("❌ Lỗi:", error.message);
  }
}

listModels();
