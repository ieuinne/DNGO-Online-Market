require("dotenv").config();
const { searchMonAn } = require("../src/repositories/chat.repo");

async function testSearch() {
  const testQueries = [
    "Đùi gà xốt kiểu Teriyaki",
    "đùi gà xốt kiểu teriyaki",
    "dui ga xot kieu teriyaki",
    "Đùi gà",
    "Teriyaki",
    "gà xốt",
  ];

  console.log("🧪 Testing search món ăn...\n");

  for (const query of testQueries) {
    console.log(`\n📝 Query: "${query}"`);
    try {
      const results = await searchMonAn(query);
      if (results.length > 0) {
        console.log(`✅ Tìm thấy ${results.length} món:`);
        results.forEach((m, i) => {
          console.log(`   ${i + 1}. ${m.ten_mon_an} (${m.ma_mon_an})`);
          if (m.calories) console.log(`      Calories: ${m.calories}`);
          if (m.nguyen_lieu && m.nguyen_lieu.length > 0) {
            console.log(`      Nguyên liệu: ${m.nguyen_lieu.length} loại`);
          }
        });
      } else {
        console.log(`❌ Không tìm thấy`);
      }
    } catch (err) {
      console.error(`❌ Lỗi:`, err.message);
    }
  }

  process.exit(0);
}

testSearch();
