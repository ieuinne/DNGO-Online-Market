const express = require("express");
const {
  upload,
  handleUploadError,
} = require("../middlewares/upload.middleware");
const { auth } = require("../middlewares/auth.middleware");
const ctr = require("../controllers/upload.controller");

const router = express.Router();

router.post(
  "/single",
  auth,
  upload.single("file"),
  handleUploadError,
  ctr.uploadSingle
);

router.post(
  "/multiple",
  auth,
  upload.array("files", 10),
  handleUploadError,
  ctr.uploadMultiple
);

module.exports = router;
