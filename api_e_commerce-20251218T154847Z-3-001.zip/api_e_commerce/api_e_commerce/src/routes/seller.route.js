const router = require("express").Router();
const { auth, allow } = require("../middlewares/auth.middleware");
const ctr = require("../controllers/seller.controller");
const schema = require("../validators/seller.schema");

const validate =
  (joiSchema, pick = "body", attach = "validated") =>
  (req, res, next) => {
    const { value, error } = joiSchema.validate(req[pick], {
      abortEarly: false,
      stripUnknown: true,
    });
    if (error)
      return res
        .status(400)
        .json({ message: "ValidationError", details: error.details });
    if (attach === "validated") req.validated = value;
    else if (attach === "validatedParams") req.params = value;
    next();
  };

router.use(auth, allow("nguoi_ban"));

router.get(
  "/products",
  validate(schema.listProductQuery, "query"),
  ctr.listProducts
);

router.post(
  "/products",
  validate(schema.addProductSchema, "body"),
  ctr.addProduct
);

router.patch(
  "/products/:ma_nguyen_lieu",
  validate(schema.updateProductParams, "params", "validatedParams"),
  validate(schema.updateProductSchema, "body"),
  ctr.updateProduct
);

router.delete(
  "/products/:ma_nguyen_lieu",
  validate(schema.deleteProductParams, "params", "validatedParams"),
  ctr.deleteProduct
);

module.exports = router;
