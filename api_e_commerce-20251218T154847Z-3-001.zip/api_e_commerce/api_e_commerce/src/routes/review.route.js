const router = require("express").Router();
const { auth, allow } = require("../middlewares/auth.middleware");
const ctrl = require("../controllers/review.controller");
const { prisma } = require("../../config/db");
const Joi = require("joi");

const validate =
  (schema, pick = "body", attach = "validated") =>
  (req, res, next) => {
    if (!schema) return next();
    const { value, error } = schema.validate(req[pick], {
      abortEarly: false,
      stripUnknown: true,
    });
    if (error)
      return res
        .status(400)
        .json({ message: "ValidationError", details: error.details });
    req[attach] = value;
    next();
  };

const ensureBuyer = async (req, res, next) => {
  try {
    if (!req.user?.ma_nguoi_dung) {
      return res.status(401).json({ success: false, message: "UNAUTHORIZED" });
    }
    if (req.user.ma_nguoi_mua) return next();

    const buyer = await prisma.nguoi_mua.findFirst({
      where: { ma_nguoi_dung: req.user.ma_nguoi_dung },
      select: { ma_nguoi_mua: true },
    });
    if (!buyer) {
      return res
        .status(403)
        .json({ success: false, message: "BUYER_PROFILE_NOT_FOUND" });
    }
    req.user.ma_nguoi_mua = buyer.ma_nguoi_mua;
    return next();
  } catch (e) {
    console.error("ensureBuyer error:", e);
    return res.status(500).json({ success: false, message: "Server error" });
  }
};

const createOrUpdateBody = Joi.object({
  ma_don_hang: Joi.string().required(),
  ma_nguyen_lieu: Joi.string().required(),
  ma_gian_hang: Joi.string().required(),
  rating: Joi.number().integer().min(1).max(5).required(),
  binh_luan: Joi.string().max(2000).allow(null, "").optional(),
});

const listParams = Joi.object({
  ma_gian_hang: Joi.string().required(),
});

const listQuery = Joi.object({
  ma_nguyen_lieu: Joi.string().optional(),
  skip: Joi.number().integer().min(0).default(0),
  take: Joi.number().integer().min(1).max(50).default(10),
  sort: Joi.string().valid("asc", "desc").default("desc"),
});

const mineQuery = Joi.object({
  ma_don_hang: Joi.string().optional(),
  ma_nguyen_lieu: Joi.string().optional(),
  ma_gian_hang: Joi.string().optional(),
}).or("ma_don_hang", "ma_nguyen_lieu");

const deleteParams = Joi.object({
  ma_danh_gia: Joi.string().required(),
});

// ================== ROUTES (prefix mount: /api/review) ==================

router.post(
  "/reviews",
  auth,
  allow("nguoi_mua"),
  ensureBuyer,
  validate(createOrUpdateBody),
  ctrl.createOrUpdate
);

router.get(
  "/stores/:ma_gian_hang/reviews",
  validate(listParams, "params"),
  validate(listQuery, "query"),
  ctrl.listByStore
);

router.get(
  "/my/reviews",
  auth,
  allow("nguoi_mua"),
  ensureBuyer,
  validate(mineQuery, "query"),
  ctrl.getMine
);

router.delete(
  "/reviews/:ma_danh_gia",
  auth,
  allow("nguoi_mua"),
  ensureBuyer,
  validate(deleteParams, "params"),
  ctrl.deleteMine
);

module.exports = router;
