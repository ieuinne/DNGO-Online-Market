const express = require("express");
const router = express.Router();
const { auth } = require("../middlewares/auth.middleware");
const searchController = require("../controllers/search.controller");

router.use(auth);

router.get("/", searchController.search);

module.exports = router;
