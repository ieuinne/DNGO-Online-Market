const router = require("express").Router();
const { auth, allow } = require("../middlewares/auth.middleware");

const validate =
  (joiSchema, pick = "query", attach = "validated") =>
  (req, res, next) => {
    if (!joiSchema) return next();
    const { value, error } = joiSchema.validate(req[pick], {
      abortEarly: false,
      stripUnknown: true,
    });
    if (error) {
      return res
        .status(400)
        .json({ message: "ValidationError", details: error.details });
    }
    if (pick === "params") req.params = value;
    else req[attach] = value;
    next();
  };

const ctr = require("../controllers/cart.controller");
const schema = require("../validators/cart.schema");

router.use(auth, allow("nguoi_mua"));

router.get("/", validate(schema.viewCartQuery, "query"), ctr.viewCart);

router.post("/items", validate(schema.addItemBody, "body"), ctr.addItem);

router.post(
  "/mon-an",
  validate(schema.addMonAnToCartBody, "body"),
  ctr.addMonAnToCart
);

router.patch(
  "/items/:ma_nguyen_lieu/:ma_gian_hang",
  validate(schema.updateItemParams, "params"),
  validate(schema.updateItemBody, "body"),
  ctr.updateItem
);

router.delete(
  "/items/:ma_nguyen_lieu/:ma_gian_hang",
  validate(schema.removeItemParams, "params"),
  ctr.removeItem
);

router.post("/checkout", validate(schema.checkoutBody, "body"), ctr.checkout);

module.exports = router;
