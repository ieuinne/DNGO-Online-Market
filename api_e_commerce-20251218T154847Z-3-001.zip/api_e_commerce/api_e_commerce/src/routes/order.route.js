const router = require("express").Router();
const { auth, allow } = require("../middlewares/auth.middleware");
const ctr = require("../controllers/order.controller");
const schema = require("../validators/order.schema");

const validate =
  (joiSchema, pick = "query", attach = "validated") =>
  (req, res, next) => {
    if (!joiSchema) return next();
    const { value, error } = joiSchema.validate(req[pick], {
      abortEarly: false,
      stripUnknown: true,
    });
    if (error) {
      return res.status(400).json({
        success: false,
        message: "ValidationError",
        details: error.details,
      });
    }
    if (pick === "params") req.params = value;
    else req[attach] = value;
    next();
  };

router.get(
  "/:ma_don_hang/shipper-status",
  auth,
  allow("nguoi_mua", "nguoi_ban"),
  ctr.checkShipperStatus
);

router.use(auth, allow("nguoi_mua"));

router.get("/", validate(schema.listOrdersQuery, "query"), ctr.listOrders);

router.get(
  "/:ma_don_hang",
  validate(schema.orderDetailParams, "params"),
  ctr.getOrderDetail
);

router.delete(
  "/:ma_don_hang",
  validate(schema.orderDetailParams, "params"),
  ctr.cancelOrder
);

module.exports = router;
