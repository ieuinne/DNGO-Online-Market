const router = require("express").Router();
const { auth, allow } = require("../middlewares/auth.middleware");
const ctr = require("../controllers/buyer.controller");
const schema = require("../validators/buyer.schema");

const validate =
  (joiSchema, pick = "query", attach = "validated") =>
  (req, res, next) => {
    const { value, error } = joiSchema.validate(req[pick], {
      abortEarly: false,
      stripUnknown: true,
    });
    if (error)
      return res
        .status(400)
        .json({ message: "ValidationError", details: error.details });
    if (attach === "validated") req.validated = value;
    else if (attach === "validatedQuery") req.validatedQuery = value;
    else if (attach === "validatedParams") req.params = value;
    next();
  };

router.use(auth, allow("nguoi_mua"));

router.get(
  "/khu-vuc",
  validate(schema.listKhuVucSchema, "query"),
  ctr.listKhuVuc
);

router.get("/cho", validate(schema.listChoSchema, "query"), ctr.listCho);

router.get(
  "/gian-hang",
  validate(schema.listGianHangQuery, "query"),
  ctr.listGianHang
);

router.get(
  "/gian-hang/:ma_gian_hang",
  validate(schema.gianHangDetailParams, "params"),
  validate(schema.gianHangDetailQuery, "query"),
  ctr.gianHangDetail
);

router.get(
  "/nguyen-lieu",
  validate(schema.listNguyenLieuQuery, "query"),
  ctr.listNguyenLieu
);

router.get(
  "/danh-muc-mon-an",
  validate(schema.listDanhMucMonAnQuery, "query"),
  ctr.listDanhMucMonAn
);

router.get(
  "/danh-muc-nguyen-lieu",
  validate(schema.listDanhMucNguyenLieuQuery, "query"),
  ctr.listDanhMucNguyenLieu
);

router.get(
  "/nguyen-lieu/:ma_nguyen_lieu",
  validate(schema.nguyenLieuDetailParams, "params"),
  validate(schema.nguyenLieuDetailQuery, "query"),
  ctr.nguyenLieuDetail
);

router.get("/mon-an", validate(schema.listMonAnQuery, "query"), ctr.listMonAn);

router.get(
  "/mon-an/:ma_mon_an",
  validate(schema.monAnDetailParams, "params"),
  validate(schema.monAnDetailQuery, "query"),
  ctr.monAnDetail
);

module.exports = router;
