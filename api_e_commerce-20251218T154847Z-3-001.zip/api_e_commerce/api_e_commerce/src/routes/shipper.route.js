const router = require("express").Router();
const { auth, allow } = require("../middlewares/auth.middleware");
const ctrl = require("../controllers/shipper.controller");
const validate = require("../middlewares/validate.middleware");
const {
  acceptOrderBody,
  updateOrderStatusBody,
  listOrdersQuery,
} = require("../validators/shipper.schema");

// ================== ROUTES (prefix mount: /api/shipper) ==================

router.get("/me", auth, allow("shipper"), ctrl.getMyInfo);

router.get("/khu-vuc", auth, allow("shipper"), ctrl.listKhuVuc);

router.get("/khung-gio", auth, allow("shipper"), ctrl.listKhungGio);

router.get(
  "/orders/available",
  auth,
  allow("shipper"),
  validate(listOrdersQuery, "query"),
  ctrl.listAvailableOrders
);

router.get(
  "/orders/my",
  auth,
  allow("shipper"),
  validate(listOrdersQuery, "query"),
  ctrl.listMyOrders
);

router.post(
  "/orders/accept",
  auth,
  allow("shipper"),
  validate(acceptOrderBody),
  ctrl.acceptOrder
);

router.patch(
  "/orders/:ma_don_hang/status",
  auth,
  allow("shipper"),
  validate(updateOrderStatusBody),
  ctrl.updateOrderStatus
);

module.exports = router;
