const router = require("express").Router();
const { auth } = require("../middlewares/auth.middleware");
const ctrl = require("../controllers/chat.controller");
const Joi = require("joi");

const validate =
  (schema, pick = "body", attach = "validated") =>
  (req, res, next) => {
    if (!schema) return next();
    const { value, error } = schema.validate(req[pick], {
      abortEarly: false,
      stripUnknown: true,
    });
    if (error)
      return res.status(400).json({
        success: false,
        message: "ValidationError",
        details: error.details,
      });
    req[attach] = value;
    next();
  };

const chatBodySchema = Joi.object({
  message: Joi.string().trim().min(1).max(1000).required(),
  conversation_id: Joi.string().optional(),
});

const monAnParamsSchema = Joi.object({
  ma_mon_an: Joi.string().required(),
});

const conversationParamsSchema = Joi.object({
  conversation_id: Joi.string().required(),
});

const listConversationsQuerySchema = Joi.object({
  skip: Joi.number().integer().min(0).optional(),
  take: Joi.number().integer().min(1).max(100).optional(),
});

// ================== ROUTES ==================

router.post("/chat", auth, validate(chatBodySchema), ctrl.chat);

router.get(
  "/mon-an/:ma_mon_an",
  auth,
  validate(monAnParamsSchema, "params"),
  ctrl.getMonAnDetail
);

router.post("/conversations", auth, ctrl.createConversation);

router.get(
  "/conversations",
  auth,
  validate(listConversationsQuerySchema, "query"),
  ctrl.listConversations
);

router.get(
  "/conversations/:conversation_id",
  auth,
  validate(conversationParamsSchema, "params"),
  ctrl.getConversation
);

router.delete(
  "/conversations/:conversation_id",
  auth,
  validate(conversationParamsSchema, "params"),
  ctrl.deleteConversation
);

module.exports = router;
