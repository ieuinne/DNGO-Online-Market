const router = require("express").Router();
const { auth, allow } = require("../middlewares/auth.middleware");
const ctr = require("../controllers/payment.controller");
const Joi = require("joi");

const vnpayCheckoutBody = Joi.object({
  ma_don_hang: Joi.string().required(),
  bankCode: Joi.string().optional(),
  thoi_gian_giao_hang: Joi.date().iso().optional(),
});

const validate =
  (schema, pick = "body", attach = "validated") =>
  (req, res, next) => {
    if (!schema) return next();
    const { value, error } = schema.validate(req[pick], {
      abortEarly: false,
      stripUnknown: true,
    });
    if (error)
      return res
        .status(400)
        .json({ message: "ValidationError", details: error.details });
    req[attach] = value;
    next();
  };

router.get("/methods", ctr.getPaymentMethods);

router.post(
  "/vnpay/checkout",
  auth,
  allow("nguoi_mua"),
  validate(vnpayCheckoutBody),
  ctr.vnpayCheckout
);

router.get("/vnpay/return", ctr.vnpayReturn);
router.get("/vnpay/ipn", ctr.vnpayIpn);
router.post("/vnpay/ipn", ctr.vnpayIpn);

module.exports = router;
