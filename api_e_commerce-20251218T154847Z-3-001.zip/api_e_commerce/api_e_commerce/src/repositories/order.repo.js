const { prisma } = require("../../config/db");
const paginate = require("../utils/paginate");
const { getOrCreateCart } = require("./cart.repo");

async function listOrdersRepo(ma_nguoi_dung, query) {
  const {
    page = 1,
    limit = 12,
    tinh_trang_don_hang,
    sort = "thoi_gian_giao_hang",
    order = "desc",
  } = query || {};

  const pageNum = parseInt(page, 10);
  const limitNum = parseInt(limit, 10);

  const buyer = await prisma.nguoi_mua.findFirst({
    where: { ma_nguoi_dung },
    select: { ma_nguoi_mua: true },
  });

  if (!buyer) {
    throw new Error("Buyer profile not found");
  }

  const where = {
    ma_nguoi_mua: buyer.ma_nguoi_mua,
  };

  if (tinh_trang_don_hang) {
    where.tinh_trang_don_hang = tinh_trang_don_hang;
  }

  const orderBy = {};
  orderBy[sort] = order === "asc" ? "asc" : "desc";

  const [total, items] = await Promise.all([
    prisma.don_hang.count({ where }),
    prisma.don_hang.findMany({
      where,
      orderBy,
      skip: (pageNum - 1) * limitNum,
      take: limitNum,
      select: {
        ma_don_hang: true,
        tong_tien: true,
        dia_chi_giao_hang: true,
        tinh_trang_don_hang: true,
        thoi_gian_giao_hang: true,
        ma_thanh_toan: true,
        thanh_toan: {
          select: {
            ma_thanh_toan: true,
            hinh_thuc_thanh_toan: true,
            tinh_trang_thanh_toan: true,
            thoi_gian_thanh_toan: true,
          },
        },
      },
    }),
  ]);

  if (items.length > 0) {
    console.log(
      `[Order List] Found ${items.length} orders, first order status: ${items[0].tinh_trang_don_hang}`
    );
  }

  return {
    items,
    total,
    page: pageNum,
    limit: limitNum,
    totalPages: Math.ceil(total / limitNum),
  };
}

async function getOrderDetailRepo(ma_don_hang, ma_nguoi_dung) {
  const buyer = await prisma.nguoi_mua.findFirst({
    where: { ma_nguoi_dung },
    select: { ma_nguoi_mua: true },
  });

  if (!buyer) {
    return null;
  }

  const order = await prisma.don_hang.findFirst({
    where: {
      ma_don_hang,
      ma_nguoi_mua: buyer.ma_nguoi_mua,
    },
    include: {
      thanh_toan: {
        select: {
          ma_thanh_toan: true,
          hinh_thuc_thanh_toan: true,
          tai_khoan_thanh_toan: true,
          thoi_gian_thanh_toan: true,
          tinh_trang_thanh_toan: true,
        },
      },
    },
  });

  if (!order) {
    return null;
  }

  console.log(
    `[Order Detail] Order ${ma_don_hang} status: ${order.tinh_trang_don_hang}`
  );

  const items = await prisma.chi_tiet_don_hang.findMany({
    where: { ma_don_hang },
  });

  const enrichedItems = await Promise.all(
    items.map(async (item) => {
      const product = await prisma.san_pham_ban.findUnique({
        where: {
          ma_nguyen_lieu_ma_gian_hang: {
            ma_nguyen_lieu: item.ma_nguyen_lieu,
            ma_gian_hang: item.ma_gian_hang,
          },
        },
        include: {
          nguyen_lieu: {
            select: {
              ma_nguyen_lieu: true,
              ten_nguyen_lieu: true,
              don_vi: true,
            },
          },
          gian_hang: {
            select: {
              ma_gian_hang: true,
              ten_gian_hang: true,
              vi_tri: true,
              hinh_anh: true,
            },
          },
        },
      });

      return {
        ma_nguyen_lieu: item.ma_nguyen_lieu,
        ma_gian_hang: item.ma_gian_hang,
        so_luong: item.so_luong,
        gia_cuoi: item.gia_cuoi,
        thanh_tien: item.thanh_tien,
        ma_mon_an: item.ma_mon_an,
        nguyen_lieu: product?.nguyen_lieu || null,
        gian_hang: product?.gian_hang || null,
        don_vi_ban: product?.don_vi_ban || null,
      };
    })
  );

  return {
    ...order,
    items: enrichedItems,
  };
}

async function checkShipperStatusRepo(ma_don_hang) {
  const gomDon = await prisma.gom_don.findFirst({
    where: { ma_don_hang },
    include: {
      shipper: {
        include: {
          nguoi_dung: {
            select: {
              ten_nguoi_dung: true,
              sdt: true,
            },
          },
        },
      },
      khu_vuc: {
        select: {
          ma_khu_vuc: true,
          phuong: true,
        },
      },
      khung_gio: {
        select: {
          ma_khung_gio: true,
          gio_bat_dau: true,
          gio_ket_thuc: true,
        },
      },
    },
  });

  if (!gomDon) {
    return null;
  }

  return {
    ma_gom_don: gomDon.ma_gom_don,
    shipper: {
      ma_shipper: gomDon.shipper.ma_shipper,
      ten_nguoi_dung: gomDon.shipper.nguoi_dung.ten_nguoi_dung,
      sdt: gomDon.shipper.nguoi_dung.sdt,
      phuong_tien: gomDon.shipper.phuong_tien,
      bien_so_xe: gomDon.shipper.bien_so_xe,
    },
    khu_vuc: {
      ma_khu_vuc: gomDon.khu_vuc.ma_khu_vuc,
      phuong: gomDon.khu_vuc.phuong,
    },
    khung_gio: {
      ma_khung_gio: gomDon.khung_gio.ma_khung_gio,
      gio_bat_dau: gomDon.khung_gio.gio_bat_dau,
      gio_ket_thuc: gomDon.khung_gio.gio_ket_thuc,
    },
  };
}

async function cancelOrderRepo(ma_don_hang, ma_nguoi_dung) {
  return prisma.$transaction(async (tx) => {
    const buyer = await tx.nguoi_mua.findFirst({
      where: { ma_nguoi_dung },
      select: { ma_nguoi_mua: true },
    });

    if (!buyer) {
      throw new Error("Buyer profile not found");
    }

    const order = await tx.don_hang.findFirst({
      where: {
        ma_don_hang,
        ma_nguoi_mua: buyer.ma_nguoi_mua,
      },
      select: {
        ma_don_hang: true,
        tinh_trang_don_hang: true,
        ma_thanh_toan: true,
      },
    });

    if (!order) {
      throw new Error(
        "Đơn hàng không tồn tại hoặc bạn không có quyền truy cập"
      );
    }

    if (order.tinh_trang_don_hang !== "chua_xac_nhan") {
      throw new Error(
        `Không thể hủy đơn hàng ở trạng thái "${order.tinh_trang_don_hang}". Chỉ có thể hủy đơn hàng chưa thanh toán.`
      );
    }

    const orderItems = await tx.chi_tiet_don_hang.findMany({
      where: { ma_don_hang },
      select: {
        ma_nguyen_lieu: true,
        ma_gian_hang: true,
        so_luong: true,
      },
    });

    if (orderItems.length === 0) {
      throw new Error("Đơn hàng không có sản phẩm nào");
    }

    const cart = await getOrCreateCart(ma_nguoi_dung, tx);

    const restoredItems = [];
    for (const item of orderItems) {
      const existingCartItem = await tx.chi_tiet_gio_hang.findFirst({
        where: {
          ma_gio_hang: cart.ma_gio_hang,
          ma_nguyen_lieu: item.ma_nguyen_lieu,
          ma_gian_hang: item.ma_gian_hang,
        },
      });

      if (existingCartItem) {
        await tx.chi_tiet_gio_hang.update({
          where: {
            ma_gio_hang_ma_nguyen_lieu_ma_gian_hang: {
              ma_gio_hang: cart.ma_gio_hang,
              ma_nguyen_lieu: item.ma_nguyen_lieu,
              ma_gian_hang: item.ma_gian_hang,
            },
          },
          data: {
            so_luong: existingCartItem.so_luong + item.so_luong,
          },
        });
      } else {
        await tx.chi_tiet_gio_hang.create({
          data: {
            ma_gio_hang: cart.ma_gio_hang,
            ma_nguyen_lieu: item.ma_nguyen_lieu,
            ma_gian_hang: item.ma_gian_hang,
            so_luong: item.so_luong,
          },
        });
      }

      restoredItems.push({
        ma_nguyen_lieu: item.ma_nguyen_lieu,
        ma_gian_hang: item.ma_gian_hang,
        so_luong: item.so_luong,
      });
    }

    await tx.gom_don.deleteMany({
      where: { ma_don_hang },
    });

    if (order.ma_thanh_toan) {
      await tx.thanh_toan.delete({
        where: { ma_thanh_toan: order.ma_thanh_toan },
      });
    }

    await tx.chi_tiet_don_hang.deleteMany({
      where: { ma_don_hang },
    });

    await tx.don_hang.delete({
      where: { ma_don_hang },
    });

    return {
      ma_don_hang,
      restored_items: restoredItems,
      so_mat_hang: restoredItems.length,
      message: "Đơn hàng đã được hủy và sản phẩm đã được khôi phục về giỏ hàng",
    };
  });
}

module.exports = {
  listOrdersRepo,
  getOrderDetailRepo,
  checkShipperStatusRepo,
  cancelOrderRepo,
};
