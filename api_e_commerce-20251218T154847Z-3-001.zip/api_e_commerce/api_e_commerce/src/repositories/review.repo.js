const { prisma } = require("../../config/db");
const { randomBytes } = require("crypto");

async function genReviewId() {
  const rand = randomBytes(6).toString("base64url").slice(0, 8).toUpperCase();
  return `DG${rand}`;
}

async function canReviewItem({
  maNguoiMua,
  maDonHang,
  maNguyenLieu,
  maGianHang,
  tx = prisma,
}) {
  const order = await tx.don_hang.findFirst({
    where: {
      ma_don_hang: maDonHang,
      ma_nguoi_mua: maNguoiMua,
      tinh_trang_don_hang: { in: ["da_giao", "hoan_thanh"] },
    },
    select: { ma_don_hang: true },
  });

  if (!order) return false;

  const detail = await tx.chi_tiet_don_hang.findFirst({
    where: {
      ma_don_hang: maDonHang,
      ma_nguyen_lieu: maNguyenLieu,
      ma_gian_hang: maGianHang,
    },
    select: { ma_don_hang: true },
  });

  return !!detail;
}

async function upsertReview({
  maNguoiMua,
  maDonHang,
  maNguyenLieu,
  maGianHang,
  rating,
  binh_luan,
}) {
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
    const err = new Error("INVALID_RATING");
    err.status = 400;
    throw err;
  }
  if (binh_luan && String(binh_luan).length > 2000) {
    const err = new Error("COMMENT_TOO_LONG");
    err.status = 400;
    throw err;
  }

  return prisma.$transaction(async (tx) => {
    const canReview = await canReviewItem({
      maNguoiMua,
      maDonHang,
      maNguyenLieu,
      maGianHang,
      tx,
    });
    if (!canReview) {
      const err = new Error("CANNOT_REVIEW");
      err.status = 403;
      err.message =
        "Chỉ có thể đánh giá nguyên liệu trong đơn hàng đã giao của bạn";
      throw err;
    }

    const existing = await tx.danh_gia.findFirst({
      where: {
        ma_nguoi_mua: maNguoiMua,
        ma_don_hang: maDonHang,
        ma_nguyen_lieu: maNguyenLieu,
        ma_gian_hang: maGianHang,
      },
      select: { ma_danh_gia: true },
    });

    let review;
    if (existing) {
      review = await tx.danh_gia.update({
        where: { ma_danh_gia: existing.ma_danh_gia },
        data: { rating, binh_luan, ngay_danh_gia: new Date() },
      });
    } else {
      review = await tx.danh_gia.create({
        data: {
          ma_danh_gia: await genReviewId(),
          ma_nguoi_mua: maNguoiMua,
          ma_don_hang: maDonHang,
          ma_nguyen_lieu: maNguyenLieu,
          ma_gian_hang: maGianHang,
          rating,
          binh_luan,
          ngay_danh_gia: new Date(),
        },
      });
    }

    const agg = await tx.danh_gia.aggregate({
      _avg: { rating: true },
      where: { ma_gian_hang: maGianHang, rating: { not: null } },
    });

    const danh_gia_tb = agg._avg.rating ?? 0;
    await tx.gian_hang.update({
      where: { ma_gian_hang: maGianHang },
      data: { danh_gia_tb },
    });

    return { review, danh_gia_tb };
  });
}

async function listReviewsByStore({
  maGianHang,
  maNguyenLieu,
  skip = 0,
  take = 10,
  sort = "desc",
}) {
  const where = { ma_gian_hang: maGianHang };
  if (maNguyenLieu) {
    where.ma_nguyen_lieu = maNguyenLieu;
  }

  const [items, total, store] = await prisma.$transaction([
    prisma.danh_gia.findMany({
      where,
      orderBy: { ngay_danh_gia: sort === "asc" ? "asc" : "desc" },
      skip: Number(skip) || 0,
      take: Math.min(Number(take) || 10, 50),
      include: {
        nguoi_mua: {
          include: { nguoi_dung: { select: { ten_nguoi_dung: true } } },
        },
        don_hang: {
          select: { ma_don_hang: true },
        },
      },
    }),
    prisma.danh_gia.count({ where }),
    prisma.gian_hang.findUnique({
      where: { ma_gian_hang: maGianHang },
      select: { danh_gia_tb: true },
    }),
  ]);

  const mapped = items.map((it) => ({
    ma_danh_gia: it.ma_danh_gia,
    ma_don_hang: it.ma_don_hang,
    ma_nguyen_lieu: it.ma_nguyen_lieu,
    rating: it.rating,
    binh_luan: it.binh_luan,
    ngay_danh_gia: it.ngay_danh_gia,
    nguoi_danh_gia: {
      ma_nguoi_mua: it.ma_nguoi_mua,
      ten_hien_thi: it.nguoi_mua?.nguoi_dung?.ten_nguoi_dung || "Người dùng",
    },
  }));

  return {
    items: mapped,
    total,
    avg: store?.danh_gia_tb ?? 0,
  };
}

async function getMyReview({
  maNguoiMua,
  maDonHang,
  maNguyenLieu,
  maGianHang,
}) {
  const where = {
    ma_nguoi_mua: maNguoiMua,
    ma_gian_hang: maGianHang,
  };
  if (maDonHang) where.ma_don_hang = maDonHang;
  if (maNguyenLieu) where.ma_nguyen_lieu = maNguyenLieu;

  return prisma.danh_gia.findFirst({
    where,
    include: {
      don_hang: {
        select: { ma_don_hang: true },
      },
    },
  });
}

async function listMyReviewsByOrder({ maNguoiMua, maDonHang }) {
  return prisma.danh_gia.findMany({
    where: {
      ma_nguoi_mua: maNguoiMua,
      ma_don_hang: maDonHang,
    },
    include: {
      don_hang: {
        select: { ma_don_hang: true },
      },
    },
  });
}

async function deleteMyReview({ maNguoiMua, maDanhGia }) {
  return prisma.$transaction(async (tx) => {
    const rv = await tx.danh_gia.findUnique({
      where: { ma_danh_gia: maDanhGia },
      select: { ma_danh_gia: true, ma_nguoi_mua: true, ma_gian_hang: true },
    });
    if (!rv) {
      const err = new Error("REVIEW_NOT_FOUND");
      err.status = 404;
      throw err;
    }
    if (rv.ma_nguoi_mua !== maNguoiMua) {
      const err = new Error("FORBIDDEN_REVIEW");
      err.status = 403;
      throw err;
    }

    await tx.danh_gia.delete({ where: { ma_danh_gia: maDanhGia } });

    const agg = await tx.danh_gia.aggregate({
      _avg: { rating: true },
      where: { ma_gian_hang: rv.ma_gian_hang },
    });
    const danh_gia_tb = agg._avg.rating ?? 0;
    await tx.gian_hang.update({
      where: { ma_gian_hang: rv.ma_gian_hang },
      data: { danh_gia_tb },
    });

    return { danh_gia_tb };
  });
}

module.exports = {
  upsertReview,
  listReviewsByStore,
  getMyReview,
  listMyReviewsByOrder,
  deleteMyReview,
};
