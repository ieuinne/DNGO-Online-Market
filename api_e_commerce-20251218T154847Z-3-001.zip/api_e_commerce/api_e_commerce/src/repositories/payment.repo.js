const crypto = require("crypto");
const dayjs = require("dayjs");
const utc = require("dayjs/plugin/utc");
const timezone = require("dayjs/plugin/timezone");
dayjs.extend(utc);
dayjs.extend(timezone);

const { prisma } = require("../../config/db");

const {
  VNP_TMN_CODE,
  VNP_HASH_SECRET: RAW_SECRET,
  VNP_URL,
  VNP_RETURN_URL,
  VNP_SECURE_HASH_TYPE,
} = process.env;

const HASH_TYPE = (VNP_SECURE_HASH_TYPE || "HMACSHA512").toUpperCase();

const VNP_HASH_SECRET = (RAW_SECRET || "")
  .replace(/["']/g, "")
  .replace(/\r?\n/g, "")
  .trim();

function randBase36(n) {
  let s = "";
  while (s.length < n) s += Math.random().toString(36).slice(2);
  return s.slice(0, n).toUpperCase();
}

function genTxnRefFixed(len = 10) {
  if (len <= 2) return randBase36(Math.max(4, len));
  return "TT" + randBase36(len - 2);
}

async function ensurePendingPayment(ma_don_hang, tx = prisma) {
  const order = await tx.don_hang.findUnique({
    where: { ma_don_hang },
    select: {
      ma_don_hang: true,
      tinh_trang_don_hang: true,
      tong_tien: true,
      thanh_toan: {
        select: { ma_thanh_toan: true, tinh_trang_thanh_toan: true },
      },
    },
  });
  if (!order) throw new Error("ORDER_NOT_FOUND");

  const locked =
    order.tinh_trang_don_hang !== "chua_xac_nhan" ||
    (order.thanh_toan &&
      order.thanh_toan.tinh_trang_thanh_toan === "da_thanh_toan");
  if (locked) throw new Error("ORDER_LOCKED");

  let pay = order.thanh_toan;

  if (!pay) {
    const ma_thanh_toan = genTxnRefFixed(10);
    pay = await tx.thanh_toan.create({
      data: {
        ma_thanh_toan,
        hinh_thuc_thanh_toan: "chuyen_khoan",
        tai_khoan_thanh_toan: "",
        tinh_trang_thanh_toan: "chua_thanh_toan",
        thoi_gian_thanh_toan: new Date(),
        don_hang: { connect: { ma_don_hang } },
      },
      select: { ma_thanh_toan: true, tinh_trang_thanh_toan: true },
    });
  } else if (pay.tinh_trang_thanh_toan === "chua_thanh_toan") {
    const currentLen = (pay.ma_thanh_toan || "").length || 10;
    const newTxnRef = genTxnRefFixed(currentLen);

    pay = await tx.thanh_toan.update({
      where: { ma_thanh_toan: pay.ma_thanh_toan },
      data: { ma_thanh_toan: newTxnRef },
      select: { ma_thanh_toan: true, tinh_trang_thanh_toan: true },
    });
  }

  return { order, pay };
}

function encPlus(v) {
  return encodeURIComponent(String(v).trim()).replace(/%20/g, "+");
}
function makeSignData(params) {
  const data = { ...params };
  delete data.vnp_SecureHash;
  delete data.vnp_SecureHashType;
  const keys = Object.keys(data).sort();
  return keys.map((k) => `${k}=${encPlus(data[k])}`).join("&");
}
function toQueryPlus(params) {
  const keys = Object.keys(params).sort();
  return keys.map((k) => `${k}=${encPlus(params[k])}`).join("&");
}
function computeHash(signData, secret, type) {
  switch ((type || "").toUpperCase()) {
    case "HMACSHA512":
      return crypto
        .createHmac("sha512", secret)
        .update(signData, "utf8")
        .digest("hex")
        .toUpperCase();
    case "HMACSHA256":
      return crypto
        .createHmac("sha256", secret)
        .update(signData, "utf8")
        .digest("hex")
        .toUpperCase();
    case "SHA256":
      return crypto
        .createHash("sha256")
        .update(String(secret) + String(signData), "utf8")
        .digest("hex")
        .toUpperCase();
    default:
      return crypto
        .createHmac("sha512", secret)
        .update(signData, "utf8")
        .digest("hex")
        .toUpperCase();
  }
}

function addMinutesYYYYMMDDHHmmss(base, minutes) {
  const d = dayjs(base, "YYYYMMDDHHmmss").add(minutes, "minute");
  return d.format("YYYYMMDDHHmmss");
}

async function buildVnpayUrl({ ma_don_hang, clientIp, bankCode }) {
  if (!VNP_TMN_CODE || !VNP_HASH_SECRET || !VNP_URL || !VNP_RETURN_URL) {
    throw new Error("VNPAY_ENV_MISSING");
  }

  const { order, pay } = await ensurePendingPayment(ma_don_hang);
  const amount = Number(order.tong_tien || 0);
  if (!Number.isFinite(amount) || amount <= 0) {
    throw new Error("ORDER_AMOUNT_INVALID");
  }

  const createDate = dayjs().tz("Asia/Ho_Chi_Minh").format("YYYYMMDDHHmmss");
  const expireDate = addMinutesYYYYMMDDHHmmss(createDate, 15);

  const params = {
    vnp_Version: "2.1.0",
    vnp_Command: "pay",
    vnp_TmnCode: VNP_TMN_CODE,
    vnp_Locale: "vn",
    vnp_CurrCode: "VND",
    vnp_TxnRef: String(pay.ma_thanh_toan),
    vnp_OrderInfo: `Thanh toan don ${ma_don_hang}`,
    vnp_OrderType: "other",
    vnp_Amount: String(Math.round(amount * 100)),
    vnp_ReturnUrl: VNP_RETURN_URL,
    vnp_IpAddr: (clientIp || "").split(",")[0].trim(),
    vnp_CreateDate: createDate,
    vnp_ExpireDate: expireDate,
  };
  if (bankCode) params.vnp_BankCode = bankCode;

  const signData = makeSignData(params);

  const vnp_SecureHash = computeHash(signData, VNP_HASH_SECRET, HASH_TYPE);

  const query = toQueryPlus({
    ...params,
    vnp_SecureHashType: HASH_TYPE,
    vnp_SecureHash,
  });
  const payUrl = `${VNP_URL}?${query}`;

  console.log("[VNP SIGNTYPE]", HASH_TYPE);
  console.log("[VNP SIGNDATA]", signData);
  console.log("[VNP HASH    ]", vnp_SecureHash);
  console.log("[VNP URL     ]", payUrl);

  return { payUrl, ma_thanh_toan: pay.ma_thanh_toan, amount };
}

module.exports = {
  buildVnpayUrl,
};
