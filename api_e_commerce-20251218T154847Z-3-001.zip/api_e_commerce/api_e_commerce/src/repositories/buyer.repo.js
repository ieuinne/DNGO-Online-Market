const { prisma } = require("./user.repo");
const paginate = require("../utils/paginate");

async function listKhuVucRepo(q) {
  const { page, limit, skip, take } = paginate(q);

  const SORT_MAP = {
    ten_khu_vuc: "phuong",
    phuong: "phuong",
    ma_khu_vuc: "ma_khu_vuc",
  };
  const sortField = SORT_MAP[q.sort] || "phuong";

  const where = q.search ? { phuong: { contains: q.search } } : {};
  const orderBy = { [sortField]: q.order || "asc" };

  const [rows, total] = await prisma.$transaction([
    prisma.khu_vuc.findMany({ where, skip, take, orderBy }),
    prisma.khu_vuc.count({ where }),
  ]);

  const ids = rows.map((r) => r.ma_khu_vuc);
  let countMap = new Map();
  if (ids.length) {
    const counts = await prisma.cho_table.groupBy({
      by: ["ma_khu_vuc"],
      where: { ma_khu_vuc: { in: ids } },
      _count: { ma_cho: true },
    });
    countMap = new Map(counts.map((c) => [c.ma_khu_vuc, c._count.ma_cho]));
  }

  return {
    data: rows.map((r) => ({
      ma_khu_vuc: r.ma_khu_vuc,
      phuong: r.phuong,
      longitude: r.longitude ?? null,
      latitude: r.latitude ?? null,
      so_cho: countMap.get(r.ma_khu_vuc) || 0,
    })),
    meta: { page, limit: take, total, hasNext: skip + take < total },
  };
}

async function listChoRepo(q) {
  const { page, limit, skip, take } = paginate(q);

  const where = {
    ...(q.ma_khu_vuc ? { ma_khu_vuc: q.ma_khu_vuc } : {}),
    ...(q.search
      ? {
          OR: [
            { ten_cho: { contains: q.search } },
            { dia_chi: { contains: q.search } },
            { khu_vuc: { contains: q.search } },
          ],
        }
      : {}),
  };

  const SORT_MAP = {
    ten_cho: "ten_cho",
    ma_cho: "ma_cho",
    dia_chi: "dia_chi",
    khu_vuc: "khu_vuc",
  };
  const sortField = SORT_MAP[q.sort] || "ten_cho";
  const orderBy = { [sortField]: q.order || "asc" };

  const [rows, total] = await prisma.$transaction([
    prisma.cho_table.findMany({
      where,
      skip,
      take,
      orderBy,
      include: {
        _count: { select: { gian_hang: true } },
      },
    }),
    prisma.cho_table.count({ where }),
  ]);

  return {
    data: rows.map((r) => ({
      ma_cho: r.ma_cho,
      ten_cho: r.ten_cho,
      ma_khu_vuc: r.ma_khu_vuc,
      ten_khu_vuc: r.khu_vuc,
      dia_chi: r.dia_chi,
      hinh_anh: r.hinh_anh,
      so_gian_hang: r._count?.gian_hang ?? 0,
    })),
    meta: { page, limit: take, total, hasNext: skip + take < total },
  };
}

async function listGianHangRepo(q) {
  const { page, limit, skip, take } = paginate(q);

  const where = {
    ...(q.ma_cho ? { ma_cho: q.ma_cho } : {}),
    ...(q.search
      ? {
          OR: [
            { ten_gian_hang: { contains: q.search } },
            { vi_tri: { contains: q.search } },
          ],
        }
      : {}),
  };

  const SORT_MAP = {
    ten_gian_hang: "ten_gian_hang",
    vi_tri: "vi_tri",
    danh_gia_tb: "danh_gia_tb",
    ma_gian_hang: "ma_gian_hang",
  };
  const sortField = SORT_MAP[q.sort] || "ten_gian_hang";
  const orderBy = { [sortField]: q.order || "asc" };

  const [rows, total] = await prisma.$transaction([
    prisma.gian_hang.findMany({
      where,
      skip,
      take,
      orderBy,
      select: {
        ma_gian_hang: true,
        ten_gian_hang: true,
        vi_tri: true,
        hinh_anh: true,
        danh_gia_tb: true,
        ma_cho: true,
      },
    }),
    prisma.gian_hang.count({ where }),
  ]);

  return {
    data: rows,
    meta: { page, limit: take, total, hasNext: skip + take < total },
  };
}

async function gianHangDetailRepo(q) {
  const { page, limit, skip, take } = paginate(q);
  const ma_gian_hang = q.ma_gian_hang;

  const gianHang = await prisma.gian_hang.findUnique({
    where: { ma_gian_hang },
    select: {
      ma_gian_hang: true,
      ten_gian_hang: true,
      vi_tri: true,
      hinh_anh: true,
      danh_gia_tb: true,
      ngay_dang_ky: true,
      ma_cho: true,
      cho_table: {
        select: {
          ma_cho: true,
          ten_cho: true,
          dia_chi: true,
          hinh_anh: true,
          ma_khu_vuc: true,
          khu_vuc: true,
        },
      },
    },
  });

  if (!gianHang) {
    return null;
  }

  let khuVucInfo = null;
  if (gianHang.cho_table?.ma_khu_vuc) {
    const khuVuc = await prisma.khu_vuc.findUnique({
      where: { ma_khu_vuc: gianHang.cho_table.ma_khu_vuc },
      select: {
        ma_khu_vuc: true,
        phuong: true,
      },
    });
    if (khuVuc) {
      khuVucInfo = {
        ma_khu_vuc: khuVuc.ma_khu_vuc,
        phuong: khuVuc.phuong,
      };
    }
  }

  const soSanPham = await prisma.san_pham_ban.count({
    where: { ma_gian_hang },
  });

  const soDanhGia = await prisma.danh_gia.count({
    where: { ma_gian_hang },
  });

  const whereSPB = {
    ma_gian_hang,
    ...(q.search
      ? {
          nguyen_lieu: {
            ten_nguyen_lieu: { contains: q.search },
          },
        }
      : {}),
  };

  const SORT_MAP = {
    ten_nguyen_lieu: "nguyen_lieu",
    gia_goc: "gia_goc",
    gia_cuoi: "gia_cuoi",
    so_luong_ban: "so_luong_ban",
    ngay_cap_nhat: "ngay_cap_nhat",
  };

  const sortField = SORT_MAP[q.sort] || "ngay_cap_nhat";
  let orderBy = {};

  if (sortField === "nguyen_lieu") {
    orderBy = { nguyen_lieu: { ten_nguyen_lieu: q.order || "asc" } };
  } else {
    orderBy = { [sortField]: q.order || "desc" };
  }

  const [sanPhamRows, sanPhamTotal] = await prisma.$transaction([
    prisma.san_pham_ban.findMany({
      where: whereSPB,
      skip,
      take,
      orderBy,
      select: {
        ma_nguyen_lieu: true,
        gia_goc: true,
        gia_cuoi: true,
        so_luong_ban: true,
        hinh_anh: true,
        don_vi_ban: true,
        phan_tram_giam_gia: true,
        ngay_cap_nhat: true,
        nguyen_lieu: {
          select: {
            ma_nguyen_lieu: true,
            ten_nguyen_lieu: true,
            don_vi: true,
            ma_nhom_nguyen_lieu: true,
            nhom_nguyen_lieu: {
              select: {
                ten_nhom_nguyen_lieu: true,
              },
            },
          },
        },
      },
    }),
    prisma.san_pham_ban.count({ where: whereSPB }),
  ]);

  return {
    detail: {
      ma_gian_hang: gianHang.ma_gian_hang,
      ten_gian_hang: gianHang.ten_gian_hang,
      vi_tri: gianHang.vi_tri,
      hinh_anh: gianHang.hinh_anh,
      danh_gia_tb: gianHang.danh_gia_tb,
      ngay_dang_ky: gianHang.ngay_dang_ky,
      so_san_pham: soSanPham,
      so_danh_gia: soDanhGia,
      cho: gianHang.cho_table
        ? {
            ma_cho: gianHang.cho_table.ma_cho,
            ten_cho: gianHang.cho_table.ten_cho,
            dia_chi: gianHang.cho_table.dia_chi,
            hinh_anh: gianHang.cho_table.hinh_anh,
            khu_vuc: khuVucInfo,
          }
        : null,
    },
    san_pham: {
      data: sanPhamRows.map((sp) => ({
        ma_nguyen_lieu: sp.ma_nguyen_lieu,
        ten_nguyen_lieu: sp.nguyen_lieu?.ten_nguyen_lieu || null,
        don_vi: sp.don_vi_ban || sp.nguyen_lieu?.don_vi || null,
        ma_nhom_nguyen_lieu: sp.nguyen_lieu?.ma_nhom_nguyen_lieu || null,
        ten_nhom_nguyen_lieu:
          sp.nguyen_lieu?.nhom_nguyen_lieu?.ten_nhom_nguyen_lieu || null,
        hinh_anh: sp.hinh_anh,
        gia_goc: sp.gia_goc,
        gia_cuoi: sp.gia_cuoi,
        so_luong_ban: sp.so_luong_ban,
        phan_tram_giam_gia: sp.phan_tram_giam_gia,
        ngay_cap_nhat: sp.ngay_cap_nhat,
      })),
      meta: {
        page,
        limit: take,
        total: sanPhamTotal,
        hasNext: skip + take < sanPhamTotal,
      },
    },
  };
}

async function listNguyenLieuRepo(q) {
  const { page, limit, skip, take } = paginate(q);

  const whereNL = {
    ...(q.search ? { ten_nguyen_lieu: { contains: q.search } } : {}),
    ...(q.ma_nhom_nguyen_lieu
      ? { ma_nhom_nguyen_lieu: q.ma_nhom_nguyen_lieu }
      : {}),
  };

  const whereSPBFilter = {
    ...(q.ma_gian_hang ? { ma_gian_hang: q.ma_gian_hang } : {}),
    ...(q.ma_cho ? { gian_hang: { ma_cho: q.ma_cho } } : {}),
  };

  if (q.hinh_anh === true || q.hinh_anh === "true") {
    whereSPBFilter.hinh_anh = { gt: "" };
  }

  const hasSPBFilter = Object.keys(whereSPBFilter).length > 0;

  const SORT_MAP = {
    ten_nguyen_lieu: "ten_nguyen_lieu",
    ma_nguyen_lieu: "ma_nguyen_lieu",
  };
  const sortField = SORT_MAP[q.sort] || "ten_nguyen_lieu";
  const orderBy = { [sortField]: q.order || "asc" };

  const [rowsNL, total] = await prisma.$transaction([
    prisma.nguyen_lieu.findMany({
      where: {
        ...whereNL,
        ...(hasSPBFilter ? { san_pham_ban: { some: whereSPBFilter } } : {}),
      },
      skip,
      take,
      orderBy,
      select: {
        ma_nguyen_lieu: true,
        ten_nguyen_lieu: true,
        don_vi: true,
        ma_nhom_nguyen_lieu: true,
        nhom_nguyen_lieu: { select: { ten_nhom_nguyen_lieu: true } },
      },
    }),
    prisma.nguyen_lieu.count({
      where: {
        ...whereNL,
        ...(hasSPBFilter ? { san_pham_ban: { some: whereSPBFilter } } : {}),
      },
    }),
  ]);

  const ids = rowsNL.map((x) => x.ma_nguyen_lieu);
  if (ids.length === 0) {
    return { data: [], meta: { page, limit: take, total, hasNext: false } };
  }

  const whereSPB = { ma_nguyen_lieu: { in: ids }, ...whereSPBFilter };

  const spbDistinct = await prisma.san_pham_ban.findMany({
    where: whereSPB,
    distinct: ["ma_nguyen_lieu", "ma_gian_hang"],
    select: { ma_nguyen_lieu: true, ma_gian_hang: true },
  });
  const sellerCount = new Map();
  for (const r of spbDistinct) {
    sellerCount.set(
      r.ma_nguyen_lieu,
      (sellerCount.get(r.ma_nguyen_lieu) || 0) + 1
    );
  }

  const latest = await prisma.san_pham_ban.findMany({
    where: whereSPB,
    orderBy: [{ ma_nguyen_lieu: "asc" }, { ngay_cap_nhat: "desc" }],
    select: {
      ma_nguyen_lieu: true,
      hinh_anh: true,
      ngay_cap_nhat: true,
      don_vi_ban: true,
      gia_goc: true,
      gia_cuoi: true,
    },
  });
  const latestMap = new Map();
  for (const row of latest) {
    if (!latestMap.has(row.ma_nguyen_lieu))
      latestMap.set(row.ma_nguyen_lieu, row);
  }

  let data = rowsNL.map((nl) => {
    const l = latestMap.get(nl.ma_nguyen_lieu);

    const don_vi_hien_thi = (l?.don_vi_ban || nl.don_vi) ?? null;

    return {
      ma_nguyen_lieu: nl.ma_nguyen_lieu,
      ten_nguyen_lieu: nl.ten_nguyen_lieu,
      don_vi: don_vi_hien_thi,
      ma_nhom_nguyen_lieu: nl.ma_nhom_nguyen_lieu,
      ten_nhom_nguyen_lieu: nl.nhom_nguyen_lieu?.ten_nhom_nguyen_lieu ?? null,
      so_gian_hang: sellerCount.get(nl.ma_nguyen_lieu) || 0,
      gia_goc: l?.gia_goc ?? null,
      gia_cuoi: l?.gia_cuoi ?? null,
      ngay_cap_nhat: l?.ngay_cap_nhat ?? null,
      hinh_anh: l?.hinh_anh ?? null,
    };
  });

  return {
    data,
    meta: { page, limit: take, total, hasNext: skip + take < total },
  };
}

async function listDanhMucNguyenLieuRepo(q) {
  const { page, limit, skip, take } = paginate(q);

  const where = q.search
    ? { ten_nhom_nguyen_lieu: { contains: q.search } }
    : {};
  const orderBy = { [q.sort || "ten_nhom_nguyen_lieu"]: q.order || "asc" };

  const [rows, total] = await prisma.$transaction([
    prisma.nhom_nguyen_lieu.findMany({
      where,
      skip,
      take,
      orderBy,
      include: { _count: { select: { nguyen_lieu: true } } },
    }),
    prisma.nhom_nguyen_lieu.count({ where }),
  ]);

  return {
    data: rows.map((r) => ({
      ma_nhom_nguyen_lieu: r.ma_nhom_nguyen_lieu,
      ten_nhom_nguyen_lieu: r.ten_nhom_nguyen_lieu,
      so_nguyen_lieu: r._count?.nguyen_lieu ?? 0,
    })),
    meta: { page, limit: take, total, hasNext: skip + take < total },
  };
}

async function listDanhMucMonAnRepo(q) {
  const { page, limit, skip, take } = paginate(q);

  const where = q.search ? { ten_danh_muc_mon_an: { contains: q.search } } : {};
  const orderBy = { [q.sort || "ten_danh_muc_mon_an"]: q.order || "asc" };

  const [rows, total] = await prisma.$transaction([
    prisma.danh_muc_mon_an.findMany({
      where,
      skip,
      take,
      orderBy,
      include: { _count: { select: { phan_loai_mon_an: true } } },
    }),
    prisma.danh_muc_mon_an.count({ where }),
  ]);

  return {
    data: rows.map((r) => ({
      ma_danh_muc_mon_an: r.ma_danh_muc_mon_an,
      ten_danh_muc_mon_an: r.ten_danh_muc_mon_an,
      so_mon_an: r._count?.phan_loai_mon_an ?? 0,
    })),
    meta: { page, limit: take, total, hasNext: skip + take < total },
  };
}

async function listMonAnOnlyRepo(q) {
  const { page, limit, skip, take } = paginate(q);

  const where = {
    ...(q.search ? { ten_mon_an: { contains: q.search } } : {}),
    ...(q.ma_danh_muc_mon_an
      ? {
          phan_loai_mon_an: {
            some: { ma_danh_muc_mon_an: q.ma_danh_muc_mon_an },
          },
        }
      : {}),
  };

  if (q.hinh_anh === true || q.hinh_anh === "true") {
    where.hinh_anh = { gt: "" };
  }
  const orderBy = { [q.sort || "ten_mon_an"]: q.order || "asc" };

  const [rows, total] = await prisma.$transaction([
    prisma.mon_an.findMany({
      where,
      skip,
      take,
      orderBy,
      select: {
        ma_mon_an: true,
        ten_mon_an: true,
        hinh_anh: true,
        phan_loai_mon_an: {
          select: {
            danh_muc_mon_an: {
              select: { ma_danh_muc_mon_an: true, ten_danh_muc_mon_an: true },
            },
          },
        },
      },
    }),
    prisma.mon_an.count({ where }),
  ]);

  let data = rows.map((r) => ({
    ma_mon_an: r.ma_mon_an,
    ten_mon_an: r.ten_mon_an,
    hinh_anh: r.hinh_anh,
    danh_muc: (r.phan_loai_mon_an || []).map((x) => ({
      ma_danh_muc_mon_an: x.danh_muc_mon_an?.ma_danh_muc_mon_an,
      ten_danh_muc_mon_an: x.danh_muc_mon_an?.ten_danh_muc_mon_an,
    })),
  }));

  if (q.hinh_anh === true || q.hinh_anh === "true") {
    data = data.filter((item) => item.hinh_anh && item.hinh_anh.trim() !== "");
  }

  return {
    data,
    meta: { page, limit: take, total, hasNext: skip + take < total },
  };
}

async function nguyenLieuDetailRepo(q) {
  const { page, limit, skip, take } = paginate(q);
  const id = q.ma_nguyen_lieu;

  const nl = await prisma.nguyen_lieu.findUnique({
    where: { ma_nguyen_lieu: id },
    select: {
      ma_nguyen_lieu: true,
      ten_nguyen_lieu: true,
      don_vi: true,
      ma_nhom_nguyen_lieu: true,
      nhom_nguyen_lieu: { select: { ten_nhom_nguyen_lieu: true } },
    },
  });
  if (!nl) {
    return null;
  }

  const whereSPBFilter = {
    ma_nguyen_lieu: id,
    ...(q.ma_cho ? { gian_hang: { ma_cho: q.ma_cho } } : {}),
  };

  const soGianHangDistinctRows = await prisma.san_pham_ban.findMany({
    where: whereSPBFilter,
    distinct: ["ma_gian_hang"],
    select: { ma_gian_hang: true },
  });

  const latest = await prisma.san_pham_ban.findFirst({
    where: whereSPBFilter,
    orderBy: [{ ngay_cap_nhat: "desc" }],
    select: {
      hinh_anh: true,
      ngay_cap_nhat: true,
      gia_goc: true,
      gia_cuoi: true,
      don_vi_ban: true,
    },
  });

  const spbLatestPerShop = await prisma.san_pham_ban.findMany({
    where: whereSPBFilter,
    orderBy: [{ ma_gian_hang: "asc" }, { ngay_cap_nhat: "desc" }],
    select: {
      ma_gian_hang: true,
      gia_goc: true,
      gia_cuoi: true,
      hinh_anh: true,
      ngay_cap_nhat: true,
      so_luong_ban: true,
      don_vi_ban: true,
      gian_hang: {
        select: {
          ma_gian_hang: true,
          ten_gian_hang: true,
          vi_tri: true,
          ma_cho: true,
        },
      },
    },
  });

  const seen = new Set();
  const sellersAll = [];
  for (const r of spbLatestPerShop) {
    if (!seen.has(r.ma_gian_hang)) {
      seen.add(r.ma_gian_hang);
      sellersAll.push({
        ma_gian_hang: r.ma_gian_hang,
        ten_gian_hang: r.gian_hang?.ten_gian_hang || null,
        vi_tri: r.gian_hang?.vi_tri || null,
        ma_cho: r.gian_hang?.ma_cho || null,
        gia_goc: r.gia_goc ?? null,
        gia_cuoi: r.gia_cuoi ?? null,
        hinh_anh: r.hinh_anh || null,
        ngay_cap_nhat: r.ngay_cap_nhat,
        so_luong_ban: r.so_luong_ban ?? null,
        don_vi_ban: r.don_vi_ban ?? null,
      });
    }
  }

  const sortKey = q.sort || "ngay_cap_nhat";
  const order = (q.order || "desc").toLowerCase() === "asc" ? 1 : -1;
  sellersAll.sort((a, b) => {
    if (a[sortKey] == null && b[sortKey] == null) return 0;
    if (a[sortKey] == null) return 1;
    if (b[sortKey] == null) return -1;
    return a[sortKey] > b[sortKey]
      ? order
      : a[sortKey] < b[sortKey]
      ? -order
      : 0;
  });
  const sellersPage = sellersAll.slice(skip, skip + take);

  const don_vi_hien_thi = (latest?.don_vi_ban || nl.don_vi) ?? null;

  return {
    detail: {
      ma_nguyen_lieu: nl.ma_nguyen_lieu,
      ten_nguyen_lieu: nl.ten_nguyen_lieu,
      don_vi: don_vi_hien_thi,
      ma_nhom_nguyen_lieu: nl.ma_nhom_nguyen_lieu,
      ten_nhom_nguyen_lieu: nl.nhom_nguyen_lieu?.ten_nhom_nguyen_lieu ?? null,

      so_gian_hang: soGianHangDistinctRows.length,
      gia_goc: latest?.gia_goc ?? null,
      gia_cuoi: latest?.gia_cuoi ?? null,

      ngay_cap_nhat_moi_nhat: latest?.ngay_cap_nhat ?? null,
      hinh_anh_moi_nhat: latest?.hinh_anh ?? null,
    },
    sellers: {
      data: sellersPage,
      meta: {
        page,
        limit: take,
        total: sellersAll.length,
        hasNext: skip + take < sellersAll.length,
      },
    },
  };
}

async function monAnDetailRepo(q) {
  const id = q.ma_mon_an;

  const mon = await prisma.mon_an.findUnique({
    where: { ma_mon_an: id },
    select: {
      ma_mon_an: true,
      ten_mon_an: true,
      hinh_anh: true,
      khoang_thoi_gian: true,
      do_kho: true,
      khau_phan_tieu_chuan: true,
      cach_thuc_hien: true,
      so_che: true,
      cach_dung: true,
      calories: true,
      phan_loai_mon_an: {
        select: {
          danh_muc_mon_an: {
            select: {
              ma_danh_muc_mon_an: true,
              ten_danh_muc_mon_an: true,
            },
          },
        },
      },
    },
  });

  if (!mon) return null;

  const standardServings = mon.khau_phan_tieu_chuan || 1;

  const requestedServingsRaw = q.khau_phan;
  const requestedServings =
    typeof requestedServingsRaw === "number" && requestedServingsRaw > 0
      ? requestedServingsRaw
      : standardServings;

  const factor = requestedServings / standardServings;

  const caloriesBase = mon.calories || null;
  const caloriesPerServing =
    caloriesBase && standardServings ? caloriesBase / standardServings : null;
  const caloriesTotal =
    caloriesPerServing && requestedServings
      ? caloriesPerServing * requestedServings
      : caloriesBase;

  const congThuc = await prisma.cong_thuc_mon_an.findMany({
    where: { ma_mon_an: id },
    orderBy: [{ ma_nguyen_lieu: "asc" }],
    select: {
      ma_nguyen_lieu: true,
      dinh_luong: true,
      ten_nguyen_lieu: true,
      nguyen_lieu: {
        select: {
          ma_nguyen_lieu: true,
          ten_nguyen_lieu: true,
          don_vi: true,
        },
      },
    },
  });

  const danh_muc = (mon.phan_loai_mon_an || []).map((x) => ({
    ma_danh_muc_mon_an: x.danh_muc_mon_an?.ma_danh_muc_mon_an,
    ten_danh_muc_mon_an: x.danh_muc_mon_an?.ten_danh_muc_mon_an,
  }));

  const allNguyenLieuIds = congThuc
    .map((c) => c.nguyen_lieu?.ma_nguyen_lieu)
    .filter(Boolean);

  const sanPhamBan =
    allNguyenLieuIds.length > 0
      ? await prisma.san_pham_ban.findMany({
          where: {
            ma_nguyen_lieu: { in: allNguyenLieuIds },
          },
          orderBy: [{ ma_nguyen_lieu: "asc" }, { ngay_cap_nhat: "desc" }],
          select: {
            ma_nguyen_lieu: true,
            ma_gian_hang: true,
            don_vi_ban: true,
            hinh_anh: true,
            gia_goc: true,
            gia_cuoi: true,
            so_luong_ban: true,
            gian_hang: {
              select: {
                ma_gian_hang: true,
                ten_gian_hang: true,
                ma_cho: true,
              },
            },
          },
        })
      : [];

  const donViBanMap = new Map();
  const nguyenLieuInfoMap = new Map();
  for (const spb of sanPhamBan) {
    if (!donViBanMap.has(spb.ma_nguyen_lieu) && spb.don_vi_ban) {
      donViBanMap.set(spb.ma_nguyen_lieu, spb.don_vi_ban);
    }
    if (!nguyenLieuInfoMap.has(spb.ma_nguyen_lieu)) {
      nguyenLieuInfoMap.set(spb.ma_nguyen_lieu, {
        hinh_anh: spb.hinh_anh || null,
        gia_goc: spb.gia_goc ?? null,
        gia_cuoi: spb.gia_cuoi ?? null,
        so_luong_ban: spb.so_luong_ban ?? null,
        gian_hang: [],
      });
    }
    const info = nguyenLieuInfoMap.get(spb.ma_nguyen_lieu);
    if (
      spb.gian_hang &&
      !info.gian_hang.find((gh) => gh.ma_gian_hang === spb.ma_gian_hang)
    ) {
      info.gian_hang.push({
        ma_gian_hang: spb.gian_hang.ma_gian_hang,
        ten_gian_hang: spb.gian_hang.ten_gian_hang || null,
        ma_cho: spb.gian_hang.ma_cho || null,
      });
    }
  }

  const nguyen_lieu = (congThuc || [])
    .map((c) => {
      const maNL = c.nguyen_lieu?.ma_nguyen_lieu;
      const don_vi_ban = maNL ? donViBanMap.get(maNL) : null;
      const don_vi_goc = c.nguyen_lieu?.don_vi || null;
      const don_vi_hien_thi = (don_vi_ban || don_vi_goc) ?? null;

      const dinh_luong_raw = c.dinh_luong || null;
      let dinh_luong_cleaned = dinh_luong_raw
        ? dinh_luong_raw.trim().replace(/\r\n?/g, "").trim()
        : null;

      if (dinh_luong_cleaned && factor !== 1) {
        const match = dinh_luong_cleaned.match(
          /^(\d+(?:\.\d+)?)\s*\/\s*(\d+)|^(\d+(?:\.\d+)?)/
        );
        if (match) {
          let value;
          if (match[1] && match[2]) {
            value = parseFloat(match[1]) / parseFloat(match[2]);
          } else {
            value = parseFloat(match[3] || match[1]);
          }

          if (!isNaN(value)) {
            const scaledValue = Math.round(value * factor);
            const unitMatch = dinh_luong_cleaned.match(/([a-zA-ZÀ-ỹ]+)$/);
            const unit = unitMatch ? unitMatch[1] : "";
            dinh_luong_cleaned = unit
              ? `${scaledValue}${unit}`
              : scaledValue.toString();
          }
        }
      }

      const nguyenLieuInfo = maNL ? nguyenLieuInfoMap.get(maNL) : null;

      return {
        ma_nguyen_lieu: maNL,
        ten_nguyen_lieu:
          c.ten_nguyen_lieu || c.nguyen_lieu?.ten_nguyen_lieu || null,
        don_vi_goc: don_vi_hien_thi,
        dinh_luong: dinh_luong_cleaned,
        hinh_anh: nguyenLieuInfo?.hinh_anh || null,
        gia_goc: nguyenLieuInfo?.gia_goc ?? null,
        gia_cuoi: nguyenLieuInfo?.gia_cuoi ?? null,
        so_luong_ban: nguyenLieuInfo?.so_luong_ban ?? null,
        so_gian_hang: nguyenLieuInfo?.gian_hang?.length || 0,
        gian_hang: nguyenLieuInfo?.gian_hang || [],
      };
    })
    .filter((nl) => nl.dinh_luong !== null && nl.dinh_luong !== "");

  return {
    detail: {
      ma_mon_an: mon.ma_mon_an,
      ten_mon_an: mon.ten_mon_an,
      hinh_anh: mon.hinh_anh || null,
      khoang_thoi_gian: mon.khoang_thoi_gian || null,
      do_kho: mon.do_kho || null,

      khau_phan_tieu_chuan: standardServings,
      khau_phan_hien_tai: requestedServings,

      calories_goc: caloriesBase,
      calories_moi_khau_phan: caloriesPerServing,
      calories_tong_theo_khau_phan: caloriesTotal,

      calories: caloriesBase,

      cach_thuc_hien: mon.cach_thuc_hien || null,
      so_che: mon.so_che || null,
      cach_dung: mon.cach_dung || null,

      so_danh_muc: danh_muc.length,
      so_nguyen_lieu: nguyen_lieu.length,
      danh_muc,
      nguyen_lieu,
    },
  };
}

module.exports = {
  listKhuVucRepo,
  listChoRepo,
  listGianHangRepo,
  gianHangDetailRepo,
  listDanhMucMonAnRepo,
  listDanhMucNguyenLieuRepo,
  listNguyenLieuRepo,
  listMonAnOnlyRepo,
  nguyenLieuDetailRepo,
  monAnDetailRepo,
};
