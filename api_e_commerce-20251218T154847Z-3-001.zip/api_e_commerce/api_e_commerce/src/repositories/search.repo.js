const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

const searchAll = async (query) => {
  try {
    const searchTerm = `%${query}%`;

    const gianHangResults = await prisma.$queryRaw`
      SELECT 
        ma_gian_hang as id,
        ten_gian_hang as name,
        'stall' as type,
        hinh_anh as image
      FROM gian_hang 
      WHERE ten_gian_hang LIKE ${searchTerm}
      LIMIT 5`;

    const monAnResults = await prisma.$queryRaw`
      SELECT 
        ma_mon_an as id,
        ten_mon_an as name,
        'dish' as type,
        hinh_anh as image
      FROM mon_an 
      WHERE ten_mon_an LIKE ${searchTerm}
      LIMIT 5`;

    const nguyenLieuResults = await prisma.$queryRaw`
      SELECT 
        ma_nguyen_lieu as id,
        ten_nguyen_lieu as name,
        'ingredient' as type,
        NULL as image
      FROM nguyen_lieu 
      WHERE ten_nguyen_lieu LIKE ${searchTerm}
      LIMIT 5`;

    return {
      stalls: gianHangResults,
      dishes: monAnResults,
      ingredients: nguyenLieuResults,
    };
  } catch (error) {
    console.error("Search error:", error);
    throw new Error("Error performing search");
  }
};

module.exports = {
  searchAll,
};
