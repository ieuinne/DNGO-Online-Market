const { prisma } = require("./user.repo");
const { v4: uuidv4 } = require("uuid");

const conversationStore = new Map();

function createConversation(userId) {
  const conversationId = uuidv4();
  const now = new Date();

  conversationStore.set(conversationId, {
    conversation_id: conversationId,
    user_id: userId,
    messages: [],
    created_at: now,
    updated_at: now,
  });

  return conversationStore.get(conversationId);
}

function getConversation(conversationId, userId) {
  const conversation = conversationStore.get(conversationId);

  if (!conversation) {
    return null;
  }

  if (conversation.user_id !== userId) {
    return null;
  }

  return conversation;
}

function listConversations(userId, skip = 0, take = 20) {
  const conversations = Array.from(conversationStore.values())
    .filter((conv) => conv.user_id === userId)
    .sort((a, b) => b.updated_at - a.updated_at)
    .slice(skip, skip + take)
    .map((conv) => ({
      conversation_id: conv.conversation_id,
      created_at: conv.created_at,
      updated_at: conv.updated_at,
      message_count: conv.messages.length,
      last_message: conv.messages[conv.messages.length - 1] || null,
    }));

  return conversations;
}

function addMessageToConversation(conversationId, role, content, userId) {
  const conversation = conversationStore.get(conversationId);

  if (!conversation) {
    return null;
  }

  if (conversation.user_id !== userId) {
    return null;
  }

  const message = {
    role,
    content,
    timestamp: new Date(),
  };

  conversation.messages.push(message);
  conversation.updated_at = new Date();

  return message;
}

function getConversationHistory(conversationId, userId, limit = 20) {
  const conversation = getConversation(conversationId, userId);

  if (!conversation) {
    return [];
  }

  const messages = conversation.messages.slice(-limit);

  return messages.map((msg) => ({
    role: msg.role === "user" ? "user" : "model",
    parts: [{ text: msg.content }],
  }));
}

function deleteConversation(conversationId, userId) {
  const conversation = conversationStore.get(conversationId);

  if (!conversation) {
    return false;
  }

  if (conversation.user_id !== userId) {
    return false;
  }

  return conversationStore.delete(conversationId);
}

function deleteAllUserConversations(userId) {
  let deleted = 0;
  for (const [id, conv] of conversationStore.entries()) {
    if (conv.user_id === userId) {
      conversationStore.delete(id);
      deleted++;
    }
  }
  return deleted;
}

function removeVietnameseTones(str) {
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
  str = str.replace(/đ/g, "d");
  str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "A");
  str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "E");
  str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "I");
  str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "O");
  str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "U");
  str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "Y");
  str = str.replace(/Đ/g, "D");
  return str;
}

async function searchMonAn(keywords) {
  const stopWords = new Set([
    "cách",
    "làm",
    "món",
    "ăn",
    "và",
    "mua",
    "nguyên",
    "liệu",
    "món này",
    "xốt",
    "kiểu",
    "của",
    "cho",
    "tôi",
    "muốn",
    "biết",
    "về",
    "gì",
    "nào",
  ]);

  const searchTerms = keywords
    .toLowerCase()
    .split(/\s+/)
    .filter((t) => t.length > 0 && !stopWords.has(t));

  if (searchTerms.length === 0) return [];

  let maMonAnList = [];

  const sortedTerms = [...searchTerms].sort((a, b) => b.length - a.length);

  const whereAllTerms = {
    AND: sortedTerms.map((term) => ({
      ten_mon_an: { contains: term },
    })),
  };
  const exactResults = await prisma.mon_an.findMany({
    where: whereAllTerms,
    take: 20,
    select: { ma_mon_an: true },
  });
  maMonAnList = exactResults.map((r) => r.ma_mon_an);

  if (maMonAnList.length === 0 && sortedTerms.length > 1) {
    const importantTerm = sortedTerms[0];
    const otherTerms = sortedTerms.slice(1);

    const whereImportant = {
      AND: [
        { ten_mon_an: { contains: importantTerm } },
        {
          OR: otherTerms.map((term) => ({
            ten_mon_an: { contains: term },
          })),
        },
      ],
    };
    const importantResults = await prisma.mon_an.findMany({
      where: whereImportant,
      take: 20,
      select: { ma_mon_an: true },
    });
    maMonAnList = importantResults.map((r) => r.ma_mon_an);
  }

  if (maMonAnList.length === 0) {
    const whereContains = {
      OR: sortedTerms.map((term) => ({
        ten_mon_an: { contains: term },
      })),
    };
    const prismaResults = await prisma.mon_an.findMany({
      where: whereContains,
      take: 50,
      select: { ma_mon_an: true },
    });
    const matchCount = new Map();
    prismaResults.forEach((r) => {
      const count = sortedTerms.filter((term) =>
        r.ma_mon_an.toLowerCase().includes(term)
      ).length;
      matchCount.set(r.ma_mon_an, count);
    });
    maMonAnList = Array.from(matchCount.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 20)
      .map(([ma]) => ma);
  }

  if (maMonAnList.length === 0 && searchTerms.length > 0) {
    const noToneTerms = searchTerms.map((t) => removeVietnameseTones(t));
    const searchPattern = `%${noToneTerms.join("%")}%`;

    try {
      const noToneResults = await prisma.$queryRawUnsafe(
        `SELECT ma_mon_an FROM mon_an WHERE LOWER(ten_mon_an) LIKE LOWER(?) LIMIT 20`,
        searchPattern
      );

      if (noToneResults && noToneResults.length > 0) {
        maMonAnList = noToneResults.map((r) => r.ma_mon_an);
      }
    } catch (err) {
      console.warn("Raw SQL search error:", err.message);
    }
  }

  if (maMonAnList.length === 0 && searchTerms.length > 1) {
    for (const term of searchTerms) {
      const whereSingle = {
        ten_mon_an: { contains: term },
      };
      const singleResults = await prisma.mon_an.findMany({
        where: whereSingle,
        take: 10,
        select: { ma_mon_an: true },
      });
      singleResults.forEach((r) => {
        if (!maMonAnList.includes(r.ma_mon_an)) {
          maMonAnList.push(r.ma_mon_an);
        }
      });
    }
  }

  if (maMonAnList.length === 0) return [];

  const where = {
    ma_mon_an: { in: maMonAnList },
  };

  const monAn = await prisma.mon_an.findMany({
    where,
    take: 10,
    select: {
      ma_mon_an: true,
      ten_mon_an: true,
      hinh_anh: true,
      khoang_thoi_gian: true,
      do_kho: true,
      khau_phan_tieu_chuan: true,
      calories: true,
      cach_thuc_hien: true,
      so_che: true,
      cach_dung: true,
      phan_loai_mon_an: {
        select: {
          danh_muc_mon_an: {
            select: {
              ma_danh_muc_mon_an: true,
              ten_danh_muc_mon_an: true,
            },
          },
        },
      },
      cong_thuc_mon_an: {
        select: {
          ten_nguyen_lieu: true,
          dinh_luong: true,
          nguyen_lieu: {
            select: {
              ma_nguyen_lieu: true,
              ten_nguyen_lieu: true,
              don_vi: true,
            },
          },
        },
      },
    },
  });

  const allNguyenLieuIds = new Set();
  monAn.forEach((m) => {
    m.cong_thuc_mon_an.forEach((c) => {
      if (c.nguyen_lieu?.ma_nguyen_lieu) {
        allNguyenLieuIds.add(c.nguyen_lieu.ma_nguyen_lieu);
      }
    });
  });

  const sanPhamBan = await prisma.san_pham_ban.findMany({
    where: {
      ma_nguyen_lieu: { in: Array.from(allNguyenLieuIds) },
      so_luong_ban: { gt: 0 },
    },
    select: {
      ma_nguyen_lieu: true,
      ma_gian_hang: true,
      gia_cuoi: true,
      don_vi_ban: true,
      so_luong_ban: true,
      gian_hang: {
        select: {
          ten_gian_hang: true,
          vi_tri: true,
          ma_cho: true,
        },
      },
    },
    orderBy: [{ ma_nguyen_lieu: "asc" }, { gia_cuoi: "asc" }],
  });

  const spbByNguyenLieu = new Map();
  sanPhamBan.forEach((sp) => {
    if (!spbByNguyenLieu.has(sp.ma_nguyen_lieu)) {
      spbByNguyenLieu.set(sp.ma_nguyen_lieu, []);
    }
    spbByNguyenLieu.get(sp.ma_nguyen_lieu).push({
      ma_gian_hang: sp.ma_gian_hang,
      ten_gian_hang: sp.gian_hang?.ten_gian_hang,
      vi_tri: sp.gian_hang?.vi_tri,
      ma_cho: sp.gian_hang?.ma_cho,
      gia: sp.gia_cuoi,
      don_vi_ban: sp.don_vi_ban,
      so_luong: sp.so_luong_ban,
    });
  });

  return monAn.map((m) => ({
    ma_mon_an: m.ma_mon_an,
    ten_mon_an: m.ten_mon_an,
    hinh_anh: m.hinh_anh,
    khoang_thoi_gian: m.khoang_thoi_gian,
    do_kho: m.do_kho,
    khau_phan_tieu_chuan: m.khau_phan_tieu_chuan,
    calories: m.calories,
    cach_thuc_hien: m.cach_thuc_hien,
    so_che: m.so_che,
    cach_dung: m.cach_dung,
    danh_muc: m.phan_loai_mon_an.map((p) => ({
      ma_danh_muc: p.danh_muc_mon_an?.ma_danh_muc_mon_an,
      ten_danh_muc: p.danh_muc_mon_an?.ten_danh_muc_mon_an,
    })),
    nguyen_lieu: m.cong_thuc_mon_an.map((c) => {
      const maNL = c.nguyen_lieu?.ma_nguyen_lieu;
      const gianHang = maNL ? spbByNguyenLieu.get(maNL) || [] : [];
      return {
        ma_nguyen_lieu: maNL,
        ten: c.ten_nguyen_lieu || c.nguyen_lieu?.ten_nguyen_lieu,
        dinh_luong: c.dinh_luong,
        don_vi: c.nguyen_lieu?.don_vi,
        gian_hang: gianHang.slice(0, 3),
      };
    }),
  }));
}

async function searchNguyenLieuCoSan(keywords) {
  const searchTerms = keywords
    .toLowerCase()
    .split(/\s+/)
    .filter((t) => t.length > 0);

  if (searchTerms.length === 0) return [];

  const where = {
    OR: searchTerms.map((term) => ({
      ten_nguyen_lieu: { contains: term },
    })),
    san_pham_ban: {
      some: {
        so_luong_ban: { gt: 0 },
      },
    },
  };

  const nguyenLieu = await prisma.nguyen_lieu.findMany({
    where,
    take: 20,
    select: {
      ma_nguyen_lieu: true,
      ten_nguyen_lieu: true,
      don_vi: true,
      san_pham_ban: {
        where: {
          so_luong_ban: { gt: 0 },
        },
        select: {
          gia_cuoi: true,
          ma_gian_hang: true,
          gian_hang: {
            select: {
              ten_gian_hang: true,
              vi_tri: true,
            },
          },
        },
        orderBy: { gia_cuoi: "asc" },
        take: 3,
      },
    },
  });

  return nguyenLieu.map((nl) => ({
    ma_nguyen_lieu: nl.ma_nguyen_lieu,
    ten_nguyen_lieu: nl.ten_nguyen_lieu,
    don_vi: nl.don_vi,
    gian_hang: nl.san_pham_ban.map((sp) => ({
      ma_gian_hang: sp.ma_gian_hang,
      ten_gian_hang: sp.gian_hang?.ten_gian_hang,
      vi_tri: sp.gian_hang?.vi_tri,
      gia: sp.gia_cuoi,
    })),
  }));
}

async function searchMonAnByCho(maCho) {
  const allMonAn = await prisma.mon_an.findMany({
    select: {
      ma_mon_an: true,
      ten_mon_an: true,
      hinh_anh: true,
      khoang_thoi_gian: true,
      do_kho: true,
      khau_phan_tieu_chuan: true,
      calories: true,
      cach_thuc_hien: true,
      so_che: true,
      cach_dung: true,
      phan_loai_mon_an: {
        select: {
          danh_muc_mon_an: {
            select: {
              ma_danh_muc_mon_an: true,
              ten_danh_muc_mon_an: true,
            },
          },
        },
      },
      cong_thuc_mon_an: {
        select: {
          ten_nguyen_lieu: true,
          dinh_luong: true,
          nguyen_lieu: {
            select: {
              ma_nguyen_lieu: true,
              ten_nguyen_lieu: true,
              don_vi: true,
            },
          },
        },
      },
    },
  });

  const gianHangTrongCho = await prisma.gian_hang.findMany({
    where: {
      ma_cho: maCho,
    },
    select: {
      ma_gian_hang: true,
      ten_gian_hang: true,
      vi_tri: true,
    },
  });

  const maGianHangTrongCho = new Set(
    gianHangTrongCho.map((gh) => gh.ma_gian_hang)
  );

  const sanPhamBanTrongCho = await prisma.san_pham_ban.findMany({
    where: {
      ma_gian_hang: { in: Array.from(maGianHangTrongCho) },
      so_luong_ban: { gt: 0 },
    },
    select: {
      ma_nguyen_lieu: true,
      ma_gian_hang: true,
      gia_cuoi: true,
      don_vi_ban: true,
      so_luong_ban: true,
      gian_hang: {
        select: {
          ten_gian_hang: true,
          vi_tri: true,
          ma_cho: true,
        },
      },
    },
    orderBy: [{ ma_nguyen_lieu: "asc" }, { gia_cuoi: "asc" }],
  });

  const spbByNguyenLieu = new Map();
  sanPhamBanTrongCho.forEach((sp) => {
    if (!spbByNguyenLieu.has(sp.ma_nguyen_lieu)) {
      spbByNguyenLieu.set(sp.ma_nguyen_lieu, []);
    }
    spbByNguyenLieu.get(sp.ma_nguyen_lieu).push({
      ma_gian_hang: sp.ma_gian_hang,
      ten_gian_hang: sp.gian_hang?.ten_gian_hang,
      vi_tri: sp.gian_hang?.vi_tri,
      ma_cho: sp.gian_hang?.ma_cho,
      gia: sp.gia_cuoi,
      don_vi_ban: sp.don_vi_ban,
      so_luong: sp.so_luong_ban,
    });
  });

  const monAnHopLe = allMonAn.filter((mon) => {
    if (!mon.cong_thuc_mon_an || mon.cong_thuc_mon_an.length === 0) {
      return false;
    }

    return mon.cong_thuc_mon_an.every((ct) => {
      const maNL = ct.nguyen_lieu?.ma_nguyen_lieu;
      if (!maNL) return false;
      return spbByNguyenLieu.has(maNL) && spbByNguyenLieu.get(maNL).length > 0;
    });
  });

  return monAnHopLe.map((m) => ({
    ma_mon_an: m.ma_mon_an,
    ten_mon_an: m.ten_mon_an,
    hinh_anh: m.hinh_anh,
    khoang_thoi_gian: m.khoang_thoi_gian,
    do_kho: m.do_kho,
    khau_phan_tieu_chuan: m.khau_phan_tieu_chuan,
    calories: m.calories,
    cach_thuc_hien: m.cach_thuc_hien,
    so_che: m.so_che,
    cach_dung: m.cach_dung,
    danh_muc: m.phan_loai_mon_an.map((p) => ({
      ma_danh_muc: p.danh_muc_mon_an?.ma_danh_muc_mon_an,
      ten_danh_muc: p.danh_muc_mon_an?.ten_danh_muc_mon_an,
    })),
    nguyen_lieu: m.cong_thuc_mon_an.map((c) => {
      const maNL = c.nguyen_lieu?.ma_nguyen_lieu;
      const gianHang = maNL ? spbByNguyenLieu.get(maNL) || [] : [];
      return {
        ma_nguyen_lieu: maNL,
        ten: c.ten_nguyen_lieu || c.nguyen_lieu?.ten_nguyen_lieu,
        dinh_luong: c.dinh_luong,
        don_vi: c.nguyen_lieu?.don_vi,
        gian_hang: gianHang.slice(0, 3),
      };
    }),
  }));
}

async function getMonAnGoiY(limit = 5) {
  const monAn = await prisma.mon_an.findMany({
    take: limit,
    orderBy: { ma_mon_an: "asc" },
    select: {
      ma_mon_an: true,
      ten_mon_an: true,
      hinh_anh: true,
      khoang_thoi_gian: true,
      do_kho: true,
      khau_phan_tieu_chuan: true,
      calories: true,
      cach_thuc_hien: true,
      so_che: true,
      cach_dung: true,
      phan_loai_mon_an: {
        select: {
          danh_muc_mon_an: {
            select: {
              ma_danh_muc_mon_an: true,
              ten_danh_muc_mon_an: true,
            },
          },
        },
      },
      cong_thuc_mon_an: {
        select: {
          ten_nguyen_lieu: true,
          dinh_luong: true,
          nguyen_lieu: {
            select: {
              ma_nguyen_lieu: true,
              ten_nguyen_lieu: true,
              don_vi: true,
            },
          },
        },
      },
    },
  });

  const allNguyenLieuIds = new Set();
  monAn.forEach((m) => {
    m.cong_thuc_mon_an.forEach((c) => {
      if (c.nguyen_lieu?.ma_nguyen_lieu) {
        allNguyenLieuIds.add(c.nguyen_lieu.ma_nguyen_lieu);
      }
    });
  });

  const sanPhamBan = await prisma.san_pham_ban.findMany({
    where: {
      ma_nguyen_lieu: { in: Array.from(allNguyenLieuIds) },
      so_luong_ban: { gt: 0 },
    },
    select: {
      ma_nguyen_lieu: true,
      ma_gian_hang: true,
      gia_cuoi: true,
      don_vi_ban: true,
      so_luong_ban: true,
      gian_hang: {
        select: {
          ten_gian_hang: true,
          vi_tri: true,
          ma_cho: true,
        },
      },
    },
    orderBy: [{ ma_nguyen_lieu: "asc" }, { gia_cuoi: "asc" }],
  });

  const spbByNguyenLieu = new Map();
  sanPhamBan.forEach((sp) => {
    if (!spbByNguyenLieu.has(sp.ma_nguyen_lieu)) {
      spbByNguyenLieu.set(sp.ma_nguyen_lieu, []);
    }
    spbByNguyenLieu.get(sp.ma_nguyen_lieu).push({
      ma_gian_hang: sp.ma_gian_hang,
      ten_gian_hang: sp.gian_hang?.ten_gian_hang,
      vi_tri: sp.gian_hang?.vi_tri,
      ma_cho: sp.gian_hang?.ma_cho,
      gia: sp.gia_cuoi,
      don_vi_ban: sp.don_vi_ban,
      so_luong: sp.so_luong_ban,
    });
  });

  return monAn.map((m) => ({
    ma_mon_an: m.ma_mon_an,
    ten_mon_an: m.ten_mon_an,
    hinh_anh: m.hinh_anh,
    khoang_thoi_gian: m.khoang_thoi_gian,
    do_kho: m.do_kho,
    khau_phan_tieu_chuan: m.khau_phan_tieu_chuan,
    calories: m.calories,
    cach_thuc_hien: m.cach_thuc_hien,
    so_che: m.so_che,
    cach_dung: m.cach_dung,
    danh_muc: m.phan_loai_mon_an.map((p) => ({
      ma_danh_muc: p.danh_muc_mon_an?.ma_danh_muc_mon_an,
      ten_danh_muc: p.danh_muc_mon_an?.ten_danh_muc_mon_an,
    })),
    nguyen_lieu: m.cong_thuc_mon_an.map((c) => {
      const maNL = c.nguyen_lieu?.ma_nguyen_lieu;
      const gianHang = maNL ? spbByNguyenLieu.get(maNL) || [] : [];
      return {
        ma_nguyen_lieu: maNL,
        ten: c.ten_nguyen_lieu || c.nguyen_lieu?.ten_nguyen_lieu,
        dinh_luong: c.dinh_luong,
        don_vi: c.nguyen_lieu?.don_vi,
        gian_hang: gianHang.slice(0, 3),
      };
    }),
  }));
}

async function getMonAnDetail(maMonAn) {
  const monAn = await prisma.mon_an.findUnique({
    where: { ma_mon_an: maMonAn },
    select: {
      ma_mon_an: true,
      ten_mon_an: true,
      hinh_anh: true,
      khoang_thoi_gian: true,
      do_kho: true,
      khau_phan_tieu_chuan: true,
      calories: true,
      cach_thuc_hien: true,
      so_che: true,
      cach_dung: true,
      phan_loai_mon_an: {
        select: {
          danh_muc_mon_an: {
            select: {
              ma_danh_muc_mon_an: true,
              ten_danh_muc_mon_an: true,
            },
          },
        },
      },
      cong_thuc_mon_an: {
        select: {
          ten_nguyen_lieu: true,
          dinh_luong: true,
          nguyen_lieu: {
            select: {
              ma_nguyen_lieu: true,
              ten_nguyen_lieu: true,
              don_vi: true,
            },
          },
        },
      },
    },
  });

  if (!monAn) return null;

  const allNguyenLieuIds = new Set();
  monAn.cong_thuc_mon_an.forEach((c) => {
    if (c.nguyen_lieu?.ma_nguyen_lieu) {
      allNguyenLieuIds.add(c.nguyen_lieu.ma_nguyen_lieu);
    }
  });

  const sanPhamBan = await prisma.san_pham_ban.findMany({
    where: {
      ma_nguyen_lieu: { in: Array.from(allNguyenLieuIds) },
      so_luong_ban: { gt: 0 },
    },
    select: {
      ma_nguyen_lieu: true,
      ma_gian_hang: true,
      gia_cuoi: true,
      don_vi_ban: true,
      so_luong_ban: true,
      gian_hang: {
        select: {
          ten_gian_hang: true,
          vi_tri: true,
          ma_cho: true,
        },
      },
    },
    orderBy: [{ ma_nguyen_lieu: "asc" }, { gia_cuoi: "asc" }],
  });

  const spbByNguyenLieu = new Map();
  sanPhamBan.forEach((sp) => {
    if (!spbByNguyenLieu.has(sp.ma_nguyen_lieu)) {
      spbByNguyenLieu.set(sp.ma_nguyen_lieu, []);
    }
    spbByNguyenLieu.get(sp.ma_nguyen_lieu).push({
      ma_gian_hang: sp.ma_gian_hang,
      ten_gian_hang: sp.gian_hang?.ten_gian_hang,
      vi_tri: sp.gian_hang?.vi_tri,
      ma_cho: sp.gian_hang?.ma_cho,
      gia: sp.gia_cuoi,
      don_vi_ban: sp.don_vi_ban,
      so_luong: sp.so_luong_ban,
    });
  });

  return {
    ma_mon_an: monAn.ma_mon_an,
    ten_mon_an: monAn.ten_mon_an,
    hinh_anh: monAn.hinh_anh,
    khoang_thoi_gian: monAn.khoang_thoi_gian,
    do_kho: monAn.do_kho,
    khau_phan_tieu_chuan: monAn.khau_phan_tieu_chuan,
    calories: monAn.calories,
    cach_thuc_hien: monAn.cach_thuc_hien,
    so_che: monAn.so_che,
    cach_dung: monAn.cach_dung,
    danh_muc: monAn.phan_loai_mon_an.map((p) => ({
      ma_danh_muc: p.danh_muc_mon_an?.ma_danh_muc_mon_an,
      ten_danh_muc: p.danh_muc_mon_an?.ten_danh_muc_mon_an,
    })),
    nguyen_lieu: monAn.cong_thuc_mon_an.map((c) => {
      const maNL = c.nguyen_lieu?.ma_nguyen_lieu;
      const gianHang = maNL ? spbByNguyenLieu.get(maNL) || [] : [];
      return {
        ma_nguyen_lieu: maNL,
        ten: c.ten_nguyen_lieu || c.nguyen_lieu?.ten_nguyen_lieu,
        dinh_luong: c.dinh_luong,
        don_vi: c.nguyen_lieu?.don_vi,
        gian_hang: gianHang.slice(0, 3),
      };
    }),
  };
}

module.exports = {
  createConversation,
  getConversation,
  listConversations,
  addMessageToConversation,
  getConversationHistory,
  deleteConversation,
  deleteAllUserConversations,

  searchMonAn,
  searchMonAnByCho,
  searchNguyenLieuCoSan,
  getMonAnGoiY,
  getMonAnDetail,
};
