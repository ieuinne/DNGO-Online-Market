const { prisma } = require("./user.repo");
const paginate = require("../utils/paginate");

async function getGianHangId(maNguoiDung) {
  const gianHang = await prisma.gian_hang.findFirst({
    where: { ma_nguoi_dung: maNguoiDung },
    select: { ma_gian_hang: true },
  });
  if (!gianHang) throw new Error("Người dùng chưa đăng ký gian hàng");
  return gianHang.ma_gian_hang;
}

async function listProductsRepo(maNguoiDung, q) {
  const maGianHang = await getGianHangId(maNguoiDung);
  const { page, limit, skip, take } = paginate(q);

  const where = {
    ma_gian_hang: maGianHang,
    ...(q.search
      ? {
          nguyen_lieu: {
            ten_nguyen_lieu: { contains: q.search },
          },
        }
      : {}),
  };

  const orderBy = { [q.sort || "ngay_cap_nhat"]: q.order || "desc" };

  const [rows, total] = await prisma.$transaction([
    prisma.san_pham_ban.findMany({
      where,
      skip,
      take,
      orderBy,
      include: {
        nguyen_lieu: {
          select: { ten_nguyen_lieu: true, don_vi: true },
        },
      },
    }),
    prisma.san_pham_ban.count({ where }),
  ]);

  return {
    data: rows.map((r) => ({
      ma_nguyen_lieu: r.ma_nguyen_lieu,
      ten_nguyen_lieu: r.nguyen_lieu?.ten_nguyen_lieu,
      hinh_anh: r.hinh_anh,
      so_luong_ban: r.so_luong_ban,
      gia_goc: r.gia_goc,
      gia_cuoi: r.gia_cuoi,
      don_vi_ban: r.don_vi_ban,
      phan_tram_giam_gia: r.phan_tram_giam_gia,
      ngay_cap_nhat: r.ngay_cap_nhat,
    })),
    meta: { page, limit: take, total, hasNext: skip + take < total },
  };
}

async function addProductRepo(maNguoiDung, data) {
  const maGianHang = await getGianHangId(maNguoiDung);

  const exists = await prisma.san_pham_ban.findUnique({
    where: {
      ma_nguyen_lieu_ma_gian_hang: {
        ma_nguyen_lieu: data.ma_nguyen_lieu,
        ma_gian_hang: maGianHang,
      },
    },
  });

  if (exists) throw new Error("Sản phẩm này đã có trong gian hàng của bạn");

  let gia_cuoi = data.gia_goc;
  if (data.phan_tram_giam_gia) {
    gia_cuoi = data.gia_goc * (1 - data.phan_tram_giam_gia / 100);
  }

  return prisma.san_pham_ban.create({
    data: {
      ...data,
      ma_gian_hang: maGianHang,
      ngay_cap_nhat: new Date(),
    },
  });
}

async function updateProductRepo(maNguoiDung, maNguyenLieu, data) {
  const maGianHang = await getGianHangId(maNguoiDung);

  const exists = await prisma.san_pham_ban.findUnique({
    where: {
      ma_nguyen_lieu_ma_gian_hang: {
        ma_nguyen_lieu: maNguyenLieu,
        ma_gian_hang: maGianHang,
      },
    },
  });

  if (!exists) throw new Error("Sản phẩm không tồn tại trong gian hàng");

  const gia_goc = data.gia_goc ?? exists.gia_goc;
  const phan_tram = data.phan_tram_giam_gia ?? exists.phan_tram_giam_gia;

  if (data.gia_goc !== undefined || data.phan_tram_giam_gia !== undefined) {
    if (phan_tram) {
      gia_cuoi = gia_goc * (1 - phan_tram / 100);
    } else {
      gia_cuoi = gia_goc;
    }
  }

  return prisma.san_pham_ban.update({
    where: {
      ma_nguyen_lieu_ma_gian_hang: {
        ma_nguyen_lieu: maNguyenLieu,
        ma_gian_hang: maGianHang,
      },
    },
    data: {
      ...data,
      ngay_cap_nhat: new Date(),
    },
  });
}

async function deleteProductRepo(maNguoiDung, maNguyenLieu) {
  const maGianHang = await getGianHangId(maNguoiDung);

  return prisma.san_pham_ban.delete({
    where: {
      ma_nguyen_lieu_ma_gian_hang: {
        ma_nguyen_lieu: maNguyenLieu,
        ma_gian_hang: maGianHang,
      },
    },
  });
}

module.exports = {
  listProductsRepo,
  addProductRepo,
  updateProductRepo,
  deleteProductRepo,
};
