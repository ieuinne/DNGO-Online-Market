const { prisma } = require("./user.repo");
const { don_hang_tinh_trang_don_hang } = require("@prisma/client");
const {
  determineShippingAddress,
  formatShippingAddress,
} = require("../utils/shipping");
const { genId } = require("./user.repo");

function randBase36(n) {
  let s = "";
  while (s.length < n) s += Math.random().toString(36).slice(2);
  return s.slice(0, n).toUpperCase();
}

function genTxnRefFixed(len = 10) {
  if (len <= 2) return randBase36(Math.max(4, len));
  return "TT" + randBase36(len - 2);
}

function genCartId() {
  return "GH" + Date.now().toString(36).toUpperCase();
}

function genOrderId() {
  return "DH" + Date.now().toString(36).toUpperCase();
}

function genBuyerId() {
  return "NM" + Date.now().toString(36).toUpperCase();
}

function genGomDonId() {
  return "GD" + Date.now().toString(36).toUpperCase();
}

async function getRandomShipper(tx = prisma) {
  const shipper = await tx.shipper.findFirst({
    where: {
      nguoi_dung: {
        ten_dang_nhap: "hieushipper",
      },
    },
    select: { ma_shipper: true },
  });

  if (!shipper) {
    const firstShipper = await tx.shipper.findFirst({
      select: { ma_shipper: true },
    });
    return firstShipper;
  }

  return shipper;
}

async function getRandomKhuVuc(tx = prisma) {
  const allKhuVuc = await tx.khu_vuc.findMany({
    select: { ma_khu_vuc: true },
  });

  if (allKhuVuc.length === 0) {
    return null;
  }

  const randomIndex = Math.floor(Math.random() * allKhuVuc.length);
  return allKhuVuc[randomIndex];
}

async function getRandomKhungGio(tx = prisma) {
  const allKhungGio = await tx.khung_gio.findMany({
    select: { ma_khung_gio: true },
  });

  if (allKhungGio.length === 0) {
    return null;
  }

  const randomIndex = Math.floor(Math.random() * allKhungGio.length);
  return allKhungGio[randomIndex];
}

async function assignRandomShipperToOrder(ma_don_hang, tx = prisma) {
  const existingGomDon = await tx.gom_don.findFirst({
    where: { ma_don_hang },
    select: { ma_gom_don: true },
  });

  if (existingGomDon) {
    return null;
  }

  const shipper = await getRandomShipper(tx);
  const khuVuc = await getRandomKhuVuc(tx);
  const khungGio = await getRandomKhungGio(tx);

  if (!shipper || !khuVuc || !khungGio) {
    return null;
  }

  const gomDon = await tx.gom_don.create({
    data: {
      ma_gom_don: genGomDonId(),
      ma_shipper: shipper.ma_shipper,
      ma_don_hang: ma_don_hang,
      ma_khu_vuc: khuVuc.ma_khu_vuc,
      ma_khung_gio: khungGio.ma_khung_gio,
    },
  });

  return gomDon;
}

async function getOrEnsureBuyer(maNguoiDung, tx = prisma) {
  const buyer = await tx.nguoi_mua.findFirst({
    where: { nguoi_dung: { ma_nguoi_dung: maNguoiDung } },
    select: { ma_nguoi_mua: true },
  });
  if (buyer) return buyer;

  return tx.nguoi_mua.create({
    data: {
      ma_nguoi_mua: genBuyerId(),
      nguoi_dung: { connect: { ma_nguoi_dung: maNguoiDung } },
    },
    select: { ma_nguoi_mua: true },
  });
}

async function getOrCreateCart(maNguoiDung, tx = prisma) {
  const buyer = await getOrEnsureBuyer(maNguoiDung, tx);

  let cart = await tx.gio_hang.findFirst({
    where: { ma_nguoi_mua: buyer.ma_nguoi_mua },
    select: { ma_gio_hang: true },
  });

  if (!cart) {
    cart = await tx.gio_hang.create({
      data: {
        ma_gio_hang: genCartId(),
        ma_nguoi_mua: buyer.ma_nguoi_mua,
      },
      select: { ma_gio_hang: true },
    });
  }

  return cart;
}

async function getLatestSPB(
  { ma_nguyen_lieu, ma_gian_hang, ma_cho },
  tx = prisma
) {
  const where = {
    ma_nguyen_lieu,
    ma_gian_hang,
    ...(ma_cho ? { gian_hang: { ma_cho } } : {}),
  };
  return tx.san_pham_ban.findFirst({
    where,
    orderBy: { ngay_cap_nhat: "desc" },
    select: {
      ma_nguyen_lieu: true,
      ma_gian_hang: true,
      gia_goc: true,
      gia_cuoi: true,
      ngay_cap_nhat: true,
      hinh_anh: true,
    },
  });
}

async function viewCartRepo(maNguoiDung) {
  const cart = await getOrCreateCart(maNguoiDung);

  const items = await prisma.chi_tiet_gio_hang.findMany({
    where: { ma_gio_hang: cart.ma_gio_hang },
    orderBy: [{ ma_gian_hang: "asc" }],
    select: {
      ma_nguyen_lieu: true,
      ma_gian_hang: true,
      so_luong: true,
      ngay_them: true,
    },
  });

  if (items.length === 0) {
    return {
      ma_gio_hang: cart.ma_gio_hang,
      tong_tien: 0,
      so_mat_hang: 0,
      items: [],
    };
  }

  const maNLSet = new Set(items.map((i) => i.ma_nguyen_lieu));
  const maGHSet = new Set(items.map((i) => i.ma_gian_hang));

  const nlRows = await prisma.nguyen_lieu.findMany({
    where: { ma_nguyen_lieu: { in: [...maNLSet] } },
    select: { ma_nguyen_lieu: true, ten_nguyen_lieu: true },
  });
  const nlMap = new Map(
    nlRows.map((r) => [r.ma_nguyen_lieu, r.ten_nguyen_lieu])
  );

  const ghRows = await prisma.gian_hang.findMany({
    where: { ma_gian_hang: { in: [...maGHSet] } },
    select: { ma_gian_hang: true, ten_gian_hang: true, ma_cho: true },
  });
  const ghMap = new Map(
    ghRows.map((r) => [
      r.ma_gian_hang,
      { ten_gian_hang: r.ten_gian_hang, ma_cho: r.ma_cho },
    ])
  );

  const orPairs = items.map((it) => {
    const gh = ghMap.get(it.ma_gian_hang);
    return {
      ma_nguyen_lieu: it.ma_nguyen_lieu,
      ma_gian_hang: it.ma_gian_hang,
      ...(gh?.ma_cho ? { gian_hang: { ma_cho: gh.ma_cho } } : {}),
    };
  });

  const spbRows = await prisma.san_pham_ban.findMany({
    where: { OR: orPairs },
    orderBy: [
      { ma_nguyen_lieu: "asc" },
      { ma_gian_hang: "asc" },
      { ngay_cap_nhat: "desc" },
    ],
    select: {
      ma_nguyen_lieu: true,
      ma_gian_hang: true,
      gia_goc: true,
      gia_cuoi: true,
      don_vi_ban: true,
      hinh_anh: true,
      ngay_cap_nhat: true,
    },
  });

  const priceMap = new Map();
  const priceGocMap = new Map();
  const imgMap = new Map();
  const donViBanMap = new Map();
  for (const r of spbRows) {
    const k = `${r.ma_nguyen_lieu}|${r.ma_gian_hang}`;
    if (!priceMap.has(k)) {
      priceMap.set(k, r.gia_cuoi || 0);
      priceGocMap.set(k, r.gia_goc || 0);
      imgMap.set(k, r.hinh_anh || null);
      donViBanMap.set(k, r.don_vi_ban || null);
    }
  }

  let tong_tien = 0;
  let tong_tien_goc = 0;
  const data = items.map((it) => {
    const nlName = nlMap.get(it.ma_nguyen_lieu) || null;
    const ghInfo = ghMap.get(it.ma_gian_hang) || {};
    const k = `${it.ma_nguyen_lieu}|${it.ma_gian_hang}`;
    const gia_cuoi = priceMap.get(k) || 0;
    const gia_goc = priceGocMap.get(k) || 0;
    const img = imgMap.get(k);
    const don_vi_ban = donViBanMap.get(k);
    const don_gia = Number(gia_cuoi);
    const don_gia_goc = Number(gia_goc);
    const thanh_tien = don_gia * Number(it.so_luong);
    const thanh_tien_goc = don_gia_goc * Number(it.so_luong);

    tong_tien += thanh_tien;
    tong_tien_goc += thanh_tien_goc;

    return {
      ma_nguyen_lieu: it.ma_nguyen_lieu,
      ten_nguyen_lieu: nlName,
      ma_gian_hang: it.ma_gian_hang,
      ten_gian_hang: ghInfo.ten_gian_hang || null,
      so_luong: it.so_luong,
      don_vi_ban: don_vi_ban,
      don_gia_goc: don_gia_goc,
      don_gia: don_gia,
      thanh_tien: thanh_tien,
      hinh_anh: img,
    };
  });

  const tiet_kiem = tong_tien_goc - tong_tien;

  return {
    cart: {
      ma_don_hang: cart.ma_gio_hang,
      tong_tien_goc: tong_tien_goc,
      tong_tien: tong_tien,
      tiet_kiem: tiet_kiem,
      so_mat_hang: data.length,
    },
    items: data,
  };
}

async function addCartItemRepo(maNguoiDung, payload) {
  const { ma_nguyen_lieu, ma_gian_hang, so_luong, ma_cho } = payload;
  const qty = Math.max(1, parseInt(so_luong ?? 1, 10));

  return prisma.$transaction(async (tx) => {
    const cart = await getOrCreateCart(maNguoiDung, tx);

    const spb = await getLatestSPB({ ma_nguyen_lieu, ma_gian_hang, ma_cho });
    if (!spb) {
      throw new Error("Sản phẩm không khả dụng");
    }

    const exists = await tx.chi_tiet_gio_hang.findFirst({
      where: {
        ma_gio_hang: cart.ma_gio_hang,
        ma_nguyen_lieu,
        ma_gian_hang,
      },
    });

    if (exists) {
      await tx.chi_tiet_gio_hang.update({
        where: {
          ma_gio_hang_ma_nguyen_lieu_ma_gian_hang: {
            ma_gio_hang: cart.ma_gio_hang,
            ma_nguyen_lieu,
            ma_gian_hang,
          },
        },
        data: {
          so_luong: exists.so_luong + qty,
        },
      });
    } else {
      await tx.chi_tiet_gio_hang.create({
        data: {
          ma_gio_hang: cart.ma_gio_hang,
          ma_nguyen_lieu,
          ma_gian_hang,
          so_luong: qty,
        },
      });
    }

    const allItems = await tx.chi_tiet_gio_hang.findMany({
      where: { ma_gio_hang: cart.ma_gio_hang },
    });

    let tong_tien = 0;
    for (const item of allItems) {
      const spb = await getLatestSPB({
        ma_nguyen_lieu: item.ma_nguyen_lieu,
        ma_gian_hang: item.ma_gian_hang,
      });
      const price = spb?.gia_cuoi || 0;
      tong_tien += Number(price) * Number(item.so_luong);
    }

    return {
      ma_gio_hang: cart.ma_gio_hang,
      tong_tien: tong_tien,
      so_mat_hang: allItems.length,
    };
  });
}

async function updateCartItemRepo(maNguoiDung, params, body) {
  const { ma_nguyen_lieu, ma_gian_hang } = params;
  const nextQty = parseInt(body?.so_luong ?? 0, 10);

  return prisma.$transaction(async (tx) => {
    const cart = await getOrCreateCart(maNguoiDung, tx);

    const itemKey = {
      ma_gio_hang: cart.ma_gio_hang,
      ma_nguyen_lieu,
      ma_gian_hang,
    };
    const item = await tx.chi_tiet_gio_hang.findFirst({ where: itemKey });
    if (!item) throw new Error("Item không tồn tại trong giỏ");

    if (!Number.isFinite(nextQty) || nextQty <= 0) {
      await tx.chi_tiet_gio_hang.delete({
        where: {
          ma_gio_hang_ma_nguyen_lieu_ma_gian_hang: {
            ma_gio_hang: cart.ma_gio_hang,
            ma_nguyen_lieu,
            ma_gian_hang,
          },
        },
      });
    } else {
      await tx.chi_tiet_gio_hang.update({
        where: {
          ma_gio_hang_ma_nguyen_lieu_ma_gian_hang: {
            ma_gio_hang: cart.ma_gio_hang,
            ma_nguyen_lieu,
            ma_gian_hang,
          },
        },
        data: {
          so_luong: nextQty,
        },
      });
    }

    const allItems = await tx.chi_tiet_gio_hang.findMany({
      where: { ma_gio_hang: cart.ma_gio_hang },
    });

    let tong_tien = 0;
    for (const item of allItems) {
      const spb = await getLatestSPB({
        ma_nguyen_lieu: item.ma_nguyen_lieu,
        ma_gian_hang: item.ma_gian_hang,
      });
      const price = spb?.gia_cuoi || 0;
      tong_tien += Number(price) * Number(item.so_luong);
    }

    return {
      ma_gio_hang: cart.ma_gio_hang,
      tong_tien: tong_tien,
      so_mat_hang: allItems.length,
    };
  });
}

async function removeCartItemRepo(maNguoiDung, params) {
  const { ma_nguyen_lieu, ma_gian_hang } = params;

  return prisma.$transaction(async (tx) => {
    const cart = await getOrCreateCart(maNguoiDung, tx);

    await tx.chi_tiet_gio_hang.deleteMany({
      where: {
        ma_gio_hang: cart.ma_gio_hang,
        ma_nguyen_lieu,
        ma_gian_hang,
      },
    });

    const allItems = await tx.chi_tiet_gio_hang.findMany({
      where: { ma_gio_hang: cart.ma_gio_hang },
    });

    let tong_tien = 0;
    for (const item of allItems) {
      const spb = await getLatestSPB({
        ma_nguyen_lieu: item.ma_nguyen_lieu,
        ma_gian_hang: item.ma_gian_hang,
      });
      const price = spb?.gia_cuoi || 0;
      tong_tien += Number(price) * Number(item.so_luong);
    }

    return {
      ma_gio_hang: cart.ma_gio_hang,
      tong_tien: tong_tien,
      so_mat_hang: allItems.length,
    };
  });
}

async function checkoutCartRepo(
  maNguoiDung,
  selectedItems = [],
  recipientInfo = {},
  payment_method = "chuyen_khoan"
) {
  return prisma.$transaction(async (tx) => {
    const buyer = await getOrEnsureBuyer(maNguoiDung, tx);

    const cart = await tx.gio_hang.findFirst({
      where: { ma_nguoi_mua: buyer.ma_nguoi_mua },
      select: { ma_gio_hang: true },
    });

    if (!cart) throw new Error("Giỏ hàng trống");

    let itemsToCheckout;
    if (!selectedItems || selectedItems.length === 0) {
      itemsToCheckout = await tx.chi_tiet_gio_hang.findMany({
        where: { ma_gio_hang: cart.ma_gio_hang },
      });
    } else {
      const whereConditions = selectedItems.map((item) => ({
        ma_gio_hang: cart.ma_gio_hang,
        ma_nguyen_lieu: item.ma_nguyen_lieu,
        ma_gian_hang: item.ma_gian_hang,
      }));

      itemsToCheckout = await tx.chi_tiet_gio_hang.findMany({
        where: { OR: whereConditions },
      });
    }

    if (itemsToCheckout.length === 0) {
      throw new Error("Không có sản phẩm nào được chọn để thanh toán");
    }

    let tong_tien = 0;
    const orderItems = [];

    for (const item of itemsToCheckout) {
      const spb = await getLatestSPB(
        {
          ma_nguyen_lieu: item.ma_nguyen_lieu,
          ma_gian_hang: item.ma_gian_hang,
        },
        tx
      );

      if (!spb) {
        throw new Error(`Sản phẩm ${item.ma_nguyen_lieu} không còn khả dụng`);
      }

      const gia_cuoi = Number(spb.gia_cuoi || 0);
      const thanh_tien = gia_cuoi * Number(item.so_luong);
      tong_tien += thanh_tien;

      orderItems.push({
        ma_nguyen_lieu: item.ma_nguyen_lieu,
        ma_gian_hang: item.ma_gian_hang,
        so_luong: item.so_luong,
        gia_cuoi: gia_cuoi,
        thanh_tien: thanh_tien,
      });
    }

    if (tong_tien <= 0) {
      throw new Error("Giỏ hàng chưa có sản phẩm hợp lệ");
    }

    const user = await tx.nguoi_dung.findUnique({
      where: { ma_nguoi_dung: maNguoiDung },
      select: {
        ten_nguoi_dung: true,
        sdt: true,
        dia_chi: true,
      },
    });

    const shippingInfo = determineShippingAddress({
      recipient: recipientInfo?.recipient,
      legacyFields: {
        ten_nguoi_nhan: recipientInfo?.ten_nguoi_nhan,
        sdt_nguoi_nhan: recipientInfo?.sdt_nguoi_nhan,
        dia_chi_giao_hang: recipientInfo?.dia_chi_giao_hang,
      },
      userProfile: user
        ? {
            ten_nguoi_dung: user.ten_nguoi_dung,
            sdt: user.sdt,
            dia_chi: user.dia_chi,
          }
        : null,
    });

    const shippingAddressJson = formatShippingAddress(shippingInfo);

    const ma_don_hang = genOrderId();
    const order = await tx.don_hang.create({
      data: {
        ma_don_hang,
        ma_nguoi_mua: buyer.ma_nguoi_mua,
        tong_tien,
        dia_chi_giao_hang: shippingAddressJson,
        tinh_trang_don_hang: "chua_xac_nhan",
        thoi_gian_giao_hang: new Date(),
      },
    });

    for (const item of orderItems) {
      await tx.chi_tiet_don_hang.create({
        data: {
          ma_don_hang: order.ma_don_hang,
          ma_nguyen_lieu: item.ma_nguyen_lieu,
          ma_gian_hang: item.ma_gian_hang,
          so_luong: item.so_luong,
          gia_cuoi: item.gia_cuoi,
        },
      });
    }

    for (const item of itemsToCheckout) {
      await tx.chi_tiet_gio_hang.delete({
        where: {
          ma_gio_hang_ma_nguyen_lieu_ma_gian_hang: {
            ma_gio_hang: cart.ma_gio_hang,
            ma_nguyen_lieu: item.ma_nguyen_lieu,
            ma_gian_hang: item.ma_gian_hang,
          },
        },
      });
    }

    const remainingItems = await tx.chi_tiet_gio_hang.count({
      where: { ma_gio_hang: cart.ma_gio_hang },
    });

    if (remainingItems === 0) {
      await tx.gio_hang.delete({
        where: { ma_gio_hang: cart.ma_gio_hang },
      });
    }

    let ma_thanh_toan = null;
    if (payment_method === "tien_mat") {
      const paymentId = genTxnRefFixed(10);
      const payment = await tx.thanh_toan.create({
        data: {
          ma_thanh_toan: paymentId,
          hinh_thuc_thanh_toan: "tien_mat",
          tai_khoan_thanh_toan: "",
          thoi_gian_thanh_toan: new Date(),
          tinh_trang_thanh_toan: "chua_thanh_toan",
          don_hang: { connect: { ma_don_hang: order.ma_don_hang } },
        },
        select: { ma_thanh_toan: true },
      });
      ma_thanh_toan = payment.ma_thanh_toan;

      await tx.don_hang.update({
        where: { ma_don_hang: order.ma_don_hang },
        data: { tinh_trang_don_hang: "da_xac_nhan" },
      });

      await assignRandomShipperToOrder(order.ma_don_hang, tx);

      const updatedOrder = await tx.don_hang.findUnique({
        where: { ma_don_hang: order.ma_don_hang },
        select: { tinh_trang_don_hang: true },
      });
      if (updatedOrder) {
        order.tinh_trang_don_hang = updatedOrder.tinh_trang_don_hang;
      }
    }

    let tong_tien_goc = 0;
    for (const item of orderItems) {
      const spb = await getLatestSPB(
        {
          ma_nguyen_lieu: item.ma_nguyen_lieu,
          ma_gian_hang: item.ma_gian_hang,
        },
        tx
      );
      const gia_goc = Number(spb?.gia_goc || 0);
      tong_tien_goc += gia_goc * Number(item.so_luong);
    }
    const tiet_kiem = tong_tien_goc - tong_tien;

    return {
      order: {
        ma_don_hang: order.ma_don_hang,
        trang_thai: order.tinh_trang_don_hang,
        tong_tien: tong_tien,
        tong_tien_goc: tong_tien_goc,
        payment_method: payment_method,
        ...(ma_thanh_toan ? { ma_thanh_toan: ma_thanh_toan } : {}),
      },
      totals: {
        ma_don_hang: order.ma_don_hang,
        tong_tien: tong_tien,
        tong_tien_goc: tong_tien_goc,
        tiet_kiem: tiet_kiem,
      },
      so_mat_hang: orderItems.length,
      items_checkout: itemsToCheckout.length,
      items_remaining: remainingItems,
    };
  });
}

async function addMonAnToCartRepo(maNguoiDung, payload) {
  const { ma_mon_an, khau_phan, ma_cho } = payload;

  return prisma.$transaction(async (tx) => {
    const mon = await tx.mon_an.findUnique({
      where: { ma_mon_an },
      select: {
        ma_mon_an: true,
        khau_phan_tieu_chuan: true,
      },
    });

    if (!mon) {
      throw new Error("Món ăn không tồn tại");
    }

    const standardServings = mon.khau_phan_tieu_chuan || 1;
    const requestedServings =
      typeof khau_phan === "number" && khau_phan > 0
        ? khau_phan
        : standardServings;
    const factor = requestedServings / standardServings;

    const congThuc = await tx.cong_thuc_mon_an.findMany({
      where: { ma_mon_an },
      select: {
        ma_nguyen_lieu: true,
        dinh_luong: true,
        ten_nguyen_lieu: true,
        nguyen_lieu: {
          select: {
            ma_nguyen_lieu: true,
            ten_nguyen_lieu: true,
            don_vi: true,
          },
        },
      },
    });

    if (congThuc.length === 0) {
      throw new Error("Món ăn chưa có công thức");
    }

    const cart = await getOrCreateCart(maNguoiDung, tx);
    const addedItems = [];
    const errors = [];

    for (const c of congThuc) {
      const maNL = c.nguyen_lieu?.ma_nguyen_lieu;
      if (!maNL) continue;

      const dinh_luong_raw = c.dinh_luong || null;
      if (!dinh_luong_raw) continue;

      let dinh_luong_cleaned = dinh_luong_raw
        .trim()
        .replace(/\r\n?/g, "")
        .trim();

      const match = dinh_luong_cleaned.match(
        /^(\d+(?:\.\d+)?)\s*\/\s*(\d+)|^(\d+(?:\.\d+)?)/
      );
      if (!match) continue;

      let value;
      if (match[1] && match[2]) {
        value = parseFloat(match[1]) / parseFloat(match[2]);
      } else {
        value = parseFloat(match[3] || match[1]);
      }

      if (isNaN(value)) continue;

      const so_luong = Math.round(value * factor);

      if (so_luong <= 0) continue;

      const whereSPB = {
        ma_nguyen_lieu: maNL,
        so_luong_ban: { gt: 0 },
        ...(ma_cho ? { gian_hang: { ma_cho } } : {}),
      };

      const spb = await getLatestSPB(
        {
          ma_nguyen_lieu: maNL,
          ma_cho,
        },
        tx
      );

      if (!spb) {
        const tenNL =
          c.ten_nguyen_lieu || c.nguyen_lieu?.ten_nguyen_lieu || null;
        errors.push({
          ma_nguyen_lieu: maNL,
          ten_nguyen_lieu: tenNL,
          error: "Nguyên liệu không khả dụng",
        });
        continue;
      }

      const exists = await tx.chi_tiet_gio_hang.findFirst({
        where: {
          ma_gio_hang: cart.ma_gio_hang,
          ma_nguyen_lieu: maNL,
          ma_gian_hang: spb.ma_gian_hang,
        },
      });

      if (exists) {
        await tx.chi_tiet_gio_hang.update({
          where: {
            ma_gio_hang_ma_nguyen_lieu_ma_gian_hang: {
              ma_gio_hang: cart.ma_gio_hang,
              ma_nguyen_lieu: maNL,
              ma_gian_hang: spb.ma_gian_hang,
            },
          },
          data: {
            so_luong: exists.so_luong + so_luong,
          },
        });
      } else {
        await tx.chi_tiet_gio_hang.create({
          data: {
            ma_gio_hang: cart.ma_gio_hang,
            ma_nguyen_lieu: maNL,
            ma_gian_hang: spb.ma_gian_hang,
            so_luong: so_luong,
          },
        });
      }

      const tenNL = c.ten_nguyen_lieu || c.nguyen_lieu?.ten_nguyen_lieu || null;

      addedItems.push({
        ma_nguyen_lieu: maNL,
        ten_nguyen_lieu: tenNL,
        ma_gian_hang: spb.ma_gian_hang,
        so_luong,
      });
    }

    const allItems = await tx.chi_tiet_gio_hang.findMany({
      where: { ma_gio_hang: cart.ma_gio_hang },
    });

    let tong_tien = 0;
    for (const item of allItems) {
      const spb = await getLatestSPB(
        {
          ma_nguyen_lieu: item.ma_nguyen_lieu,
          ma_gian_hang: item.ma_gian_hang,
        },
        tx
      );
      const price = spb?.gia_cuoi || 0;
      tong_tien += Number(price) * Number(item.so_luong);
    }

    return {
      ma_gio_hang: cart.ma_gio_hang,
      tong_tien: tong_tien,
      so_mat_hang: allItems.length,
      added_items: addedItems,
      errors: errors.length > 0 ? errors : undefined,
    };
  });
}

module.exports = {
  viewCartRepo,
  addCartItemRepo,
  updateCartItemRepo,
  removeCartItemRepo,
  checkoutCartRepo,
  assignRandomShipperToOrder,
  addMonAnToCartRepo,
  getOrCreateCart,
};
