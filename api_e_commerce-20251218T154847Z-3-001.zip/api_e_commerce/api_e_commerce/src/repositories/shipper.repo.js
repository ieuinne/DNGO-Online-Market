const { prisma } = require("../../config/db");
const { randomBytes } = require("crypto");

function genGomDonId() {
  const rand = randomBytes(6).toString("base64url").slice(0, 8).toUpperCase();
  return `GD${rand}`;
}

async function getShipperByUserId(ma_nguoi_dung) {
  const shipper = await prisma.shipper.findFirst({
    where: { ma_nguoi_dung },
    include: {
      nguoi_dung: {
        select: {
          ma_nguoi_dung: true,
          ten_nguoi_dung: true,
          sdt: true,
        },
      },
    },
  });
  return shipper;
}

async function listAvailableOrdersRepo(query = {}) {
  const { page = 1, limit = 10, tinh_trang_don_hang } = query;
  const skip = (Number(page) - 1) * Number(limit);
  const take = Number(limit);

  const where = {
    tinh_trang_don_hang: {
      in: ["da_xac_nhan", "dang_giao"],
    },
  };

  if (tinh_trang_don_hang) {
    where.tinh_trang_don_hang = tinh_trang_don_hang;
  }

  const [orders, total] = await Promise.all([
    prisma.don_hang.findMany({
      where,
      orderBy: { thoi_gian_giao_hang: "asc" },
      skip,
      take,
      include: {
        nguoi_mua: {
          include: {
            nguoi_dung: {
              select: {
                ten_nguoi_dung: true,
                sdt: true,
                dia_chi: true,
              },
            },
          },
        },
        gom_don: {
          take: 1,
          include: {
            shipper: {
              include: {
                nguoi_dung: {
                  select: {
                    ten_nguoi_dung: true,
                    sdt: true,
                  },
                },
              },
            },
            khu_vuc: {
              select: {
                ma_khu_vuc: true,
                phuong: true,
              },
            },
            khung_gio: {
              select: {
                ma_khung_gio: true,
                gio_bat_dau: true,
                gio_ket_thuc: true,
              },
            },
          },
        },
        thanh_toan: {
          select: {
            hinh_thuc_thanh_toan: true,
            tinh_trang_thanh_toan: true,
          },
        },
      },
    }),
    prisma.don_hang.count({ where }),
  ]);

  return {
    items: orders.map((order) => ({
      ma_don_hang: order.ma_don_hang,
      tong_tien: order.tong_tien,
      dia_chi_giao_hang: order.dia_chi_giao_hang,
      tinh_trang_don_hang: order.tinh_trang_don_hang,
      thoi_gian_giao_hang: order.thoi_gian_giao_hang,
      nguoi_mua: {
        ma_nguoi_mua: order.ma_nguoi_mua,
        ten_nguoi_dung: order.nguoi_mua.nguoi_dung.ten_nguoi_dung,
        sdt: order.nguoi_mua.nguoi_dung.sdt,
        dia_chi: order.nguoi_mua.nguoi_dung.dia_chi,
      },
      thanh_toan: order.thanh_toan,
      shipper_info: order.gom_don[0]
        ? {
            ma_gom_don: order.gom_don[0].ma_gom_don,
            ma_shipper: order.gom_don[0].shipper.ma_shipper,
            ten_shipper: order.gom_don[0].shipper.nguoi_dung.ten_nguoi_dung,
            sdt_shipper: order.gom_don[0].shipper.nguoi_dung.sdt,
            khu_vuc: order.gom_don[0].khu_vuc,
            khung_gio: order.gom_don[0].khung_gio,
          }
        : null,
    })),
    total,
    page: Number(page),
    limit: Number(limit),
    totalPages: Math.ceil(total / take),
  };
}

async function listMyOrdersRepo(ma_shipper, query = {}) {
  const { page = 1, limit = 10, tinh_trang_don_hang } = query;
  const skip = (Number(page) - 1) * Number(limit);
  const take = Number(limit);

  const where = {
    gom_don: {
      some: {
        ma_shipper: ma_shipper,
      },
    },
  };

  if (tinh_trang_don_hang) {
    where.tinh_trang_don_hang = tinh_trang_don_hang;
  }

  const [orders, total] = await Promise.all([
    prisma.don_hang.findMany({
      where,
      orderBy: { thoi_gian_giao_hang: "asc" },
      skip,
      take,
      include: {
        nguoi_mua: {
          include: {
            nguoi_dung: {
              select: {
                ten_nguoi_dung: true,
                sdt: true,
                dia_chi: true,
              },
            },
          },
        },
        gom_don: {
          where: { ma_shipper },
          include: {
            khu_vuc: {
              select: {
                ma_khu_vuc: true,
                phuong: true,
              },
            },
            khung_gio: {
              select: {
                ma_khung_gio: true,
                gio_bat_dau: true,
                gio_ket_thuc: true,
              },
            },
          },
        },
        thanh_toan: {
          select: {
            hinh_thuc_thanh_toan: true,
            tinh_trang_thanh_toan: true,
          },
        },
      },
    }),
    prisma.don_hang.count({ where }),
  ]);

  return {
    items: orders.map((order) => ({
      ma_don_hang: order.ma_don_hang,
      tong_tien: order.tong_tien,
      dia_chi_giao_hang: order.dia_chi_giao_hang,
      tinh_trang_don_hang: order.tinh_trang_don_hang,
      thoi_gian_giao_hang: order.thoi_gian_giao_hang,
      nguoi_mua: {
        ma_nguoi_mua: order.ma_nguoi_mua,
        ten_nguoi_dung: order.nguoi_mua.nguoi_dung.ten_nguoi_dung,
        sdt: order.nguoi_mua.nguoi_dung.sdt,
        dia_chi: order.nguoi_mua.nguoi_dung.dia_chi,
      },
      thanh_toan: order.thanh_toan,
      gom_don: order.gom_don[0]
        ? {
            ma_gom_don: order.gom_don[0].ma_gom_don,
            khu_vuc: order.gom_don[0].khu_vuc,
            khung_gio: order.gom_don[0].khung_gio,
          }
        : null,
    })),
    total,
    page: Number(page),
    limit: Number(limit),
    totalPages: Math.ceil(total / take),
  };
}

async function acceptOrderRepo(
  ma_shipper,
  ma_don_hang,
  ma_khu_vuc,
  ma_khung_gio
) {
  return prisma.$transaction(async (tx) => {
    const order = await tx.don_hang.findUnique({
      where: { ma_don_hang },
      select: {
        tinh_trang_don_hang: true,
      },
    });

    if (!order) {
      const err = new Error("ORDER_NOT_FOUND");
      err.status = 404;
      throw err;
    }

    if (order.tinh_trang_don_hang !== "da_xac_nhan") {
      const err = new Error("ORDER_NOT_AVAILABLE");
      err.status = 400;
      err.message = "Chỉ có thể nhận đơn hàng đã xác nhận";
      throw err;
    }

    const existingGomDon = await tx.gom_don.findFirst({
      where: { ma_don_hang },
      select: { ma_shipper: true },
    });

    if (existingGomDon) {
      if (existingGomDon.ma_shipper !== ma_shipper) {
        const err = new Error("ORDER_ALREADY_TAKEN");
        err.status = 409;
        err.message = "Đơn hàng đã được shipper khác nhận";
        throw err;
      }
      const gomDon = await tx.gom_don.findFirst({
        where: { ma_don_hang, ma_shipper },
        include: {
          khu_vuc: true,
          khung_gio: true,
        },
      });
      return { gom_don: gomDon, is_new: false };
    }

    const gomDon = await tx.gom_don.create({
      data: {
        ma_gom_don: genGomDonId(),
        ma_shipper: ma_shipper,
        ma_don_hang: ma_don_hang,
        ma_khu_vuc: ma_khu_vuc,
        ma_khung_gio: ma_khung_gio,
      },
      include: {
        khu_vuc: true,
        khung_gio: true,
      },
    });

    const updatedOrder = await tx.don_hang.update({
      where: { ma_don_hang },
      data: { tinh_trang_don_hang: "dang_giao" },
      select: {
        ma_don_hang: true,
        tinh_trang_don_hang: true,
      },
    });

    console.log(
      `[Shipper Accept] Updated order ${ma_don_hang} status to: ${updatedOrder.tinh_trang_don_hang}`
    );

    return { gom_don: gomDon, is_new: true };
  });
}

async function updateOrderStatusRepo(ma_shipper, ma_don_hang, tinh_trang_moi) {
  const allowedStatuses = ["dang_giao", "da_giao", "hoan_thanh"];
  if (!allowedStatuses.includes(tinh_trang_moi)) {
    const err = new Error("INVALID_STATUS");
    err.status = 400;
    err.message = `Trạng thái không hợp lệ. Chỉ cho phép: ${allowedStatuses.join(
      ", "
    )}`;
    throw err;
  }

  return prisma.$transaction(async (tx) => {
    const gomDon = await tx.gom_don.findFirst({
      where: {
        ma_don_hang,
        ma_shipper,
      },
      include: {
        don_hang: {
          select: {
            tinh_trang_don_hang: true,
          },
        },
      },
    });

    if (!gomDon) {
      const err = new Error("FORBIDDEN");
      err.status = 403;
      err.message = "Bạn không có quyền cập nhật đơn hàng này";
      throw err;
    }

    const currentStatus = gomDon.don_hang.tinh_trang_don_hang;

    if (tinh_trang_moi === "dang_giao") {
      if (currentStatus === "dang_giao") {
      } else if (currentStatus !== "da_xac_nhan") {
        const err = new Error("INVALID_TRANSITION");
        err.status = 400;
        err.message = "Chỉ có thể bắt đầu giao từ trạng thái 'da_xac_nhan'";
        throw err;
      }
    }

    if (tinh_trang_moi === "da_giao" && currentStatus !== "dang_giao") {
      const err = new Error("INVALID_TRANSITION");
      err.status = 400;
      err.message = "Chỉ có thể đánh dấu đã giao từ trạng thái 'dang_giao'";
      throw err;
    }

    if (tinh_trang_moi === "hoan_thanh" && currentStatus !== "da_giao") {
      const err = new Error("INVALID_TRANSITION");
      err.status = 400;
      err.message = "Chỉ có thể hoàn thành từ trạng thái 'da_giao'";
      throw err;
    }

    const updatedOrder = await tx.don_hang.update({
      where: { ma_don_hang },
      data: { tinh_trang_don_hang: tinh_trang_moi },
      include: {
        nguoi_mua: {
          include: {
            nguoi_dung: {
              select: {
                ten_nguoi_dung: true,
                sdt: true,
              },
            },
          },
        },
        gom_don: {
          where: { ma_shipper },
          include: {
            khu_vuc: true,
            khung_gio: true,
          },
        },
      },
    });

    console.log(
      `[Shipper] Updated order ${ma_don_hang} status to: ${tinh_trang_moi}`
    );

    return updatedOrder;
  });
}

async function listKhuVucRepo() {
  const khuVucs = await prisma.khu_vuc.findMany({
    orderBy: { phuong: "asc" },
    select: {
      ma_khu_vuc: true,
      phuong: true,
      longitude: true,
      latitude: true,
    },
  });
  return khuVucs;
}

async function listKhungGioRepo() {
  const khungGios = await prisma.khung_gio.findMany({
    orderBy: { gio_bat_dau: "asc" },
    select: {
      ma_khung_gio: true,
      gio_bat_dau: true,
      gio_ket_thuc: true,
    },
  });
  return khungGios;
}

module.exports = {
  getShipperByUserId,
  listAvailableOrdersRepo,
  listMyOrdersRepo,
  acceptOrderRepo,
  updateOrderStatusRepo,
  listKhuVucRepo,
  listKhungGioRepo,
};
