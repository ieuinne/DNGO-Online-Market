const { Storage } = require("@google-cloud/storage");
const path = require("path");

const storage = new Storage();

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "market-images-bucket";

async function uploadToGCS(fileBuffer, originalName, folder = "uploads") {
  try {
    const bucket = storage.bucket(BUCKET_NAME);

    const timestamp = Date.now();
    const ext = path.extname(originalName);
    const baseName = path.basename(originalName, ext);
    const fileName = `${folder}/${baseName}-${timestamp}${ext}`;

    const file = bucket.file(fileName);

    await file.save(fileBuffer, {
      metadata: {
        contentType: getContentType(ext),
        cacheControl: "public, max-age=31536000",
      },
      public: true,
    });

    const publicUrl = `https://storage.googleapis.com/${BUCKET_NAME}/${fileName}`;
    return publicUrl;
  } catch (error) {
    console.error("Error uploading to GCS:", error);
    throw new Error("Không thể upload file lên Google Cloud Storage");
  }
}

async function uploadToGCS(fileBuffer, originalName, folder = "uploads") {
  try {
    const bucket = storage.bucket(BUCKET_NAME);

    const timestamp = Date.now();
    const ext = path.extname(originalName);
    const baseName = path.basename(originalName, ext);
    const fileName = `${folder}/${baseName}-${timestamp}${ext}`;

    const file = bucket.file(fileName);

    await file.save(fileBuffer, {
      metadata: {
        contentType: getContentType(ext),
        cacheControl: "public, max-age=31536000",
      },
      public: true,
    });

    const publicUrl = `https://storage.googleapis.com/${BUCKET_NAME}/${fileName}`;
    return publicUrl;
  } catch (error) {
    console.error("Error uploading to GCS:", error);
    throw new Error("Không thể upload file lên Google Cloud Storage");
  }
}

async function deleteFromGCS(fileUrl) {
  try {
    const urlPattern = new RegExp(
      `https://storage.googleapis.com/${BUCKET_NAME}/(.+)`
    );
    const match = fileUrl.match(urlPattern);

    if (!match) {
      throw new Error("Invalid file URL");
    }

    const filePath = match[1];
    const bucket = storage.bucket(BUCKET_NAME);
    const file = bucket.file(filePath);

    await file.delete();
    return true;
  } catch (error) {
    console.error("Error deleting from GCS:", error);
    throw new Error("Không thể xóa file từ Google Cloud Storage");
  }
}

function getContentType(ext) {
  const types = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
  };
  return types[ext.toLowerCase()] || "application/octet-stream";
}

module.exports = {
  uploadToGCS,
  deleteFromGCS,
};
