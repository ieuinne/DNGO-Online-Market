const { GoogleGenerativeAI } = require("@google/generative-ai");
const {
  searchMonAn,
  searchMonAnByCho,
  searchNguyenLieuCoSan,
  getMonAnGoiY,
  getMonAnDetail: getMonAnDetailFromRepo,
} = require("../repositories/chat.repo");
const { prisma } = require("../repositories/user.repo");

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
if (!GEMINI_API_KEY) {
  console.warn("GEMINI_API_KEY chưa được cấu hình");
}

const genAI = GEMINI_API_KEY ? new GoogleGenerativeAI(GEMINI_API_KEY) : null;

function removeVietnameseTones(str) {
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
  str = str.replace(/đ/g, "d");
  str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "A");
  str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "E");
  str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "I");
  str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "O");
  str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "U");
  str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "Y");
  str = str.replace(/Đ/g, "D");
  return str;
}

async function buildDatabaseContext(userQuery) {
  const queryLower = userQuery.toLowerCase();

  const choPatterns = [
    /chợ\s+([A-Z]\d+)/i,
    /chợ\s+([^\s,\.!?]+(?:\s+[^\s,\.!?]+)*)/i,
    /ở\s+chợ\s+([A-Z]\d+)/i,
    /ở\s+chợ\s+([^\s,\.!?]+(?:\s+[^\s,\.!?]+)*)/i,
    /tại\s+chợ\s+([A-Z]\d+)/i,
    /tại\s+chợ\s+([^\s,\.!?]+(?:\s+[^\s,\.!?]+)*)/i,
  ];

  let maCho = null;
  let choNameOrCode = null;

  for (const pattern of choPatterns) {
    const match = userQuery.match(pattern);
    if (match && match[1]) {
      choNameOrCode = match[1].trim();
      break;
    }
  }

  if (choNameOrCode) {
    if (/^C\d+$/i.test(choNameOrCode)) {
      maCho = choNameOrCode.toUpperCase();
    } else {
      const cho = await prisma.cho_table.findFirst({
        where: {
          OR: [
            { ten_cho: { contains: choNameOrCode } },
            { ten_cho: { contains: removeVietnameseTones(choNameOrCode) } },
          ],
        },
        select: { ma_cho: true, ten_cho: true },
      });
      if (cho) {
        maCho = cho.ma_cho;
        console.log(`Tìm thấy chợ: ${cho.ten_cho} (${maCho})`);
      }
    }
  }

  const isMonAnQuery =
    queryLower.includes("ăn gì") ||
    queryLower.includes("ăn") ||
    queryLower.includes("món") ||
    queryLower.includes("công thức") ||
    queryLower.includes("nấu") ||
    queryLower.includes("chế biến") ||
    queryLower.includes("gợi ý") ||
    queryLower.includes("suggest") ||
    queryLower.includes("recommend") ||
    queryLower.includes("thông tin");

  const isNguyenLieuQuery =
    queryLower.includes("nguyên liệu") ||
    queryLower.includes("có gì") ||
    queryLower.includes("bán") ||
    queryLower.includes("mua") ||
    queryLower.includes("giá") ||
    queryLower.includes("cửa hàng");

  let context = {
    mon_an: [],
    nguyen_lieu: [],
    gioi_thieu: "",
  };

  if (maCho && isMonAnQuery) {
    context.mon_an = await searchMonAnByCho(maCho);
  } else if (isMonAnQuery) {
    if (userQuery.length > 3) {
      let cleanQuery = userQuery
        .replace(
          /là gì|gì|như thế nào|ra sao|thế nào|cho tôi biết|tôi muốn biết|tôi muốn|cách làm|mua nguyên liệu|nguyên liệu món này|và|này|món này/gi,
          ""
        )
        .trim();
      cleanQuery = cleanQuery.replace(/^món\s+/i, "").trim();
      if (cleanQuery.length > 2) {
        context.mon_an = await searchMonAn(cleanQuery);
      }
    }

    if (context.mon_an.length === 0) {
      let keywords = userQuery
        .replace(
          /ăn gì|ăn|món|gợi ý|suggest|recommend|hôm nay|bữa|bữa tối|bữa trưa|bữa sáng|cho tôi|tôi muốn|muốn|biết|về|cách làm|mua nguyên liệu|nguyên liệu món này|và|này|món này/gi,
          ""
        )
        .trim();

      if (keywords && keywords.length > 1) {
        context.mon_an = await searchMonAn(keywords);
      }
    }

    if (context.mon_an.length === 0) {
      const words = userQuery
        .toLowerCase()
        .split(/\s+/)
        .filter(
          (w) =>
            w.length > 2 &&
            ![
              "gì",
              "nào",
              "sao",
              "thế",
              "cho",
              "tôi",
              "muốn",
              "biết",
              "về",
              "món",
              "ăn",
            ].includes(w)
        );

      if (words.length > 0) {
        const longestWord = words.reduce((a, b) =>
          a.length > b.length ? a : b
        );
        if (longestWord.length > 2) {
          context.mon_an = await searchMonAn(longestWord);
        }
      }
    }

    if (context.mon_an.length === 0) {
      context.mon_an = await getMonAnGoiY(5);
    }
  }

  if (isNguyenLieuQuery || context.mon_an.length > 0) {
    const keywords = userQuery
      .replace(/nguyên liệu|có gì|bán|mua|giá|cửa hàng/gi, "")
      .trim();
    if (keywords && keywords.length > 2) {
      context.nguyen_lieu = await searchNguyenLieuCoSan(keywords);
    }
    if (context.nguyen_lieu.length === 0) {
      context.nguyen_lieu = await searchNguyenLieuCoSan("rau thịt cá");
    }
  }

  let contextText = "";

  if (context.mon_an.length > 0) {
    contextText += "\n=== MÓN ĂN CÓ SẴN TRONG HỆ THỐNG ===\n";
    context.mon_an.forEach((mon, idx) => {
      contextText += `\n${idx + 1}. ${mon.ten_mon_an} (Mã: ${mon.ma_mon_an})\n`;

      if (mon.khoang_thoi_gian)
        contextText += `   ⏱️ Thời gian: ${mon.khoang_thoi_gian} phút\n`;
      if (mon.do_kho) contextText += `   📊 Độ khó: ${mon.do_kho}\n`;
      if (mon.khau_phan_tieu_chuan)
        contextText += `   👥 Khẩu phần: ${mon.khau_phan_tieu_chuan} người\n`;
      if (mon.calories) contextText += `   🔥 Calories: ${mon.calories} cal\n`;

      if (mon.danh_muc && mon.danh_muc.length > 0) {
        contextText += `   📁 Danh mục: ${mon.danh_muc
          .map((d) => d.ten_danh_muc)
          .join(", ")}\n`;
      }

      if (mon.nguyen_lieu && mon.nguyen_lieu.length > 0) {
        contextText += `   🥘 Nguyên liệu:\n`;
        mon.nguyen_lieu.forEach((nl) => {
          contextText += `      - ${nl.ten}`;
          if (nl.dinh_luong) contextText += ` (${nl.dinh_luong})`;
          if (nl.don_vi) contextText += ` - Đơn vị: ${nl.don_vi}`;
          contextText += "\n";

          if (nl.gian_hang && nl.gian_hang.length > 0) {
            contextText += `        📍 Có bán tại:\n`;
            nl.gian_hang.forEach((gh) => {
              contextText += `          • ${gh.ten_gian_hang} (${
                gh.vi_tri || "N/A"
              })`;
              if (gh.gia) {
                contextText += ` - Giá: ${Number(gh.gia).toLocaleString(
                  "vi-VN"
                )}đ/${gh.don_vi_ban || ""}`;
              }
              if (gh.so_luong) {
                contextText += ` - Còn: ${gh.so_luong} ${gh.don_vi_ban || ""}`;
              }
              contextText += "\n";
            });
          } else {
            contextText += `        ⚠️ Hiện chưa có gian hàng nào bán nguyên liệu này\n`;
          }
        });
      }

      if (mon.cach_thuc_hien) {
        contextText += `   📝 Cách thực hiện:\n`;
        const steps = mon.cach_thuc_hien.split(/\n+/).filter((s) => s.trim());
        steps.forEach((step, i) => {
          if (step.trim()) {
            contextText += `      ${i + 1}. ${step.trim()}\n`;
          }
        });
      }

      if (mon.so_che) {
        contextText += `   🍳 Sơ chế:\n      ${mon.so_che}\n`;
      }

      if (mon.cach_dung) {
        contextText += `   🍽️ Cách dùng:\n      ${mon.cach_dung}\n`;
      }

      contextText += "\n";
    });
  }

  if (context.nguyen_lieu.length > 0) {
    contextText += "\n=== NGUYÊN LIỆU ĐANG BÁN TẠI CÁC GIAN HÀNG ===\n";
    context.nguyen_lieu.slice(0, 10).forEach((nl) => {
      contextText += `- ${nl.ten_nguyen_lieu} (${nl.don_vi || ""})`;
      if (nl.gian_hang && nl.gian_hang.length > 0) {
        const minPrice = Math.min(...nl.gian_hang.map((gh) => gh.gia || 0));
        contextText += ` - Giá từ ${minPrice.toLocaleString("vi-VN")}đ`;
      }
      contextText += "\n";
    });
  }

  return { context, contextText };
}

async function chatWithGemini(userMessage, conversationHistory = []) {
  if (!genAI) {
    throw new Error(
      "Gemini API chưa được cấu hình. Vui lòng cung cấp GEMINI_API_KEY."
    );
  }

  const { context, contextText } = await buildDatabaseContext(userMessage);

  console.log("=== DATABASE CONTEXT ===");
  console.log("Mon an found:", context.mon_an.length);
  if (context.mon_an.length > 0) {
    console.log(
      "Mon an:",
      context.mon_an.map((m) => ({ ma: m.ma_mon_an, ten: m.ten_mon_an }))
    );
  }
  console.log("Context text length:", contextText.length);
  console.log("=== END DATABASE CONTEXT ===");

  const systemPrompt = `Bạn là một trợ lý ẩm thực thông minh và chuyên nghiệp cho hệ thống chợ online. Nhiệm vụ của bạn là:

1. **Giao tiếp tự nhiên**: Trả lời thân thiện, nhiệt tình bằng tiếng Việt
2. **Gợi ý món ăn**: Dựa trên dữ liệu có sẵn, gợi ý món ăn phù hợp với sở thích người dùng
3. **Thông tin chi tiết**: Khi người dùng hỏi về món ăn, hãy cung cấp đầy đủ:
   - Thông tin cơ bản: thời gian nấu, độ khó, khẩu phần, calories
   - Danh sách nguyên liệu với định lượng cụ thể
   - Công thức nấu chi tiết (cách thực hiện, sơ chế, cách dùng)
   - Thông tin gian hàng bán nguyên liệu (tên gian hàng, vị trí, giá cả, số lượng còn)
4. **Tư vấn mua sắm**: Gợi ý nơi mua nguyên liệu với giá tốt nhất
5. **Chỉ dùng dữ liệu thực tế**: Chỉ đề xuất món ăn và nguyên liệu CÓ TRONG DỮ LIỆU được cung cấp

DỮ LIỆU HỆ THỐNG (THÔNG TIN ĐẦY ĐỦ):
${contextText || "Hiện tại chưa có dữ liệu món ăn cụ thể."}

⚠️⚠️⚠️ QUAN TRỌNG - ĐỌC KỸ VÀ TUÂN THỦ NGHIÊM NGẶT:
- Nếu trong phần "DỮ LIỆU HỆ THỐNG" CÓ món ăn được liệt kê, bạn BẮT BUỘC PHẢI trả lời về món đó với đầy đủ thông tin
- TUYỆT ĐỐI KHÔNG BAO GIỜ nói "không có dữ liệu", "chưa có trong hệ thống", "rất tiếc", "chưa có sẵn" nếu món ăn đã được liệt kê ở trên
- Nếu người dùng hỏi về món ăn có trong danh sách, bạn PHẢI trả lời CHI TIẾT về món đó ngay lập tức với TẤT CẢ thông tin có trong dữ liệu
- Luôn sử dụng thông tin từ dữ liệu được cung cấp, không tự bịa thông tin
- Nếu người dùng hỏi về món ăn cụ thể và món đó CÓ trong "DỮ LIỆU HỆ THỐNG", bạn PHẢI trả lời về món đó, KHÔNG được gợi ý món khác

HƯỚNG DẪN TRẢ LỜI:
- Luôn trả lời bằng tiếng Việt, tự nhiên như đang tư vấn cho bạn bè
- Khi giới thiệu món ăn, hãy đề cập đầy đủ: tên món, mã món (ma_mon_an), calories, thời gian nấu, độ khó
- Liệt kê nguyên liệu kèm định lượng và thông tin gian hàng bán (tên, vị trí, giá)
- Nếu có công thức, hãy tóm tắt các bước chính
- Gợi ý gian hàng có giá tốt nhất cho từng nguyên liệu
- Nếu người dùng hỏi "ăn gì", hãy gợi ý 2-3 món phù hợp với thông tin đầy đủ
- Trả lời chi tiết nhưng không quá dài dòng, dễ đọc, có cấu trúc rõ ràng
- Nếu món ăn có trong dữ liệu, hãy trả lời NGAY với thông tin đầy đủ, không cần hỏi lại`;

  const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

  const history = conversationHistory.slice(-10);

  try {
    if (history.length > 0) {
      const chat = model.startChat({
        history: history,
      });

      const messageWithContext = `${systemPrompt}\n\nNgười dùng: ${userMessage}\n\nTrợ lý:`;
      result = await chat.sendMessage(messageWithContext);
    } else {
      const fullPrompt = `${systemPrompt}\n\nNgười dùng: ${userMessage}\n\nTrợ lý:`;
      result = await model.generateContent(fullPrompt);
    }

    const response = await result.response;
    const text = response.text();

    console.log("=== AI RESPONSE MESSAGE ===");
    console.log(text);
    console.log("=== END AI RESPONSE ===");

    const nguyenLieuFromMonAn = [];
    if (context.mon_an.length > 0) {
      context.mon_an.forEach((mon) => {
        if (mon.nguyen_lieu && mon.nguyen_lieu.length > 0) {
          mon.nguyen_lieu.forEach((nl) => {
            if (
              !nguyenLieuFromMonAn.find(
                (n) => n.ma_nguyen_lieu === nl.ma_nguyen_lieu
              )
            ) {
              nguyenLieuFromMonAn.push({
                ma_nguyen_lieu: nl.ma_nguyen_lieu,
                ten_nguyen_lieu: nl.ten,
                don_vi: nl.don_vi,
                dinh_luong: nl.dinh_luong,
                gian_hang:
                  nl.gian_hang && nl.gian_hang.length > 0
                    ? [nl.gian_hang[0]]
                    : [],
              });
            }
          });
        }
      });
    }

    const allNguyenLieu = [...nguyenLieuFromMonAn];
    context.nguyen_lieu.forEach((nl) => {
      if (!allNguyenLieu.find((n) => n.ma_nguyen_lieu === nl.ma_nguyen_lieu)) {
        allNguyenLieu.push({
          ma_nguyen_lieu: nl.ma_nguyen_lieu,
          ten_nguyen_lieu: nl.ten_nguyen_lieu,
          don_vi: nl.don_vi,
          gian_hang:
            nl.gian_hang && nl.gian_hang.length > 0 ? [nl.gian_hang[0]] : [],
        });
      }
    });

    return {
      message: text,
      suggestions: {
        mon_an: context.mon_an.slice(0, 3).map((m) => ({
          ma_mon_an: m.ma_mon_an,
          ten_mon_an: m.ten_mon_an,
          hinh_anh: m.hinh_anh,
        })),
        nguyen_lieu: allNguyenLieu.slice(0, 10).map((nl) => {
          const hasGianHang = nl.gian_hang && nl.gian_hang.length > 0;
          return {
            ma_nguyen_lieu: nl.ma_nguyen_lieu,
            ten_nguyen_lieu: nl.ten_nguyen_lieu,
            don_vi: nl.don_vi,
            dinh_luong: nl.dinh_luong,
            gian_hang_suggest: hasGianHang
              ? {
                  ma_gian_hang: nl.gian_hang[0].ma_gian_hang,
                  ten_gian_hang: nl.gian_hang[0].ten_gian_hang,
                  vi_tri: nl.gian_hang[0].vi_tri,
                  gia: nl.gian_hang[0].gia,
                  don_vi_ban: nl.gian_hang[0].don_vi_ban,
                  so_luong: nl.gian_hang[0].so_luong,
                }
              : null,
            actions: {
              can_view_detail: true,
              can_add_to_cart: hasGianHang,
              detail_endpoint: `/api/buyer/nguyen-lieu/${nl.ma_nguyen_lieu}`,
              add_to_cart_endpoint: hasGianHang ? "/api/cart" : null,
              buttons: {
                view_detail: {
                  label: "Xem chi tiết",
                  enabled: true,
                  endpoint: `/api/buyer/nguyen-lieu/${nl.ma_nguyen_lieu}`,
                  method: "GET",
                },
                add_to_cart: {
                  label: "Thêm vào giỏ",
                  enabled: hasGianHang,
                  endpoint: "/api/cart",
                  method: "POST",
                  payload: hasGianHang
                    ? {
                        ma_nguyen_lieu: nl.ma_nguyen_lieu,
                        ma_gian_hang: nl.gian_hang[0].ma_gian_hang,
                        so_luong: 1,
                      }
                    : null,
                },
              },
            },
          };
        }),
      },
    };
  } catch (error) {
    console.error("Gemini API error:", error);
    throw new Error(
      `Lỗi khi giao tiếp với AI: ${error.message || "Unknown error"}`
    );
  }
}

module.exports = {
  chatWithGemini,
  buildDatabaseContext,
  getMonAnDetail: getMonAnDetailFromRepo,
};
