const crypto = require("crypto");

function sortObject(obj) {
  const out = {};
  Object.keys(obj)
    .sort()
    .forEach((k) => (out[k] = obj[k]));
  return out;
}
function encPlus(v) {
  return encodeURIComponent(String(v).trim()).replace(/%20/g, "+");
}
function makeSignData(obj) {
  const data = { ...obj };
  delete data.vnp_SecureHash;
  delete data.vnp_SecureHashType;
  const sorted = sortObject(data);
  return Object.keys(sorted)
    .map((k) => `${k}=${encPlus(sorted[k])}`)
    .join("&");
}
function computeHash(signData, secret, type) {
  switch ((type || "").toUpperCase()) {
    case "HMACSHA512":
      return crypto
        .createHmac("sha512", secret)
        .update(signData, "utf8")
        .digest("hex")
        .toUpperCase();
    case "HMACSHA256":
      return crypto
        .createHmac("sha256", secret)
        .update(signData, "utf8")
        .digest("hex")
        .toUpperCase();
    case "SHA256":
      return crypto
        .createHash("sha256")
        .update(String(secret) + String(signData), "utf8")
        .digest("hex")
        .toUpperCase();
    default:
      return crypto
        .createHmac("sha512", secret)
        .update(signData, "utf8")
        .digest("hex")
        .toUpperCase();
  }
}

function verifySignature(obj) {
  const rawSecret =
    process.env.VNP_HASH_SECRET || process.env.VNP_HASHSECRET || "";
  const secret = rawSecret.replace(/["']/g, "").replace(/\r?\n/g, "").trim();
  if (!secret) throw new Error("Missing VNP_HASH_SECRET");

  const type = (process.env.VNP_SECURE_HASH_TYPE || "HMACSHA512").toUpperCase();
  const clientHash = String(obj.vnp_SecureHash || "").toUpperCase();

  const signData = makeSignData(obj);
  const expected = computeHash(signData, secret, type);

  return expected === clientHash;
}

function verifySignatureDebug(obj) {
  const rawSecret =
    process.env.VNP_HASH_SECRET || process.env.VNP_HASHSECRET || "";
  const secret = rawSecret.replace(/["']/g, "").replace(/\r?\n/g, "").trim();
  const type = (process.env.VNP_SECURE_HASH_TYPE || "HMACSHA512").toUpperCase();
  const clientHash = String(obj.vnp_SecureHash || "").toUpperCase();
  const signData = makeSignData(obj);
  const expected = computeHash(signData, secret, type);
  return {
    ok: expected === clientHash,
    type,
    expected,
    client: clientHash,
    signData,
  };
}

module.exports = { verifySignature, verifySignatureDebug };
