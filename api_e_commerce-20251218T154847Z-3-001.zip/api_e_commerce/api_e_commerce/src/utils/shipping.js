function determineShippingAddress({
  recipient = null,
  legacyFields = {},
  savedAddress = null,
  userProfile = null,
}) {
  const nameFinal =
    recipient?.name ||
    legacyFields?.ten_nguoi_nhan ||
    savedAddress?.name ||
    userProfile?.ten_nguoi_dung ||
    null;

  const phoneFinal =
    recipient?.phone ||
    legacyFields?.sdt_nguoi_nhan ||
    savedAddress?.phone ||
    userProfile?.sdt ||
    null;

  const addressFinal =
    recipient?.address ||
    legacyFields?.dia_chi_giao_hang ||
    savedAddress?.address ||
    userProfile?.dia_chi ||
    null;

  return {
    name: nameFinal,
    phone: phoneFinal,
    address: addressFinal,
  };
}

function formatShippingAddress(shippingInfo) {
  return JSON.stringify({
    name: String(shippingInfo.name || "").trim(),
    phone: String(shippingInfo.phone || "").trim(),
    address: String(shippingInfo.address || "").trim(),
  });
}

function parseShippingAddress(jsonString) {
  if (!jsonString) return null;
  try {
    return JSON.parse(jsonString);
  } catch {
    return null;
  }
}

module.exports = {
  determineShippingAddress,
  formatShippingAddress,
  parseShippingAddress,
};
