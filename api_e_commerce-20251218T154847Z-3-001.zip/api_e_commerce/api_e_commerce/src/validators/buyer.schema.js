const Joi = require("joi");

const listKhuVucSchema = Joi.object({
  search: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  sort: Joi.string()
    .valid("ten_khu_vuc", "phuong", "ma_khu_vuc")
    .default("ten_khu_vuc"),
  order: Joi.string().valid("asc", "desc").default("asc"),
});

const listChoSchema = Joi.object({
  ma_khu_vuc: Joi.string().trim().optional(),
  search: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  sort: Joi.string()
    .valid("ten_cho", "ma_cho", "dia_chi", "khu_vuc", "ma_khu_vuc")
    .default("ten_cho"),
  order: Joi.string().valid("asc", "desc").default("asc"),
});

const choDetailParamsSchema = Joi.object({
  ma_cho: Joi.string().required(),
});

const listGianHangQuery = Joi.object({
  search: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  sort: Joi.string()
    .valid("ten_gian_hang", "vi_tri", "danh_gia_tb")
    .default("ten_gian_hang"),
  order: Joi.string().valid("asc", "desc").default("asc"),
  ma_cho: Joi.string().trim().optional(),
});

const gianHangDetailParams = Joi.object({
  ma_gian_hang: Joi.string().trim().required(),
});

const gianHangDetailQuery = Joi.object({
  search: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  sort: Joi.string()
    .valid(
      "ten_nguyen_lieu",
      "gia_goc",
      "gia_cuoi",
      "so_luong_ban",
      "ngay_cap_nhat"
    )
    .default("ngay_cap_nhat"),
  order: Joi.string().valid("asc", "desc").default("desc"),
});

const listNguyenLieuQuery = Joi.object({
  search: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  sort: Joi.string()
    .valid("ten_nguyen_lieu", "ma_nguyen_lieu")
    .default("ten_nguyen_lieu"),
  order: Joi.string().valid("asc", "desc").default("asc"),
  ma_cho: Joi.string().trim().optional(),
  ma_gian_hang: Joi.string().trim().optional(),
  ma_nhom_nguyen_lieu: Joi.string().trim().optional(),
  hinh_anh: Joi.boolean().optional(),
});

const listDanhMucNguyenLieuQuery = Joi.object({
  search: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  sort: Joi.string()
    .valid("ten_nhom_nguyen_lieu", "ma_nhom_nguyen_lieu")
    .default("ten_nhom_nguyen_lieu"),
  order: Joi.string().valid("asc", "desc").default("asc"),
});

const listDanhMucMonAnQuery = Joi.object({
  search: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  sort: Joi.string()
    .valid("ten_danh_muc_mon_an", "ma_danh_muc_mon_an")
    .default("ten_danh_muc_mon_an"),
  order: Joi.string().valid("asc", "desc").default("asc"),
});

const listMonAnQuery = Joi.object({
  search: Joi.string().trim().optional(),
  ma_danh_muc_mon_an: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  sort: Joi.string().valid("ten_mon_an", "ma_mon_an").default("ten_mon_an"),
  order: Joi.string().valid("asc", "desc").default("asc"),
  hinh_anh: Joi.boolean().optional(),
});

const monAnDetailParams = Joi.object({
  ma_mon_an: Joi.string().trim().required(),
});

const nguyenLieuDetailParams = Joi.object({
  ma_nguyen_lieu: Joi.string().trim().required(),
});

const nguyenLieuDetailQuery = Joi.object({
  ma_cho: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  sort: Joi.string()
    .valid("gia_goc", "gia_cuoi", "ngay_cap_nhat")
    .default("ngay_cap_nhat"),
  order: Joi.string().valid("asc", "desc").default("desc"),
});

const monAnDetailQuery = Joi.object({
  khau_phan: Joi.number().integer().min(1).optional(),
});

module.exports = {
  listKhuVucSchema,
  listChoSchema,
  choDetailParamsSchema,
  listGianHangQuery,
  gianHangDetailParams,
  gianHangDetailQuery,
  listNguyenLieuQuery,
  listDanhMucNguyenLieuQuery,
  listDanhMucMonAnQuery,
  listMonAnQuery,

  nguyenLieuDetailParams,
  nguyenLieuDetailQuery,

  monAnDetailParams,
  monAnDetailQuery,
};
