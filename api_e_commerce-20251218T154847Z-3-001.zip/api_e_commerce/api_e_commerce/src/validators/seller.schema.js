const Joi = require("joi");

const listProductQuery = Joi.object({
  search: Joi.string().trim().optional(),
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  sort: Joi.string()
    .valid("ten_nguyen_lieu", "gia_goc", "so_luong_ban", "ngay_cap_nhat")
    .default("ngay_cap_nhat"),
  order: Joi.string().valid("asc", "desc").default("desc"),
});

const addProductSchema = Joi.object({
  ma_nguyen_lieu: Joi.string().trim().required(),
  gia_goc: Joi.number().integer().min(0).required(),
  so_luong_ban: Joi.number().min(0).required(),
  hinh_anh: Joi.string().trim().required(),
  don_vi_ban: Joi.string().trim().required(),
  phan_tram_giam_gia: Joi.number().min(0).max(100).optional(),
  thoi_gian_bat_dau_giam: Joi.date().optional(),
  thoi_gian_ket_thuc_giam: Joi.date().optional(),
});

const updateProductSchema = Joi.object({
  gia_goc: Joi.number().integer().min(0).optional(),
  so_luong_ban: Joi.number().min(0).optional(),
  hinh_anh: Joi.string().trim().optional(),
  don_vi_ban: Joi.string().trim().optional(),
  phan_tram_giam_gia: Joi.number().min(0).max(100).optional(),
  thoi_gian_bat_dau_giam: Joi.date().optional(),
  thoi_gian_ket_thuc_giam: Joi.date().optional(),
});

const deleteProductParams = Joi.object({
  ma_nguyen_lieu: Joi.string().trim().required(),
});

const updateProductParams = Joi.object({
  ma_nguyen_lieu: Joi.string().trim().required(),
});

module.exports = {
  listProductQuery,
  addProductSchema,
  updateProductSchema,
  deleteProductParams,
  updateProductParams,
};
