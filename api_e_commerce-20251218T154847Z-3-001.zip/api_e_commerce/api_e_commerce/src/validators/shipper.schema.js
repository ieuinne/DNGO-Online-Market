const Joi = require("joi");

exports.acceptOrderBody = Joi.object({
  ma_don_hang: Joi.string().required(),
  ma_khu_vuc: Joi.string().required(),
  ma_khung_gio: Joi.string().required(),
});

exports.updateOrderStatusBody = Joi.object({
  tinh_trang_don_hang: Joi.string()
    .valid("dang_giao", "da_giao", "hoan_thanh")
    .required(),
});

exports.listOrdersQuery = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(50).default(10),
  tinh_trang_don_hang: Joi.string()
    .valid("da_xac_nhan", "dang_giao", "da_giao", "hoan_thanh")
    .optional(),
});
