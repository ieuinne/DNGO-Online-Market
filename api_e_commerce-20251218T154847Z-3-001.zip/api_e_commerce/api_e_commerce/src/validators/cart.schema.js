const Joi = require("joi");

exports.viewCartQuery = Joi.object({});

exports.addItemBody = Joi.object({
  ma_nguyen_lieu: Joi.string().required(),
  ma_gian_hang: Joi.string().required(),
  so_luong: Joi.number().integer().min(1).max(999).required(),
  ma_cho: Joi.string().optional(),
});

exports.updateItemParams = Joi.object({
  ma_nguyen_lieu: Joi.string().required(),
  ma_gian_hang: Joi.string().required(),
});
exports.updateItemBody = Joi.object({
  so_luong: Joi.number().integer().min(0).max(999).required(),
});

exports.removeItemParams = exports.updateItemParams;

exports.addMonAnToCartBody = Joi.object({
  ma_mon_an: Joi.string().required(),
  khau_phan: Joi.number().integer().min(1).optional(),
  ma_cho: Joi.string().optional(),
});

exports.checkoutBody = Joi.object({
  selectedItems: Joi.array()
    .items(
      Joi.object({
        ma_nguyen_lieu: Joi.string().required(),
        ma_gian_hang: Joi.string().required(),
      })
    )
    .optional(),
  payment_method: Joi.string()
    .valid("chuyen_khoan", "tien_mat")
    .default("chuyen_khoan")
    .description(
      "Phương thức thanh toán: chuyen_khoan (VNPay) hoặc tien_mat (COD)"
    ),
  recipient: Joi.object({
    name: Joi.string().optional(),
    phone: Joi.string()
      .pattern(/^(0|\+84)\d{9,10}$/)
      .optional(),
    address: Joi.string().optional(),
  }).optional(),
  ten_nguoi_nhan: Joi.string().optional(),
  sdt_nguoi_nhan: Joi.string().optional(),
  dia_chi_giao_hang: Joi.string().optional(),
});
