const Joi = require("joi");

const listOrdersQuery = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(12),
  tinh_trang_don_hang: Joi.string()
    .valid(
      "chua_xac_nhan",
      "da_xac_nhan",
      "dang_giao",
      "da_giao",
      "da_huy",
      "hoan_thanh"
    )
    .optional(),
  sort: Joi.string()
    .valid("thoi_gian_giao_hang", "tong_tien", "ma_don_hang")
    .default("thoi_gian_giao_hang"),
  order: Joi.string().valid("asc", "desc").default("desc"),
});

const orderDetailParams = Joi.object({
  ma_don_hang: Joi.string().trim().required(),
});

module.exports = {
  listOrdersQuery,
  orderDetailParams,
};
