const {
  listOrdersRepo,
  getOrderDetailRepo,
  checkShipperStatusRepo,
  cancelOrderRepo,
} = require("../repositories/order.repo");

exports.listOrders = async (req, res, next) => {
  try {
    const ma_nguoi_dung = req.user.ma_nguoi_dung;
    const result = await listOrdersRepo(ma_nguoi_dung, req.query);

    return res.json({
      success: true,
      ...result,
    });
  } catch (err) {
    console.error("List orders error:", err);
    next(err);
  }
};

exports.getOrderDetail = async (req, res, next) => {
  try {
    const { ma_don_hang } = req.params;
    const ma_nguoi_dung = req.user.ma_nguoi_dung;

    const order = await getOrderDetailRepo(ma_don_hang, ma_nguoi_dung);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Đơn hàng không tồn tại hoặc bạn không có quyền truy cập",
      });
    }

    return res.json({
      success: true,
      data: order,
    });
  } catch (err) {
    console.error("Get order detail error:", err);
    next(err);
  }
};

exports.checkShipperStatus = async (req, res, next) => {
  try {
    const { ma_don_hang } = req.params;

    if (!ma_don_hang) {
      return res.status(400).json({
        success: false,
        message: "ma_don_hang is required",
      });
    }

    const shipperInfo = await checkShipperStatusRepo(ma_don_hang);

    return res.json({
      success: true,
      has_shipper: !!shipperInfo,
      shipper_info: shipperInfo,
    });
  } catch (err) {
    console.error("Check shipper status error:", err);
    next(err);
  }
};

exports.cancelOrder = async (req, res, next) => {
  try {
    const { ma_don_hang } = req.params;
    const ma_nguoi_dung = req.user.ma_nguoi_dung;

    const result = await cancelOrderRepo(ma_don_hang, ma_nguoi_dung);

    return res.json({
      success: true,
      ...result,
    });
  } catch (err) {
    if (
      err.message === "Đơn hàng không tồn tại hoặc bạn không có quyền truy cập"
    ) {
      return res.status(404).json({
        success: false,
        message: err.message,
      });
    }
    if (err.message.includes("Không thể hủy đơn hàng")) {
      return res.status(400).json({
        success: false,
        message: err.message,
      });
    }
    console.error("Cancel order error:", err);
    next(err);
  }
};
