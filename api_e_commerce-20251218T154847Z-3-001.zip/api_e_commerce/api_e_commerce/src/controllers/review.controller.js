const {
  upsertReview,
  listReviewsByStore,
  getMyReview,
  listMyReviewsByOrder,
  deleteMyReview,
} = require("../repositories/review.repo");

exports.createOrUpdate = async (req, res) => {
  try {
    const buyerId = req.user?.ma_nguoi_mua;
    if (!buyerId)
      return res.status(401).json({ success: false, message: "UNAUTHORIZED" });

    const { ma_don_hang, ma_nguyen_lieu, ma_gian_hang, rating, binh_luan } =
      req.body || {};
    if (!ma_don_hang || !ma_nguyen_lieu || !ma_gian_hang)
      return res.status(400).json({
        success: false,
        message: "ma_don_hang, ma_nguyen_lieu, ma_gian_hang are required",
      });

    const result = await upsertReview({
      maNguoiMua: buyerId,
      maDonHang: ma_don_hang,
      maNguyenLieu: ma_nguyen_lieu,
      maGianHang: ma_gian_hang,
      rating: Number(rating),
      binh_luan: binh_luan ? String(binh_luan).trim() : null,
    });

    return res.json({ success: true, ...result });
  } catch (err) {
    const status = err.status || 400;
    return res.status(status).json({ success: false, message: err.message });
  }
};

exports.listByStore = async (req, res) => {
  try {
    const { ma_gian_hang } = req.params;
    const { ma_nguyen_lieu, skip, take, sort } = req.query;
    if (!ma_gian_hang)
      return res
        .status(400)
        .json({ success: false, message: "ma_gian_hang is required" });

    const result = await listReviewsByStore({
      maGianHang: ma_gian_hang,
      maNguyenLieu: ma_nguyen_lieu,
      skip,
      take,
      sort,
    });
    return res.json({ success: true, ...result });
  } catch (err) {
    return res.status(400).json({ success: false, message: err.message });
  }
};

exports.getMine = async (req, res) => {
  try {
    const buyerId = req.user?.ma_nguoi_mua;
    if (!buyerId)
      return res.status(401).json({ success: false, message: "UNAUTHORIZED" });

    const { ma_don_hang, ma_nguyen_lieu, ma_gian_hang } = req.query;

    if (ma_don_hang) {
      const reviews = await listMyReviewsByOrder({
        maNguoiMua: buyerId,
        maDonHang: ma_don_hang,
      });
      return res.json({ success: true, reviews });
    }

    if (!ma_nguyen_lieu || !ma_gian_hang)
      return res.status(400).json({
        success: false,
        message: "ma_don_hang or (ma_nguyen_lieu and ma_gian_hang) is required",
      });

    const review = await getMyReview({
      maNguoiMua: buyerId,
      maDonHang: null,
      maNguyenLieu: ma_nguyen_lieu,
      maGianHang: ma_gian_hang,
    });
    return res.json({ success: true, review });
  } catch (err) {
    return res.status(400).json({ success: false, message: err.message });
  }
};

exports.deleteMine = async (req, res) => {
  try {
    const buyerId = req.user?.ma_nguoi_mua;
    if (!buyerId)
      return res.status(401).json({ success: false, message: "UNAUTHORIZED" });

    const { ma_danh_gia } = req.params;
    if (!ma_danh_gia)
      return res
        .status(400)
        .json({ success: false, message: "ma_danh_gia is required" });

    const result = await deleteMyReview({
      maNguoiMua: buyerId,
      maDanhGia: ma_danh_gia,
    });
    return res.json({ success: true, ...result });
  } catch (err) {
    const status = err.status || 400;
    return res.status(status).json({ success: false, message: err.message });
  }
};
