const {
  getShipperByUserId,
  listAvailableOrdersRepo,
  listMyOrdersRepo,
  acceptOrderRepo,
  updateOrderStatusRepo,
  listKhuVucRepo,
  listKhungGioRepo,
} = require("../repositories/shipper.repo");

exports.getMyInfo = async (req, res, next) => {
  try {
    const ma_nguoi_dung = req.user?.ma_nguoi_dung;
    if (!ma_nguoi_dung)
      return res.status(401).json({ success: false, message: "UNAUTHORIZED" });

    const shipper = await getShipperByUserId(ma_nguoi_dung);
    if (!shipper) {
      return res.status(404).json({
        success: false,
        message: "Shipper profile not found",
      });
    }

    return res.json({
      success: true,
      shipper: {
        ma_shipper: shipper.ma_shipper,
        phuong_tien: shipper.phuong_tien,
        bien_so_xe: shipper.bien_so_xe,
        nguoi_dung: shipper.nguoi_dung,
      },
    });
  } catch (err) {
    next(err);
  }
};

exports.listAvailableOrders = async (req, res, next) => {
  try {
    const result = await listAvailableOrdersRepo(req.query);
    return res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

exports.listMyOrders = async (req, res, next) => {
  try {
    const ma_nguoi_dung = req.user?.ma_nguoi_dung;
    if (!ma_nguoi_dung)
      return res.status(401).json({ success: false, message: "UNAUTHORIZED" });

    const shipper = await getShipperByUserId(ma_nguoi_dung);
    if (!shipper) {
      return res.status(404).json({
        success: false,
        message: "Shipper profile not found",
      });
    }

    const result = await listMyOrdersRepo(shipper.ma_shipper, req.query);
    return res.json({ success: true, ...result });
  } catch (err) {
    next(err);
  }
};

exports.acceptOrder = async (req, res, next) => {
  try {
    const ma_nguoi_dung = req.user?.ma_nguoi_dung;
    if (!ma_nguoi_dung)
      return res.status(401).json({ success: false, message: "UNAUTHORIZED" });

    const shipper = await getShipperByUserId(ma_nguoi_dung);
    if (!shipper) {
      return res.status(404).json({
        success: false,
        message: "Shipper profile not found",
      });
    }

    const { ma_don_hang, ma_khu_vuc, ma_khung_gio } = req.body || {};

    if (!ma_don_hang || !ma_khu_vuc || !ma_khung_gio) {
      return res.status(400).json({
        success: false,
        message: "ma_don_hang, ma_khu_vuc, ma_khung_gio are required",
      });
    }

    const result = await acceptOrderRepo(
      shipper.ma_shipper,
      ma_don_hang,
      ma_khu_vuc,
      ma_khung_gio
    );

    return res.json({
      success: true,
      ...result,
      message: result.is_new
        ? "Đã nhận đơn hàng thành công"
        : "Đơn hàng đã được bạn nhận trước đó",
    });
  } catch (err) {
    const status = err.status || 400;
    return res.status(status).json({
      success: false,
      message: err.message || err.toString(),
    });
  }
};

exports.updateOrderStatus = async (req, res, next) => {
  try {
    const ma_nguoi_dung = req.user?.ma_nguoi_dung;
    if (!ma_nguoi_dung)
      return res.status(401).json({ success: false, message: "UNAUTHORIZED" });

    const shipper = await getShipperByUserId(ma_nguoi_dung);
    if (!shipper) {
      return res.status(404).json({
        success: false,
        message: "Shipper profile not found",
      });
    }

    const { ma_don_hang } = req.params;
    const { tinh_trang_don_hang } = req.body || {};

    if (!tinh_trang_don_hang) {
      return res.status(400).json({
        success: false,
        message: "tinh_trang_don_hang is required",
      });
    }

    const result = await updateOrderStatusRepo(
      shipper.ma_shipper,
      ma_don_hang,
      tinh_trang_don_hang
    );

    return res.json({
      success: true,
      order: {
        ma_don_hang: result.ma_don_hang,
        tinh_trang_don_hang: result.tinh_trang_don_hang,
        tong_tien: result.tong_tien,
        dia_chi_giao_hang: result.dia_chi_giao_hang,
        thoi_gian_giao_hang: result.thoi_gian_giao_hang,
        nguoi_mua: {
          ma_nguoi_mua: result.nguoi_mua.ma_nguoi_mua,
          ten_nguoi_dung: result.nguoi_mua.nguoi_dung.ten_nguoi_dung,
          sdt: result.nguoi_mua.nguoi_dung.sdt,
        },
        gom_don: result.gom_don[0]
          ? {
              ma_gom_don: result.gom_don[0].ma_gom_don,
              khu_vuc: result.gom_don[0].khu_vuc,
              khung_gio: result.gom_don[0].khung_gio,
            }
          : null,
      },
    });
  } catch (err) {
    const status = err.status || 400;
    return res.status(status).json({
      success: false,
      message: err.message || err.toString(),
    });
  }
};

exports.listKhuVuc = async (req, res, next) => {
  try {
    const khuVucs = await listKhuVucRepo();
    return res.json({ success: true, items: khuVucs });
  } catch (err) {
    next(err);
  }
};

exports.listKhungGio = async (req, res, next) => {
  try {
    const khungGios = await listKhungGioRepo();
    return res.json({ success: true, items: khungGios });
  } catch (err) {
    next(err);
  }
};
