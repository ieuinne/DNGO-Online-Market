const { chatWithGemini, getMonAnDetail } = require("../services/chat.service");
const {
  createConversation,
  getConversation,
  getConversationHistory,
  addMessageToConversation,
  listConversations,
  deleteConversation,
} = require("../repositories/chat.repo");

exports.chat = async (req, res, next) => {
  try {
    const { message, conversation_id } = req.body || {};
    const userId = req.user?.ma_nguoi_dung || req.user?.ma_nguoi_mua;
    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Không xác định được người dùng",
      });
    }

    if (
      !message ||
      typeof message !== "string" ||
      message.trim().length === 0
    ) {
      return res.status(400).json({
        success: false,
        message: "Tin nhắn không được để trống",
      });
    }

    let currentConversationId = conversation_id;
    let conversationHistory = [];

    if (currentConversationId) {
      const conversation = getConversation(currentConversationId, userId);
      if (!conversation) {
        return res.status(404).json({
          success: false,
          message: "Không tìm thấy cuộc hội thoại",
        });
      }
      conversationHistory = getConversationHistory(
        currentConversationId,
        userId
      );
    } else {
      const newConversation = createConversation(userId);
      currentConversationId = newConversation.conversation_id;
    }

    addMessageToConversation(
      currentConversationId,
      "user",
      message.trim(),
      userId
    );

    const result = await chatWithGemini(message.trim(), conversationHistory);

    addMessageToConversation(
      currentConversationId,
      "assistant",
      result.message,
      userId
    );

    return res.json({
      success: true,
      message: result.message,
      suggestions: result.suggestions,
      conversation_id: currentConversationId,
    });
  } catch (err) {
    console.error("Chat controller error:", err);
    return res.status(500).json({
      success: false,
      message: err.message || "Lỗi khi xử lý tin nhắn",
    });
  }
};

exports.getMonAnDetail = async (req, res, next) => {
  try {
    const { ma_mon_an } = req.params;

    if (!ma_mon_an) {
      return res.status(400).json({
        success: false,
        message: "ma_mon_an là bắt buộc",
      });
    }

    const detail = await getMonAnDetail(ma_mon_an);

    if (!detail) {
      return res.status(404).json({
        success: false,
        message: "Không tìm thấy món ăn",
      });
    }

    return res.json({
      success: true,
      data: detail,
    });
  } catch (err) {
    console.error("Get mon an detail error:", err);
    return res.status(500).json({
      success: false,
      message: err.message || "Lỗi khi lấy thông tin món ăn",
    });
  }
};

exports.createConversation = async (req, res, next) => {
  try {
    const userId = req.user?.ma_nguoi_dung || req.user?.ma_nguoi_mua;
    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Không xác định được người dùng",
      });
    }

    const conversation = createConversation(userId);

    return res.json({
      success: true,
      data: {
        conversation_id: conversation.conversation_id,
        created_at: conversation.created_at,
      },
    });
  } catch (err) {
    console.error("Create conversation error:", err);
    return res.status(500).json({
      success: false,
      message: err.message || "Lỗi khi tạo cuộc hội thoại",
    });
  }
};

exports.listConversations = async (req, res, next) => {
  try {
    const userId = req.user?.ma_nguoi_dung || req.user?.ma_nguoi_mua;
    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Không xác định được người dùng",
      });
    }

    const skip = parseInt(req.query.skip) || 0;
    const take = parseInt(req.query.take) || 20;

    const conversations = listConversations(userId, skip, take);

    return res.json({
      success: true,
      data: conversations,
      pagination: {
        skip,
        take,
        total: conversations.length,
      },
    });
  } catch (err) {
    console.error("List conversations error:", err);
    return res.status(500).json({
      success: false,
      message: err.message || "Lỗi khi lấy danh sách cuộc hội thoại",
    });
  }
};

exports.getConversation = async (req, res, next) => {
  try {
    const { conversation_id } = req.params;
    const userId = req.user?.ma_nguoi_dung || req.user?.ma_nguoi_mua;
    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Không xác định được người dùng",
      });
    }

    const conversation = getConversation(conversation_id, userId);
    if (!conversation) {
      return res.status(404).json({
        success: false,
        message: "Không tìm thấy cuộc hội thoại",
      });
    }

    return res.json({
      success: true,
      data: {
        conversation_id: conversation.conversation_id,
        created_at: conversation.created_at,
        updated_at: conversation.updated_at,
        messages: conversation.messages,
      },
    });
  } catch (err) {
    console.error("Get conversation error:", err);
    return res.status(500).json({
      success: false,
      message: err.message || "Lỗi khi lấy thông tin cuộc hội thoại",
    });
  }
};

exports.deleteConversation = async (req, res, next) => {
  try {
    const { conversation_id } = req.params;
    const userId = req.user?.ma_nguoi_dung || req.user?.ma_nguoi_mua;
    if (!userId) {
      return res.status(401).json({
        success: false,
        message: "Không xác định được người dùng",
      });
    }

    const deleted = deleteConversation(conversation_id, userId);
    if (!deleted) {
      return res.status(404).json({
        success: false,
        message: "Không tìm thấy cuộc hội thoại hoặc không có quyền xóa",
      });
    }

    return res.json({
      success: true,
      message: "Đã xóa cuộc hội thoại thành công",
    });
  } catch (err) {
    console.error("Delete conversation error:", err);
    return res.status(500).json({
      success: false,
      message: err.message || "Lỗi khi xóa cuộc hội thoại",
    });
  }
};
