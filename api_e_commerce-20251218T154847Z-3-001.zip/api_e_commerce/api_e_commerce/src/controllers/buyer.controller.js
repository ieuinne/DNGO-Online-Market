const {
  listKhuVucRepo,
  listChoRepo,
  listGianHangRepo,
  gianHangDetailRepo,
  listDanhMucNguyenLieuRepo,
  listNguyenLieuRepo,
  listDanhMucMonAnRepo,
  listMonAnOnlyRepo,
  nguyenLieuDetailRepo,
  monAnDetailRepo,
} = require("../repositories/buyer.repo");

exports.listKhuVuc = async (req, res, next) => {
  try {
    const result = await listKhuVucRepo(req.validated);
    res.json(result);
  } catch (e) {
    next(e);
  }
};

exports.listCho = async (req, res, next) => {
  try {
    const result = await listChoRepo(req.validated);
    res.json(result);
  } catch (e) {
    next(e);
  }
};

exports.listGianHang = async (req, res, next) => {
  try {
    const result = await listGianHangRepo(req.validated);
    res.json(result);
  } catch (e) {
    next(e);
  }
};

exports.gianHangDetail = async (req, res, next) => {
  try {
    const result = await gianHangDetailRepo({
      ...req.validated,
      ma_gian_hang: req.params.ma_gian_hang,
    });
    if (!result) {
      return res
        .status(404)
        .json({ success: false, message: "Gian hàng không tồn tại" });
    }
    res.json({ success: true, ...result });
  } catch (e) {
    next(e);
  }
};

exports.listMonAn = async (req, res, next) => {
  try {
    const result = await listMonAnOnlyRepo(req.validated);
    res.json(result);
  } catch (e) {
    next(e);
  }
};

exports.listDanhMucMonAn = async (req, res, next) => {
  try {
    const result = await listDanhMucMonAnRepo(req.validated);
    res.json(result);
  } catch (e) {
    next(e);
  }
};

exports.listNguyenLieu = async (req, res, next) => {
  try {
    const result = await listNguyenLieuRepo(req.validated);
    res.json(result);
  } catch (e) {
    next(e);
  }
};

exports.listDanhMucNguyenLieu = async (req, res, next) => {
  try {
    const result = await listDanhMucNguyenLieuRepo(req.validated);
    res.json(result);
  } catch (e) {
    next(e);
  }
};

exports.nguyenLieuDetail = async (req, res, next) => {
  try {
    const result = await nguyenLieuDetailRepo({
      ...req.validated,
      ma_nguyen_lieu: req.params.ma_nguyen_lieu,
    });
    if (!result) {
      return res
        .status(404)
        .json({ success: false, message: "Nguyên liệu không tồn tại" });
    }
    res.json({ success: true, ...result });
  } catch (e) {
    next(e);
  }
};

exports.monAnDetail = async (req, res, next) => {
  try {
    const result = await monAnDetailRepo({
      ma_mon_an: req.params.ma_mon_an,
      khau_phan: req.validated?.khau_phan,
    });
    if (!result) {
      return res
        .status(404)
        .json({ success: false, message: "Món ăn không tồn tại" });
    }
    res.json({ success: true, ...result });
  } catch (e) {
    next(e);
  }
};
