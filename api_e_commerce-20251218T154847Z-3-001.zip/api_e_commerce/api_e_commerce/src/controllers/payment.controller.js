const { verifySignature, verifySignatureDebug } = require("../utils/vnpay");
const { prisma } = require("../../config/db");
const { buildVnpayUrl } = require("../repositories/payment.repo");
const {
  determineShippingAddress,
  formatShippingAddress,
  parseShippingAddress,
} = require("../utils/shipping");
const { assignRandomShipperToOrder } = require("../repositories/cart.repo");

const getParams = (req) => (req.method === "POST" ? req.body : req.query);

function parseVnpDate(s) {
  if (!s || typeof s !== "string" || s.length !== 14) return new Date();
  const y = +s.slice(0, 4),
    M = +s.slice(4, 6) - 1,
    d = +s.slice(6, 8),
    h = +s.slice(8, 10),
    m = +s.slice(10, 12),
    sec = +s.slice(12, 14);
  return new Date(y, M, d, h, m, sec);
}

// ======================= CHECKOUT =======================
exports.vnpayCheckout = async (req, res) => {
  try {
    const payload = { ...(req.body || {}), ...(req.validated || {}) };
    const { ma_don_hang, bankCode, thoi_gian_giao_hang } = payload;

    if (!ma_don_hang) {
      return res
        .status(400)
        .json({ success: false, message: "ma_don_hang is required" });
    }

    const order = await prisma.don_hang.findUnique({
      where: { ma_don_hang },
      select: {
        ma_don_hang: true,
        ma_nguoi_mua: true,
        dia_chi_giao_hang: true,
      },
    });
    if (!order)
      return res
        .status(404)
        .json({ success: false, message: "ORDER_NOT_FOUND" });

    if (
      order.ma_nguoi_mua &&
      req.user?.ma_nguoi_mua &&
      order.ma_nguoi_mua !== req.user.ma_nguoi_mua
    ) {
      return res
        .status(403)
        .json({ success: false, message: "FORBIDDEN_ORDER" });
    }

    const savedAddress = parseShippingAddress(order.dia_chi_giao_hang);

    let userProfile = null;
    if (!savedAddress) {
      const buyer = await prisma.nguoi_mua.findUnique({
        where: { ma_nguoi_mua: order.ma_nguoi_mua },
        include: { nguoi_dung: true },
      });
      const ud = buyer?.nguoi_dung || {};
      userProfile = {
        ten_nguoi_dung: ud.ten_nguoi_dung ?? null,
        sdt: ud.sdt ?? null,
        dia_chi: ud.dia_chi ?? null,
      };
    }

    const shippingInfo = determineShippingAddress({
      savedAddress: savedAddress,
      userProfile: userProfile,
    });

    if (!shippingInfo.name || !shippingInfo.phone || !shippingInfo.address) {
      return res.status(400).json({
        success: false,
        code: "MISSING_SHIPPING_INFO",
        message:
          "Thiếu thông tin người nhận. Vui lòng bổ sung (name/phone/address) hoặc cập nhật hồ sơ người dùng.",
      });
    }

    const snapshotJson = formatShippingAddress(shippingInfo);

    await prisma.don_hang.update({
      where: { ma_don_hang },
      data: {
        dia_chi_giao_hang: snapshotJson,
        ...(thoi_gian_giao_hang
          ? { thoi_gian_giao_hang: new Date(thoi_gian_giao_hang) }
          : {}),
      },
    });

    const clientIp =
      (req.headers["x-forwarded-for"] || "").split(",")[0].trim() ||
      req.socket?.remoteAddress ||
      "127.0.0.1";

    const { payUrl, ma_thanh_toan, amount } = await buildVnpayUrl({
      ma_don_hang,
      clientIp,
      bankCode,
    });

    return res.json({ success: true, redirect: payUrl, ma_thanh_toan, amount });
  } catch (err) {
    if (err?.message === "ORDER_LOCKED")
      return res.status(409).json({
        success: false,
        code: "ORDER_LOCKED",
        message: "Đơn đã xác nhận/đã thanh toán.",
      });
    if (err?.message === "ORDER_NOT_FOUND")
      return res
        .status(404)
        .json({ success: false, message: "ORDER_NOT_FOUND" });
    if (err?.message === "ORDER_AMOUNT_INVALID")
      return res
        .status(400)
        .json({ success: false, message: "ORDER_AMOUNT_INVALID" });
    console.error(err);
    return res.status(400).json({ success: false, message: err.message });
  }
};

async function _markPaid(tx, payId, vnpData) {
  let orderIdFromInfo = null;
  const info = String(vnpData?.vnp_OrderInfo || "").trim();
  const m = info.match(/don\s+([A-Z0-9_-]+)/i);
  if (m) orderIdFromInfo = m[1];

  const current = await tx.thanh_toan.findUnique({
    where: { ma_thanh_toan: payId },
    select: {
      tinh_trang_thanh_toan: true,
      don_hang: { select: { ma_don_hang: true } },
    },
  });

  let orderId = current?.don_hang?.ma_don_hang ?? null;

  if (!orderId) {
    const host = await tx.don_hang.findFirst({
      where: { thanh_toan: { is: { ma_thanh_toan: payId } } },
      select: { ma_don_hang: true },
    });
    orderId = host?.ma_don_hang ?? null;
  }

  if (!orderId && orderIdFromInfo) orderId = orderIdFromInfo;
  if (!orderId) throw new Error("ORDER_ID_NOT_FOUND_FOR_PAYMENT");

  if (current?.tinh_trang_thanh_toan === "da_thanh_toan") {
    return orderId;
  }

  const txNo = String(vnpData?.vnp_TransactionNo || "");
  const bankNo = String(vnpData?.vnp_BankTranNo || "");
  const bankCode = String(vnpData?.vnp_BankCode || "");
  const tag = [
    bankCode,
    txNo ? `TXN=${txNo}` : "",
    bankNo ? `BANK=${bankNo}` : "",
  ]
    .filter(Boolean)
    .join("#")
    .slice(0, 64);

  const dataPaid = {
    tinh_trang_thanh_toan: "da_thanh_toan",
    tai_khoan_thanh_toan: tag,
    thoi_gian_thanh_toan: parseVnpDate(vnpData?.vnp_PayDate),
  };

  if (!current) {
    await tx.thanh_toan.create({
      data: {
        ma_thanh_toan: payId,
        hinh_thuc_thanh_toan: "chuyen_khoan",
        ...dataPaid,
        don_hang: { connect: { ma_don_hang: orderId } },
      },
    });
  } else {
    await tx.thanh_toan.update({
      where: { ma_thanh_toan: payId },
      data: {
        ...dataPaid,
        ...(current.don_hang
          ? {}
          : { don_hang: { connect: { ma_don_hang: orderId } } }),
      },
    });
  }

  const items = await tx.chi_tiet_don_hang.findMany({
    where: { ma_don_hang: orderId },
    select: {
      ma_nguyen_lieu: true,
      ma_gian_hang: true,
      so_luong: true,
      gia_cuoi: true,
      thanh_tien: true,
    },
  });

  for (const it of items) {
    if (it.thanh_tien == null) {
      await tx.chi_tiet_don_hang.update({
        where: {
          ma_don_hang_ma_nguyen_lieu_ma_gian_hang: {
            ma_don_hang: orderId,
            ma_nguyen_lieu: it.ma_nguyen_lieu,
            ma_gian_hang: it.ma_gian_hang,
          },
        },
        data: {
          thanh_tien: Number(it.gia_cuoi || 0) * Number(it.so_luong || 0),
        },
      });
    }
  }

  const lines = await tx.chi_tiet_don_hang.findMany({
    where: { ma_don_hang: orderId },
    select: { thanh_tien: true, so_luong: true, gia_cuoi: true },
  });
  const tong_tien = lines.reduce((s, r) => {
    const line =
      r.thanh_tien ?? Number(r.gia_cuoi || 0) * Number(r.so_luong || 0);
    return s + Number(line || 0);
  }, 0);

  await tx.don_hang.update({
    where: { ma_don_hang: orderId },
    data: { tinh_trang_don_hang: "da_xac_nhan", tong_tien },
  });

  await assignRandomShipperToOrder(orderId, tx);

  for (const it of items) {
    await tx.san_pham_ban.update({
      where: {
        ma_nguyen_lieu_ma_gian_hang: {
          ma_nguyen_lieu: it.ma_nguyen_lieu,
          ma_gian_hang: it.ma_gian_hang,
        },
      },
      data: { so_luong_ban: { decrement: it.so_luong } },
    });
  }

  return orderId;
}

// ======================= RETURN =======================
exports.vnpayReturn = async (req, res, next) => {
  try {
    const params = getParams(req);

    if (!verifySignature(params)) {
      return res.status(400).json({ success: false, message: "Sai chữ ký" });
    }

    const payId = String(params.vnp_TxnRef || "").trim();
    const response = params.vnp_ResponseCode;

    if (!payId) {
      return res
        .status(400)
        .json({ success: false, message: "Missing vnp_TxnRef" });
    }

    if (response === "00") {
      let orderId;
      await prisma.$transaction(async (tx) => {
        orderId = await _markPaid(tx, payId, params);
      });

      return res.json({
        success: true,
        message: "Thanh toán thành công",
        ma_don_hang: orderId,
        clear_cart: true,
      });
    }

    await prisma.thanh_toan.update({
      where: { ma_thanh_toan: payId },
      data: { tinh_trang_thanh_toan: "chua_thanh_toan" },
    });

    return res.json({
      success: false,
      message: "Thanh toán thất bại",
      code: response,
    });
  } catch (e) {
    next(e);
  }
};

// ======================= IPN =======================
exports.vnpayIpn = async (req, res, next) => {
  try {
    const params = getParams(req);

    const ok = verifySignature(params);
    if (!ok) {
      const dbg = verifySignatureDebug(params);
      console.warn("[VNP IPN VERIFY FAIL]", {
        type: dbg.type,
        expected: dbg.expected,
        client: dbg.client,
        signData: dbg.signData,
      });
      return res
        .status(200)
        .json({ RspCode: "97", Message: "Invalid signature" });
    }

    const payId = String(params.vnp_TxnRef || "");
    const response = params.vnp_ResponseCode;

    if (response === "00") {
      await prisma.$transaction(async (tx) => {
        await _markPaid(tx, payId, params);
      });
      return res
        .status(200)
        .json({ RspCode: "00", Message: "Confirm Success" });
    } else {
      await prisma.thanh_toan.update({
        where: { ma_thanh_toan: payId },
        data: { tinh_trang_thanh_toan: "chua_thanh_toan" },
      });
      return res.status(200).json({ RspCode: "00", Message: "Confirm Fail" });
    }
  } catch (e) {
    return res.status(200).json({ RspCode: "99", Message: "Unknown error" });
  }
};

// ======================= GET PAYMENT METHODS =======================
exports.getPaymentMethods = async (req, res) => {
  try {
    const paymentMethods = [
      {
        code: "chuyen_khoan",
        name: "Chuyển khoản",
        description:
          "Thanh toán qua VNPay (Thẻ ATM, Internet Banking, Ví điện tử)",
        icon: "bank",
        enabled: true,
        requiresRedirect: true,
        endpoint: "/api/payment/vnpay/checkout",
      },
      {
        code: "tien_mat",
        name: "Tiền mặt",
        description: "Thanh toán khi nhận hàng (COD - Cash on Delivery)",
        icon: "cash",
        enabled: true,
        requiresRedirect: false,
        endpoint: null,
      },
    ];

    return res.json({
      success: true,
      payment_methods: paymentMethods,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, message: err.message });
  }
};
