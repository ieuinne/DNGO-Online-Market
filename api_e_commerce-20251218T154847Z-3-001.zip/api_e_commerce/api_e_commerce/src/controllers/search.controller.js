const { searchAll } = require("../repositories/search.repo");
const http = require("../utils/http");

exports.search = async (req, res) => {
  try {
    const { q } = req.query;

    if (!q || q.trim() === "") {
      return http.badRequest(res, "Vui lòng nhập từ khóa tìm kiếm");
    }

    const results = await searchAll(q);

    return http.ok(res, results);
  } catch (error) {
    console.error("Search controller error:", error);
    return http.serverError(res, "Lỗi khi thực hiện tìm kiếm");
  }
};
