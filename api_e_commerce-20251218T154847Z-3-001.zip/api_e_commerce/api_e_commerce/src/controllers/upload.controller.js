const { uploadToGCS } = require("../services/storage.service");

exports.uploadSingle = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Không có file nào được upload",
      });
    }

    const folder = req.body.folder || "uploads";
    const imageUrl = await uploadToGCS(
      req.file.buffer,
      req.file.originalname,
      folder
    );

    return res.status(200).json({
      success: true,
      message: "Upload ảnh thành công",
      data: {
        url: imageUrl,
        originalName: req.file.originalname,
        size: req.file.size,
        mimetype: req.file.mimetype,
      },
    });
  } catch (error) {
    console.error("Upload error:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Lỗi khi upload ảnh",
    });
  }
};

exports.uploadMultiple = async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Không có file nào được upload",
      });
    }

    const folder = req.body.folder || "uploads";
    const uploadPromises = req.files.map((file) =>
      uploadToGCS(file.buffer, file.originalname, folder)
    );

    const imageUrls = await Promise.all(uploadPromises);

    return res.status(200).json({
      success: true,
      message: `Upload ${imageUrls.length} ảnh thành công`,
      data: imageUrls.map((url, index) => ({
        url,
        originalName: req.files[index].originalname,
        size: req.files[index].size,
        mimetype: req.files[index].mimetype,
      })),
    });
  } catch (error) {
    console.error("Upload error:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Lỗi khi upload ảnh",
    });
  }
};
