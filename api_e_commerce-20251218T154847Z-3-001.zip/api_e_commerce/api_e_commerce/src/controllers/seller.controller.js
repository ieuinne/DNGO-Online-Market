const {
  listProductsRepo,
  addProductRepo,
  updateProductRepo,
  deleteProductRepo,
} = require("../repositories/seller.repo");

exports.listProducts = async (req, res, next) => {
  try {
    const result = await listProductsRepo(
      req.user.ma_nguoi_dung,
      req.validated
    );
    res.json(result);
  } catch (e) {
    next(e);
  }
};

exports.addProduct = async (req, res, next) => {
  try {
    const result = await addProductRepo(req.user.ma_nguoi_dung, req.validated);
    res.status(201).json(result);
  } catch (e) {
    next(e);
  }
};

exports.updateProduct = async (req, res, next) => {
  try {
    const result = await updateProductRepo(
      req.user.ma_nguoi_dung,
      req.params.ma_nguyen_lieu,
      req.validated
    );
    res.json(result);
  } catch (e) {
    next(e);
  }
};

exports.deleteProduct = async (req, res, next) => {
  try {
    await deleteProductRepo(req.user.ma_nguoi_dung, req.params.ma_nguyen_lieu);
    res.json({ success: true, message: "Đã xóa sản phẩm khỏi gian hàng" });
  } catch (e) {
    next(e);
  }
};
