const {
  viewCartRepo,
  addCartItemRepo,
  updateCartItemRepo,
  removeCartItemRepo,
  checkoutCartRepo,
  addMonAnToCartRepo,
} = require("../repositories/cart.repo");

exports.viewCart = async (req, res, next) => {
  try {
    const out = await viewCartRepo(req.user.ma_nguoi_dung);
    return res.json({ success: true, ...out });
  } catch (e) {
    next(e);
  }
};

exports.addItem = async (req, res, next) => {
  try {
    const out = await addCartItemRepo(req.user.ma_nguoi_dung, req.body);
    return res.json({ success: true, ...out });
  } catch (e) {
    next(e);
  }
};

exports.updateItem = async (req, res, next) => {
  try {
    const out = await updateCartItemRepo(
      req.user.ma_nguoi_dung,
      req.params,
      req.body
    );
    return res.json({ success: true, ...out });
  } catch (e) {
    next(e);
  }
};

exports.removeItem = async (req, res, next) => {
  try {
    const out = await removeCartItemRepo(req.user.ma_nguoi_dung, req.params);
    return res.json({ success: true, ...out });
  } catch (e) {
    next(e);
  }
};

exports.addMonAnToCart = async (req, res, next) => {
  try {
    const out = await addMonAnToCartRepo(req.user.ma_nguoi_dung, req.body);
    return res.json({ success: true, ...out });
  } catch (e) {
    if (e.message === "Món ăn không tồn tại") {
      return res.status(404).json({
        success: false,
        message: e.message,
      });
    }
    if (e.message === "Món ăn chưa có công thức") {
      return res.status(400).json({
        success: false,
        message: e.message,
      });
    }
    next(e);
  }
};

exports.checkout = async (req, res, next) => {
  try {
    const selectedItems = req.body?.selectedItems || [];

    const payment_method =
      req.body?.payment_method ||
      req.validated?.payment_method ||
      "chuyen_khoan";

    const recipientInfo = {
      recipient: req.body?.recipient,
      ten_nguoi_nhan: req.body?.ten_nguoi_nhan,
      sdt_nguoi_nhan: req.body?.sdt_nguoi_nhan,
      dia_chi_giao_hang: req.body?.dia_chi_giao_hang,
    };

    const out = await checkoutCartRepo(
      req.user.ma_nguoi_dung,
      selectedItems,
      recipientInfo,
      payment_method
    );
    return res.json({ success: true, ...out });
  } catch (e) {
    next(e);
  }
};
