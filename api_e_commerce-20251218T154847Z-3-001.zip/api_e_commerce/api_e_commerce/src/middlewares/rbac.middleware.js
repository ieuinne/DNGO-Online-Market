const ACL = require("../../config/acl");

function isAllowed(role, resource, action) {
  if (!role) return false;
  const rule = ACL[role];
  if (!rule) return false;
  if (rule["*"]?.includes("manage")) return true;
  const actions = rule[resource] || [];
  return actions.includes(action);
}

function rbac(action, resource) {
  return (req, res, next) => {
    const role = req.user?.role;
    if (!isAllowed(role, resource, action)) {
      return res.status(403).json({ message: "Forbidden" });
    }
    next();
  };
}

module.exports = { rbac, isAllowed };
