module.exports = {
  nguoi_mua: {
    khu_vuc: ["read:list"],
    cho: ["read:list", "read:detail"],
    gian_hang: ["read:list", "read:detail"],
    mon_an: ["read:list", "read:detail"],
    don_hang: ["create", "read:detail"],
  },
  gian_hang: {
    khu_vuc: ["read:list"],
    cho: ["read:list", "read:detail"],
    gian_hang: ["read:detail", "update"],
    mon_an: ["create", "read:list", "update", "delete"],
    don_hang: ["read:list", "update"],
  },
  quan_ly_cho: {
    khu_vuc: ["read:list"],
    cho: ["read:list", "read:detail", "update"],
    gian_hang: ["read:list", "update"],
    mon_an: ["read:list"],
    don_hang: ["read:list", "update"],
  },
  shipper: {
    don_hang: ["read:list", "read:detail", "update"],
  },
  admin: {
    "*": ["manage"],
  },
};
