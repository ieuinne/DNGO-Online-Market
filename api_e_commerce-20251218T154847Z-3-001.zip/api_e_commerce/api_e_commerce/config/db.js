const { PrismaClient } = require("@prisma/client");

let prisma;

function getPrisma() {
  if (!prisma) {
    if (process.env.NODE_ENV === "production") {
      prisma = new PrismaClient();
    } else {
      if (!global.__PRISMA__) global.__PRISMA__ = new PrismaClient();
      prisma = global.__PRISMA__;
    }
  }
  return prisma;
}

async function connectDB() {
  const client = getPrisma();
  await client.$queryRaw`SELECT 1`;
  console.log("✅ Connected to MySQL (Cloud SQL) via Prisma");
}

module.exports = { 
  get prisma() { return getPrisma(); }, 
  connectDB 
};
